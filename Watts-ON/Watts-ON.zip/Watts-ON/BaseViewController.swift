//
//  BaseViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/2/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController, UITextFieldDelegate{

    
    // VARIABLES
    internal var feu:FrontendUtilities = FrontendUtilities()
    
    internal var kbHeight: CGFloat!
    internal var timer: NSTimer? = nil
    internal var readingInput: Int = 0
    
    
    internal var MENU_BTN_IMG = "rect-menu.png"
    internal var HOME_BTN_IMG = "home-light-blue.png"
    internal var NAVBAR_BACKGROUND_PICTURE = "navbarTexture.png"
    internal let NAVBAR_BACKGROUND_COLOR:UIColor = UIColor(
                                                        red: 94/255.0,
                                                        green: 130/255.0,
                                                        blue: 166/255.0,
                                                        alpha: 1
    )
    internal let NAVBAR_TINT_COLOR:UIColor = UIColor(
                                                    red: 209/255.0,
                                                    green: 235/255.0,
                                                    blue: 252/255.0,
                                                    alpha: 1
    )
    
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.kbHeight = 70
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // UI
    /*
        Lock and unlock the screen according to the lockIt param.
        input:
            * the screen lock view
            * the view that indicates the action
    */
    internal func lockScreen(lockScreen:UIView, actionIndicator:UIActivityIndicatorView, lockIt:Bool){
        
        if(lockIt){
            actionIndicator.hidden = false
            
            // show lock view and the spinner
            actionIndicator.startAnimating()
            
            // start a fade out animation and hide the lock screen
            UIView.animateWithDuration(
                1.0,
                delay: 0.5,
                options: UIViewAnimationOptions.CurveEaseIn,
                animations: {
                    lockScreen.alpha = 0.8
                }, completion: {
                    finished in
                    
                    actionIndicator.hidden = false
                    lockScreen.hidden = false
                }
            )
            
        }else{
            // start a fade out animation and hide the lock screen
            UIView.animateWithDuration(
                1.0,
                delay: 0.5,
                options: UIViewAnimationOptions.CurveEaseOut,
                animations: {
                    lockScreen.alpha = 0.0
                }, completion: {
                    finished in
                    
                    // hide lock and stop spinner
                    actionIndicator.hidden = true
                    actionIndicator.stopAnimating()
                    lockScreen.hidden = true
                }
            )
            
        }
    }
    
    
    /*
        Activate the locked mode of a screen, blocking the user interaction with its UI.
    */
    internal func activateLockedMode(screenLocker:UIView){
        print("lock user iteraction with the screen as needed.")
        
        UIView.animateWithDuration(0.1, animations:{
            screenLocker.layer.backgroundColor = UIColor.blackColor().CGColor
            screenLocker.layer.opacity = 0.0
        }, completion: {
            (value: Bool) in
            
            UIView.animateWithDuration(1.0, animations:{
                screenLocker.layer.backgroundColor = UIColor.blackColor().CGColor
                screenLocker.layer.opacity = 0.6
            })
        })
    }
    
    
    /*
        Deactivate the locked mode of a screen, allowing the user interaction with its UI.
    */
    internal func deactivateLockedMode(screenLocker:UIView){
        print("unlock user iteraction with the screen as needed.")
        
        UIView.animateWithDuration(0.1, animations:{
            screenLocker.layer.backgroundColor = self.feu.LIGHT_WHITE.CGColor
            screenLocker.layer.opacity = 0.6
        }, completion: {
            (value: Bool) in
                
            UIView.animateWithDuration(1.0, animations:{
                screenLocker.layer.backgroundColor = UIColor.blackColor().CGColor
                screenLocker.layer.opacity = 0.0
            }, completion: {
                finished in
                
                screenLocker.hidden = true
            })
        })
    }
    
    
    /*
        Customize navigation bar
    */
    internal func customizeNavBar(page:UIViewController){
        
        page.navigationController!.navigationBar.barTintColor = self.NAVBAR_BACKGROUND_COLOR
        page.navigationController!.navigationBar.tintColor    = self.NAVBAR_TINT_COLOR
        page.navigationController!.navigationBar.titleTextAttributes = [
            NSForegroundColorAttributeName: self.NAVBAR_TINT_COLOR
        ]
        
        page.navigationController?.navigationBar.barStyle = .Black
    }
    
    
    /*
        Customize the menu button
    */
    internal func customizeMenuBtn(menuBtn:UIBarButtonItem, btnIdentifier:String){
        
        var myImage = UIImage(named: "imgres.jpg")
        
        // make the image resizable
        if(self.feu.ID_HOME == btnIdentifier){
            myImage = UIImage(named: self.HOME_BTN_IMG)
        }else if(self.feu.ID_MENU == btnIdentifier){
            myImage = UIImage(named: self.MENU_BTN_IMG)
        }
        
        let myInsets:UIEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0)
        myImage = myImage!.resizableImageWithCapInsets(myInsets)
        
        // the the resizable image to the button
        menuBtn.image = myImage
    }
    
    
    /*
        Customize add button
    */
    internal func customizeAddBtn(addBtn:UIButton){
        addBtn.layer.borderColor = self.feu.LIGHT_WHITE.CGColor
        addBtn.layer.borderWidth = 5.0
        addBtn.layer.cornerRadius = addBtn.frame.size.width / 2
        addBtn.clipsToBounds = true
        self.applyCurvedShadow(addBtn)
    }
    
    func applyCurvedShadow(view: UIView) {
        let size = view.bounds.size
        let width = size.width
        let height = size.height
        let depth = CGFloat(11.0)
        let lessDepth = 0.8 * depth
        let curvyness = CGFloat(5)
        let radius = CGFloat(1)
        let path = UIBezierPath()
        
        // top left
        path.moveToPoint(CGPoint(x: radius, y: height))
        
        // top right
        path.addLineToPoint(CGPoint(x: width - 2*radius, y: height))
        
        // bottom right + a little extra
        path.addLineToPoint(CGPoint(x: width - 2*radius, y: height + depth))
        
        // path to bottom left via curve
        path.addCurveToPoint(CGPoint(x: radius, y: height + depth),
            controlPoint1: CGPoint(x: width - curvyness, y: height + lessDepth - curvyness),
            controlPoint2: CGPoint(x: curvyness, y: height + lessDepth - curvyness))
        
        let layer = view.layer
        layer.shadowPath = path.CGPath
        layer.shadowColor = UIColor.blackColor().CGColor
        layer.shadowOpacity = 0.3
        layer.shadowRadius = radius
        layer.shadowOffset = CGSize(width: 0, height: -3)
    }
    

    // Information methods
    //--------------------
    /*
        Presents an information dialog
    */
    internal func infoWindow(txt:String, title:String, vc:UIViewController) -> Void{
        
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction) in
            //println("Handle Ok logic here")
        }))
        
        vc.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    /*
        Modified version of the method above with the cancel option
    */
    internal func infoWindowWithCancel(txt:String, title:String, vc:UIViewController) -> Void{
        
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction) in
            //println("Handle Ok logic here")
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: { (action: UIAlertAction!) in
            //print("Handle Cancel Logic here")
        }))
        
        vc.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    
    // Keyboard methods
    //-----------------
    /*
       Keyboard event related method. This method return the first responder to a controller
    */
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    /*
       Keyboard event related method. Assign listener methods for notifications, on the notification center. Adds the keyboard related methods
    */
    override func viewWillAppear(animated:Bool) {
        super.viewWillAppear(animated)
        
        NSNotificationCenter.defaultCenter().addObserver(
            self,
            selector: Selector("keyboardWillShow:"),
            name: UIKeyboardWillShowNotification,
            object: nil
        )
        
        NSNotificationCenter.defaultCenter().addObserver(
            self,
            selector: Selector("keyboardWillHide:"),
            name: UIKeyboardWillHideNotification,
            object: nil
        )
    }
    
    /*
       Keyboard event related method. Remove the keyboard observers once the view is gonna dissapear
    */
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    /*
       Keyboard event related method. Detects that the keyboard is going to show up and call an animation to move the main view up
    */
    func keyboardWillShow(notification: NSNotification) {
        self.animateTextField(true)
    }
    
    /*
       Keyboard event related method. Detects that the keyboard is going to disappear and call an animation to move the main view down
    */
    func keyboardWillHide(notification: NSNotification) {
        self.animateTextField(false)
    }
    
    /*
       Keyboard event related method. Animate a text field upwards, being the distance on the movement equal to the keyboard height
    */
    func animateTextField(up: Bool) {
        var movement:CGFloat
        
        if(up){
            movement = -kbHeight
        }else{
            movement = kbHeight
        }
        
        if(((movement < 0) && (self.view.frame.origin.y >= 0)) ||
            ((movement > 0) && (self.view.frame.origin.y <= 0))){
        
            UIView.animateWithDuration(0.3,
                animations: {
                    self.view.frame = CGRectOffset(self.view.frame, 0, movement)
                }
            )
        }
    }
    
    /*
        Text field methods
    */
    func textFieldDidBeginEditing(textField: UITextField) {
        print("started editing field ...")
        self.calculateDistanceMoviment(textField)
    }
    
    /*
        Calculate the distance of the input movement on the keyboard animation
    */
    internal func calculateDistanceMoviment(textField:UITextField){
        
        // hardcode the keyboard height, can be improved to get the actual keyboard height
        let keyboardHeight = CGFloat(280.0)
        
        // try to get the parentsView origin.y position
        var foundLastSuperView:Bool = false
        var parentsYPos:CGFloat = 0.0
        var parentA = textField.superview
        
        // while not at the top of the element's view hierarchy
        while(!foundLastSuperView){
            
            // get the element superview until the top of the view hierarchy
            if let parentB:UIView = parentA{
                
                // get the Y position of the partent and sum it, to consider the real position of the text input being threated
                parentsYPos += parentB.frame.origin.y
                parentA = parentB.superview
            }else{
                foundLastSuperView = true
            }
        }
        
        // calculate de difference to base distance of the movement
        var difference = self.view.frame.height - (textField.frame.origin.y + parentsYPos)
        
        // if the keyboard is covering the input field, push the input higher and add some extra
        if(difference < keyboardHeight){
            
            // get the distance as a percentage of the difference
            difference = keyboardHeight - difference
            let distance = (difference * CGFloat(100.0)/keyboardHeight) * (keyboardHeight * CGFloat(0.01))
            
            self.kbHeight = distance + CGFloat(10.0)
        }else{
            self.kbHeight = 0.0
        }
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        timer?.invalidate()
        timer = NSTimer.scheduledTimerWithTimeInterval(5, target: self, selector: Selector("dismissKeyboard:"), userInfo: textField, repeats: false)
        return true
    }
    
    func dismissKeyboard(timer: NSTimer) {
        if let textField = timer.userInfo as? UITextField{
            textField.resignFirstResponder()
        }else{
            print("problem getting textfield out of the userInfo variable of the timer object")
        }
    }
    
    
    
    
    
    
    
    
    // Data transportation
    //--------------------
    internal func setReadingValue(input:Double){
        print("\ndo something with the input gathered from UpdateReadingViewController")
        print("value: \(input)")
    }

}



// Extends the Int class to implement some convenience methods
extension Int{
    
    static func random(range: Range<Int> ) -> Int{
        var offset = 0
        
        if range.startIndex < 0{
            offset = abs(range.startIndex)
        }
        
        let mini = UInt32(range.startIndex + offset)
        let maxi = UInt32(range.endIndex   + offset)
        
        return Int(mini + arc4random_uniform(maxi - mini)) - offset
    }
}


// Extends the double class to especify formatting
extension Double {
    
    func format(f:String) -> String {
        return NSString(format: "%\(f)f", self) as String
    }
}


// Extends the NSDate class to customize comparisons between NSDate objects
extension NSDate{
    
    func isGreaterThanDate(dateToCompare:NSDate) -> Bool{
        
        var isGreater = false
        
        if self.compare(dateToCompare) == NSComparisonResult.OrderedDescending{
            isGreater = true
        }
        
        return isGreater
    }
    
    
    func isLessThanDate(dateToCompare:NSDate) -> Bool{
        
        var isLess = false
        
        if self.compare(dateToCompare) == NSComparisonResult.OrderedAscending{
            isLess = true
        }
        
        return isLess
    }
    
    
    class func getReadebleDate(date:NSDate) -> String{
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = NSDateFormatterStyle.ShortStyle
        dateFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        
        return dateFormatter.stringFromDate(date)
    }
    
    
    class func getDateObject(date:String, format:String) -> NSDate{
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = format
        
        let date = dateFormatter.dateFromString(date)
        
        return date!
    }
    
    
    class func getDaysLeft(startDate:NSDate, endDate:NSDate) -> Int{
        
        let cal = NSCalendar.currentCalendar()
        let unit:NSCalendarUnit = NSCalendarUnit.Day
        let components = cal.components(unit, fromDate: startDate, toDate: endDate, options: .MatchFirst)
        
        return components.day
    }
}
