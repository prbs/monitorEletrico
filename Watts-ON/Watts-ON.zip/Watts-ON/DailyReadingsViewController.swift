//
//  DailyReadingsViewController.swift
//  x
//
//  Created by Diego Silva on 11/1/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class DailyReadingsViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    
    // VARIABLES
    @IBOutlet weak var tableView: UITableView!
    
    internal let dbh:DBHelpers         = DBHelpers()
    internal let selector:Selector     = Selector("goHome")
    
    internal var days:Array<AnyObject>        = []
    internal var selectedDay:String           = ""
    internal var selectedDayIndex:NSIndexPath = NSIndexPath()
    internal var deletedSelectedDay:Bool      = false
    internal var indexPaths:[Int:NSIndexPath] = [Int:NSIndexPath]()
    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        // UI
        self.customizeNavBar(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.leftBarButtonItem = self.feu.getHomeNavbarBtn(self.selector, parentVC: self)
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }

    
    
    // UI
    // Table methods
    /*
        Number of rows
    */
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    /*
        Number of rows in table
    */
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.days.count
    }
    
    /*
        Build table cells
    */
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // insert the index path on rows controller
        self.indexPaths[indexPath.row] = indexPath
        
        // create and load a cell
        let cell = tableView.dequeueReusableCellWithIdentifier("DayCell") as! DayTableViewCell
        
        // load cell content
        cell.parentController = self
        cell.index = indexPath
        if let dayLabel:String = self.days[indexPath.row] as? String{
            cell.day.text = dayLabel
        }
        
        return cell
    }

    /*
        Send user to details screen
    */
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        
        if cell != nil {
            print("selected day cell \(self.days[indexPath.row])")
            if let dayLabel:String = self.days[indexPath.row] as? String{
                self.selectedDay = dayLabel
                self.selectedDayIndex = indexPath
            }
            
            self.performSegueWithIdentifier(self.feu.SEGUE_READINGS, sender: self)
        }
    }
    
    /*
        Delete a table row
    */
    func deleteRowAtIndexPath(indexPath: NSIndexPath) {
        
        // selected day
        let day = self.days[indexPath.row]
        
        // update the lastSumReadingVal variable
        if let lastSumReadVal = DBHelpers.currentLocationData?.getLastSumReadingVal(){
            
            if let sumOfWattsPerDay = DBHelpers.currentLocationData?.getSumOfWattsForDay(day as! String){
            
                DBHelpers.currentLocationData?.setLastSumReadingVal(
                    lastSumReadVal - sumOfWattsPerDay
                )
                
                // reset the animation controller to allow a new execution of the progress animation on the home screen
                FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_BOLT] = false
            }else{
                print("problem getting sum of watts for selected day")
            }
        }else{
            print("problem getting sum of reading values")
        }
        
        // delete day from the currentLocationData 'datafile'
        DBHelpers.currentLocationData?.removeReadingsOfDay(day as! String)
        
        // update app backend file
        DBHelpers.updateLocationData(
            (DBHelpers.currentLocation?.getObId())!,
            dataManager: DBHelpers.currentLocationData!
        )
        
        // delete row from datasource
        self.days.removeAtIndex(indexPath.row)
        self.indexPaths.removeValueForKey(indexPath.row)
        
        // remove cell from table view
        self.tableView.deleteRowsAtIndexPaths(
            [indexPath],
            withRowAnimation: UITableViewRowAnimation.Automatic
        )
        
        // if the user confirmed the deletion of all readings of a day return to the previous screen
        if(self.days.count == 0){
            self.goHome()
        }
    }
    
    /*
        Modified version of the method above with the cancel option
    */
    internal func infoWindowWithCancelToDelete(txt:String, title:String, vc:UIViewController, indexPath:NSIndexPath) -> Void{
        
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction) in
            
            self.deleteRowAtIndexPath(indexPath)
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: { (action: UIAlertAction!) in
            print("user canceled the operation.")
        }))
        
        vc.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    
    
    // LOGIC
    
    
    
    
    
    // NAVIGATION
    /*
        Send the user back to the home screen by dismissing the current page from the pages stack
    */
    internal func goHome(){
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    
    
    /*
        Get something out of the Readings Details page
    */
    @IBAction func saveReadingDetail(segue:UIStoryboardSegue) {
        if let _ = segue.sourceViewController as? ReadingsViewController {
            // remove deleted day from table if the user deleted all readings of that day
            if(self.deletedSelectedDay){
                self.deleteRowAtIndexPath(self.selectedDayIndex)
            }
        }
    }
    
    
    /*
        Prepare data to next page
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if(segue.identifier == self.feu.SEGUE_READINGS){
            
            let destineVC = (segue.destinationViewController as! ReadingsViewController)
            destineVC.day = self.selectedDay
           
            if let dailyReadings = DBHelpers.currentLocationData?.getDailyReadings(self.selectedDay){
                
                destineVC.times = Array(dailyReadings.keys).sort()
                destineVC.dailyReadings = dailyReadings
            }else{
                print("problem getting daily readings for location")
            }
            
            // get the position of the clock making a regression from the 'lastSumReadingsVal' until the last input of the selected day
            let sumLastReadingForDay:Double = (
                DBHelpers.currentLocationData?.getSumLastReadingForDay(self.selectedDay)
            )!
            
            destineVC.sumRdgsForLastInpOfDay = sumLastReadingForDay
        }
    }
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
