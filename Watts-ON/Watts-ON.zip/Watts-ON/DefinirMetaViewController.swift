//
//  DefinirMetaViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class DefinirMetaViewController: BaseViewController {

    
    
    // VARIABLES
    internal let dbh:DBHelpers     = DBHelpers()
    internal let dbu:DBUtils       = DBUtils()
    internal let selector:Selector = Selector("goHome")
    
    internal var selectedReward:Reward?   = nil
    internal var currentGoalObj:PFObject? = nil
    internal var newGoal:Bool             = false
    internal var popViewController : UpdateReadingViewController!
    internal var wasFirstReadingMade:Bool = false
    internal var firstReading:Double      = 0.0
    internal var justDeletedGoal:Bool     = false
    
    internal let DOUBLE_FORMAT             = ".2"
    internal let LABEL_BTN_SELECT_REWARD   = "Escolher"
    internal let LABEL_BTN_UPDATE_REWARD   = "Atualizar"
    internal let REWARD_STATUS_DEFAULT     = "Recompensas tornam objetivos mais divertidos"
    internal let REWARD_STATUS_NO_SELECTED = "Nenhuma recompensa selecionada :("
    internal let SCREEN_TITLE_NEW          = "Definir Meta"
    internal let SCREEN_TITLE_UPDATE       = "Atualizar Meta"
    
    @IBOutlet weak var scroller: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var amountToPay: UITextField!
    @IBOutlet weak var startDate: UILabel!
    @IBOutlet weak var endDate: UIDatePicker!
    @IBOutlet weak var selectedRewardTitle: UILabel!
    @IBOutlet weak var selectRewardBtn: UIButton!
    
    @IBOutlet weak var kwhVal: UITextField!
    @IBOutlet weak var deleteRewardBtn: UIButton!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var toolBar: UIView!
    @IBOutlet weak var toolBarShadow: UIView!

    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // UI initialization
        self.customizeNavBar(self)
        self.customizeToolBar()
        
        // user is updating a goal
        if(DBHelpers.currentGoal != nil){
            self.resetUI()
            self.unlockUI()
            self.loadCurrentGoal()
        }else{
            
            // set new flag to control the current operation across the methods of this class
            self.newGoal = true
            
            // if the fisrt reading of the new goal wasn't made yet
            if(DBHelpers.currentDevice == nil){
                
                // check if the screen isn't reloading after a goal deletion
                if(!self.wasFirstReadingMade){
                    self.resetUI()
                    self.lockUI()
                    self.firstReadingDialog()
                }
            }else{
                print("user has a device, no need to lock and reset the UI")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = self.SCREEN_TITLE_NEW
        self.navigationItem.leftBarButtonItem = self.feu.getHomeNavbarBtn(self.selector, parentVC: self)
        
        // left align select reward button text
        self.selectRewardBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Left;
        self.deleteRewardBtn.hidden = true
        
        // setup the distance that the keyboard is going to move and set keyboard disapear
        self.amountToPay.delegate  = self
        self.amountToPay.keyboardType  = UIKeyboardType.NumbersAndPunctuation
        self.kbHeight = 0.0
        
        // set the scroll view
        self.setScroller()
    }
    
    
    
    // UI
    /*
        Selector of the amount to pay
    */
    @IBAction func selectorAmountSum(sender: AnyObject) {
        self.feu.sumFloatTextInput(self.amountToPay)
    }
    
    @IBAction func selectorAmountSub(sender: AnyObject) {
        self.feu.subFloatTextInputTilZero(self.amountToPay)
    }
    
    /*
        Selector KW/h sum
    */
    @IBAction func selectorKwhSum(sender: AnyObject) {
        self.feu.sumFloatTextInput(self.kwhVal)
    }
    
    @IBAction func selectorKwhSub(sender: AnyObject) {
        self.feu.subFloatTextInputTilZero(self.kwhVal)
    }
    
    
    
    /*
        Navigate to the rewards page and select an available reward
    */
    @IBAction func selectReward(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_CHOOSE_REWARD_GOAL, sender: self)
    }
    
    
    /*
        Erase the selected reward from the goal definition
    */
    @IBAction func eraseReward(sender: AnyObject) {
        print("\nerases the selected reward from the goal definition")

        if(DBHelpers.currentGoal != nil){
            DBHelpers.currentGoal!.setGoalReward(nil)
            DBHelpers.currentGoal!.setGoalReward(nil)
        }
        
        self.selectedReward = nil
        self.selectedRewardTitle.text = self.REWARD_STATUS_DEFAULT
        self.selectRewardBtn.setTitle(self.LABEL_BTN_SELECT_REWARD, forState: .Normal)
        self.deleteRewardBtn.hidden = true
    }
    
    
    /*
        Create a new goal or updates an existing one
    */
    @IBAction func saveGoal(sender: AnyObject) {
        self.upsertGoal()
    }
    
    
    /*
        Delete current goal from local system and the app backend, and reset UI
    */
    @IBAction func deleteGoal(sender: AnyObject) {
        
        if(DBHelpers.currentGoal != nil){
            self.deleteGoalDialog()
        }else{
            self.infoWindow("Não existe um objetivo configurado para este ambiente",title:"Atenção",vc: self)
        }
    }
    
    
    /*
        Redirect the user to the closed and archived goals screen
    */
    @IBAction func goOldGoals(sender: AnyObject) {
        
        self.performSegueWithIdentifier(self.feu.SEGUE_OLD_GOALS, sender: nil)
    }
    
    
    
    /*
        Send the user to the home pagd
    */
    @IBAction func goHome(sender: AnyObject) {
        self.feu.goToSegueX(self.feu.ID_HOME, obj: NSObject())
    }

    
    
    
    /*
        Customize the toolbar
    */
    internal func customizeToolBar(){
        self.toolBar.layer.borderColor = UIColor.whiteColor().CGColor
        
        self.feu.applyPlainShadow(self.toolBarShadow)
    }
    
    
    
    
    /*
        Configure the dimensions of the scroller view
    */
    internal func setScroller(){
        self.scroller.userInteractionEnabled = true
        self.scroller.frame = self.view.bounds
        
        self.scroller.contentSize.height = self.contentView.frame.size.height
        self.scroller.contentSize.width = self.contentView.frame.size.width
        
        self.feu.applyCurvedShadow(self.scroller)
    }
    
    
    /*
        Resets the UI high before loading data for update in it, to give a sense of something ongoing
    */
    internal func resetUI(){
        self.amountToPay.text = ""
        self.startDate.text = NSDate().formattedWith(self.feu.DATE_FORMAT)
        self.kwhVal.text = String(0.0)
        self.endDate.setDate(NSDate(), animated: false)
    }
    
    
    /*
        Lock the UI elements. Not input can be done
    */
    internal func lockUI(){
        self.amountToPay.enabled     = false
        self.endDate.enabled         = false
        self.selectRewardBtn.enabled = false
        self.deleteRewardBtn.enabled = false
        self.saveBtn.enabled         = false
    }
    
    
    /*
        Unlock UI elements
    */
    internal func unlockUI(){
        self.amountToPay.enabled     = true
        self.endDate.enabled         = true
        self.selectRewardBtn.enabled = true
        self.deleteRewardBtn.enabled = true
        self.saveBtn.enabled         = true
    }
    
    
    /*
        Ask if the user really want to create a new goal without a reward
    */
    internal func createGoalWithoutRewardDialog(desiredVal:NSNumber, cDate:NSDate, endDate:NSDate, kwh:NSNumber) -> Void{
        
        let title = "Tem certeza?"
        let msg   = self.REWARD_STATUS_DEFAULT
        
        let refreshAlert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Criar sem recompensa", style: .Default, handler: {
            (action: UIAlertAction) in
            
            self.createGoal(
                desiredVal,
                cDate     :cDate,
                endDate   :endDate,
                kwh       :kwh
            )
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: { (action: UIAlertAction!) in
            
            print("User canceled the new goal operation without a reward")
        }))
        
        self.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    
    /*
        This dialog is shown before the user create a new goal if the current location doesn't
        have a functional device. A goal can only be created without a device if the user 
        inform the current reading value on his/her eletric monitoring device.
    */
    internal func firstReadingDialog(){
        
        let title = "Você não possui um dispositivo de monitoramento :("
        let msg = "Sem um dispositivo de monitoramento 'Bolt' ativado no seu imóvel, as leituras da quantidade de Kilowatts deverão ser realizadas manualmente."
        
        let refreshAlert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok, criar objetivo", style: .Default, handler: { (action: UIAlertAction) in
            
            self.inputDialog()
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Não quero criar um objetivo", style: .Default, handler: { (action: UIAlertAction) in
            
            print("user canceled the new goal operation")
        }))
        
        self.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    /*
        Show the input dialog to get the first reading for the goal that is going to be created, 
        in case the user doesn't have an active device attached to this location
    */
    internal func inputDialog(){
        
        // create a new reading dialog
        self.popViewController = UpdateReadingViewController(
            nibName: "UpdateReadingViewController",
            bundle: nil
        )
        
        // initialize dialog with pointer to this page, in order to get the inserted value
        self.popViewController.callerViewController = self
        self.popViewController.isFirstReading = true
        self.popViewController.title = "This is a popup view"
        self.popViewController.showInView(
            self.view,
            withImage: UIImage(named: ""),
            withMessage: "",
            animated: true
        )
    }
    
    
    /*
        Confirm with the user if the goal really will be deleted
    */
    internal func deleteGoalDialog(){
        
        let title = "Você tem certeza?"
        let msg   = "Ao deletar o objetivo atual você irá deletar todos os dados de leitura, desde a data inicial até a data final do objetivo."
        
        let refreshAlert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Confirmar", style: .Default, handler: { (action: UIAlertAction) in
            
            self.deleteLocationGoalRel()
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: { (action: UIAlertAction!) in
            
            print("User canceled the delete goal operation.")
        }))
        
        self.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    /*
        Get data from the reading input
    */
    override internal func setReadingValue(input:Double){
        
        if(!self.wasFirstReadingMade){
            
            if(input == -1){
                print("input wasn't successful")
            }else{
                print("ok the user inserted a valid input")
                
                self.firstReading = input
                self.wasFirstReadingMade = true

                self.unlockUI()
            }
        }
    }
    
    
    
    // LOGIC
    /*
        Upsert a Goal object
    */
    internal func upsertGoal(){
        // loading objects
        print("loading values from UI ...")
        
        let desiredVal = Double(self.amountToPay.text!)
        if(desiredVal != nil){
            
            print("desiredValue: \(desiredVal)")
            
            // check if the value to pay is bigger than 0
            if(desiredVal > 0.0){
                
                // getting current date and end date
                let cDate = NSDate()
                let endDate = self.endDate.date
                
                // check if current date is smaller than today
                if(self.endDate.date.isGreaterThanDate(cDate)){
                    
                    // checkd the kwh
                    let kwh = Double(self.kwhVal.text!)
                    if(kwh > 0.0){
                        
                        // UPSERT OPERATIONS
                        if(self.newGoal){
                            
                            // INSERT
                            if(self.selectedReward == nil){
                                print("Warning, reward is nil")
                                
                                self.createGoalWithoutRewardDialog(
                                    desiredVal!,
                                    cDate     :cDate,
                                    endDate   :endDate,
                                    kwh       :kwh!
                                )
                            }else{
                                self.createGoal(
                                    desiredVal!,
                                    cDate     :cDate,
                                    endDate   :endDate,
                                    kwh       :kwh!
                                )
                            }
                        }else{
                        
                            // UPDATE
                            if(DBHelpers.currentGoal != nil){
                            
                                // load updated values
                                var distance:NSNumber = 0.0
                                if let distanceFromGoal:NSNumber = self.dbh.getDistanceOfGoal(){
                                    distance = distanceFromGoal
                                }
                                
                                let watts = self.getDesiredWatts(
                                    kwh!,
                                    desiredAmountToPay: desiredVal!
                                )
                            
                                DBHelpers.currentGoal!.setDesiredValue(desiredVal)
                                DBHelpers.currentGoal!.setEndDate(self.endDate.date)
                                DBHelpers.currentGoal!.setKWH(
                                    Double(self.kwhVal.text!)
                                )
                                DBHelpers.currentGoal!.setDesiredWatts(watts)
                                DBHelpers.currentGoal!.setGoalReward(
                                    self.selectedReward?.getObId()
                                )
                                DBHelpers.currentGoal!.setDistanceFromGoal(distance)
                                
                                self.updateGoal()
                            }
                        }
                        
                    }else{
                        print("Warning, kwh is too small or equal to 0")
                        self.infoWindow("O valor do KW/h deve ser maior do que 0.\nAinda não atingimos o sonho da energia gratuita (:", title: "Atenção", vc: self)
                    }
                }else{
                    print("Warning, current date is greater than last day")
                    self.infoWindow("A data final deve ser maior do que a data atual", title: "Atenção", vc: self)
                }
            }else{
                print("Warning, goal is too small or equal to 0")
                self.infoWindow("O valor a pagar não pode ser iqual a 0 e o aconselhável é que ele seja alcançável, para que as pessoas não se desmotivem com metas impossíveis", title: "Atenção", vc: self)
            }
        }else{
            print("warning, invalid input for field amount to pay")
            self.infoWindow("O campo 'Valor a pagar', não pode estar vazio e deve ser preenchido somente com valores numéricos", title: "Atenção", vc: self)
        }
    }
    
    
    /*
        Create a goal
    */
    internal func createGoal(desiredVal:NSNumber, cDate:NSDate, endDate:NSDate, kwh:NSNumber){
        
        if(DBHelpers.currentDevice != nil){
            
            if let iniWatts:Double = self.firstReading{
                
                // build a new Goal object and save it on the backend
                let goal:Goal = Goal()
                
                goal.setInitialWatts(iniWatts)
                goal.setDesiredValue(desiredVal)
                let watts = self.getDesiredWatts(
                    kwh,
                    desiredAmountToPay: desiredVal
                )
                goal.setDesiredWatts(watts)
                goal.setEndDate(self.endDate.date)
                goal.setGoalReward(self.selectedReward?.getObId())
                goal.setKWH(Double(self.kwhVal
                    .text!))
                goal.setDistanceFromGoal(0)
                
                self.createGoalInBackground(goal)
            }else{
                print("error converting string to int")
                self.infoWindow("Insira um valor numérico para a leitura do relógio", title: "Atenção", vc: self)
            }
        }else{
            
            // ask for first reading
            if(self.firstReading != 0){
                
                if let iniWatts:Double = self.firstReading{
                    
                    // build a new Goal object and save it on the backend
                    let goal:Goal = Goal()
                    
                    goal.setInitialWatts(iniWatts)
                    goal.setDesiredValue(desiredVal)
                    let watts = self.getDesiredWatts(
                        kwh,
                        desiredAmountToPay: desiredVal
                    )
                    goal.setDesiredWatts(watts)
                    goal.setEndDate(self.endDate.date)
                    goal.setGoalReward(self.selectedReward?.getObId())
                    goal.setKWH(Double(self.kwhVal
                        .text!))
                    goal.setDistanceFromGoal(0)
                    
                    self.createGoalInBackground(goal)
                }else{
                    print("error converting string to int")
                    self.infoWindow("Insira um valor numérico para a leitura do relógio", title: "Atenção", vc: self)
                }
            }else{
                print("error getting initial watts value")
                self.infoWindow("Para criar uma meta sem o dispositivo de monitoramento, é preciso fazer a leitura inicial da quantidade de KW/h do seu medidor elétrico.", title: "Faça a leitura inicial", vc: self)
            }
        }
        
    }
    
    
    /*
        Loads the current goal attributes into the UI
    */
    internal func loadCurrentGoal(){
        
        if(DBHelpers.currentGoal != nil){
            
            self.getGoal((DBHelpers.currentGoal?.getObId())!)
            
            // change screen details
            self.title = self.SCREEN_TITLE_UPDATE
        
            self.amountToPay.text  = DBHelpers.currentGoal!.getDesiredValue().stringValue
            self.startDate.text    = NSDate.getReadebleDate(
                (DBHelpers.currentGoal!.getStartingDate())!
            )
            self.endDate.setDate(
                (DBHelpers.currentGoal!.getEndDate())!, animated: true
            )
            self.kwhVal.text  = DBHelpers.currentGoal!.getKWH().doubleValue.format(
                self.DOUBLE_FORMAT
            )
            
            // get goal reward on the backend, if there is one, and load it
            if(self.dbu.STD_UNDEF_STRING != DBHelpers.currentGoal!.getRewardId()){
                
                let query:PFQuery = Reward.query()!
                query.getObjectInBackgroundWithId((DBHelpers.currentGoal!.getRewardId())!){
                    (object, error) -> Void in
                    
                    if(error == nil){
                        print("\nfound reward object")
                        print("load current goal reward for update ...")
                        
                        if let reward:PFObject = object{
                            self.selectedReward = Reward(reward: reward)
                            print("reward: \(self.selectedReward)")
                            
                            self.selectedRewardTitle.text = self.selectedReward?.getRewardTitle()
                            self.selectRewardBtn.setTitle(self.LABEL_BTN_UPDATE_REWARD, forState: .Normal)
                            self.deleteRewardBtn.hidden = false
                        }
                    }else{
                        print("\nerror performing query to get goal")
                    }
                }
            }
        }
        
    }
    
    
    /*
        Get a goal from the backend by using a pointer from the user-goal-device relationship
    */
    internal func getGoal(goalId:String){
        let aux:Goal = Goal()
        let query = aux.selectGoalQuery()
        
        query?.getObjectInBackgroundWithId(goalId){
            (object, error) -> Void in
            
            if(error == nil){
                print("\nfound pointed goal")
                print("load current goal for update ...")
                
                self.currentGoalObj = object
                DBHelpers.currentGoal?.updateGoal(self.currentGoalObj!)
            }else{
                print("\nerror performing query to get goal")
                self.infoWindow("Houve um erro ao tentar obter o objetivo atual para este local", title: "Falha operacional", vc: self)
            }
        }
    }
    
    
    /*
        Create a Goal object in the database
    */
    internal func createGoalInBackground(goal:Goal){
        print("\nsaving object goal in the database ..")
        print("goal: \(goal)")
        
        let goalObj:PFObject = goal.getNewGoalPFObj()
        print("goal obj: \(goalObj)")
        
        goalObj.saveInBackgroundWithBlock{
            (success: Bool, error: NSError?) -> Void in
            
            if(error == nil){
                print("saved new goal successfully.")
                self.createUserGoalLocationRel(goalObj)
            }else{
                print("failed to save goal in database. \(error!.description)")
            }
        }
    }
    
    
    /*
        Creates an user - device - goal relationship
    */
    internal func createUserGoalLocationRel(goal:PFObject){
        print("creating user-device-goal relashionship ...")
        print("Goal: \(goal)")
        print("Current user: \(PFUser.currentUser()!)")
        print("Location: \(DBHelpers.currentLocation)")
        
        let aux:Goal = Goal()
        
        let userGoalLocationRel:PFObject = aux.getUserGoalLocationObj(
            PFUser.currentUser()!,
            location:(DBHelpers.currentLocation?.getPointerToLocationTable())!,
            goal:goal
        )
        
        userGoalLocationRel.saveInBackgroundWithBlock{
            (success:Bool, error) -> Void in
        
            if(error == nil){
                print("relationship created successfuly")
                self.infoWindow("Novo objetivo criado com sucesso", title: "Operação concluída", vc: self)
                
                // update global variables
                let newGoal = Goal(goal: goal)
                DBHelpers.currentGoal = newGoal
                DBHelpers.locationGoals[(DBHelpers.currentLocation?.getObId())!] = newGoal
                
                // update the user interface
                self.currentGoalObj   = goal
                self.newGoal = false
                self.loadCurrentGoal()
                
                // perform changes on the datafile, locally and on the app backend
                DBHelpers.currentLocationData!.addReading(self.firstReading)
                self.dbh.executeInput()
                
                // send the user back to the home page
                self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
            }else{
                print("error creating user-goal-device relationship")
                self.infoWindow("Erro ao criar relacionamento entre o usuário e dispositivo atualmente selecionados e a meta criada", title: "Falha na operação", vc: self)
            }
        }
    }
    
    
    /*
        Update the current goal object in the backend
    */
    internal func updateGoal(){
        print("\nupdating current goal")
        print("current goal: \(DBHelpers.currentGoal)")
        print("goal db: \(self.currentGoalObj)")
        
        DBHelpers.currentGoal!.updateGoal(self.currentGoalObj!)
        self.currentGoalObj!.saveInBackgroundWithBlock {
            (success, error) -> Void in
            
            if(success){
                
                print("goal successfully updated")
                self.infoWindow("Meta atualizada com sucesso", title: "Operação concluída", vc: self)
                    
                self.newGoal = false
                    
                // analyze current goal and send the user to the dashboard screen to through a goal closure depending on the new goal definitions
                self.loadCurrentGoal()
                
                // send the user back to the home page
                self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
            }else{
                print("error updating goal")
                self.infoWindow("Houve um erro de conexão com o servidor", title: "Falha na operação", vc: self)
            }
        }
    }

    
    
    /*
        Delete location - goal relationship
    */
    internal func deleteLocationGoalRel(){
        
        // delete the goal from the user-location-goal relation
        let openedGoalQuery:PFQuery = DBHelpers.currentGoal!.openedGoalForLocation(
            PFUser.currentUser()!,
            location: DBHelpers.currentLocation!
        )
        
        openedGoalQuery.findObjectsInBackgroundWithBlock({
            (goals:[AnyObject]?, error:NSError?) -> Void in
            
            if(error == nil){
                if let goalRelObj = goals?.first{
                    goalRelObj.deleteInBackgroundWithBlock({
                        (success:Bool, error:NSError?) -> Void in
                        
                        if(success){
                            print("deleted location-goal relationship successfuly...")
                            self.deleteGoal()
                        }else{
                            print("there was a problem archiving the current goal")
                            self.infoWindow("Houve um erro ao arquivar o objetivo atual", title:"Falha na operação", vc: self)
                        }
                    })
                }else{
                    print("problem getting user-location object")
                }
            }else{
                print("problem getting user-location object \(error!.description)")
            }
        })
        
    }
    
    
    /*
        Delete goal
    */
    internal func deleteGoal(){
        
        let deleteGoal:PFQuery = Goal.query()!
        deleteGoal.getObjectInBackgroundWithId((DBHelpers.currentGoal?.getObId())!){
            (goalObj: PFObject?, error: NSError?) -> Void in
            
            if(error == nil){
                if let goal:PFObject = goalObj{
                    goal.deleteInBackgroundWithBlock{
                        (success, error:NSError?) -> Void in
                        
                        if(success){
                            print("Goal was successfuly deleted from the app backend relationship")
                            DBHelpers.eraseGoalTraceFromDatafile()
                            
                            // reset UI variables
                            self.resetUI()
                            self.wasFirstReadingMade  = false
                            self.justDeletedGoal      = true
                            self.firstReading         = 0
                            self.title = "Nova meta"
                            
                            self.feu.goToSegueX(self.feu.ID_HOME, obj:self)
                        }else{
                            print("error while deleting goal \(error!.description)")
                        }
                    }
                }
            }else{
                print("error while deleting goal \(error!.description)")
            }
        }
        
    }
    
    
    /*
        Calculates the desired KWS the user want to use until the end of the goal
    */
    internal func getDesiredWatts(kwh:NSNumber, desiredAmountToPay:NSNumber) -> NSNumber{
        
        let watts = desiredAmountToPay.doubleValue / kwh.doubleValue
        
        return NSNumber(double: Double(watts.format("0.3"))!)
    }
    
    
    
    // NAVIGATION
    /*
        Send the user back to the home screen by dismissing the current page from the pages stack
    */
    internal func goHome(){
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    
    /*
        Prepare data to next screen
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if(segue.identifier == self.feu.SEGUE_CHOOSE_REWARD_GOAL){
            let destineVC = (segue.destinationViewController as! RewardsViewController)
            
            destineVC.navigationSource = "outside"
        }
    }
    
    
    /*
        Get selected object from rewards
    */
    @IBAction func unwindWithSelectedReward(segue:UIStoryboardSegue) {
        
        if let rewardPickerVC:RewardsViewController = segue.sourceViewController as? RewardsViewController{
            
            print("selected reward id: \(rewardPickerVC.selectedReward?.getObId())")
            
            if(rewardPickerVC.selectedReward?.getObId() == nil){
                self.selectedRewardTitle.text = self.REWARD_STATUS_NO_SELECTED
            }else{
                self.selectedRewardTitle.text = rewardPickerVC.selectedReward?.getRewardTitle()
                self.selectRewardBtn.setTitle(self.LABEL_BTN_UPDATE_REWARD, forState: .Normal)
                
                self.selectedReward = rewardPickerVC.selectedReward
                self.deleteRewardBtn.hidden = false
            }
        }
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
