//
//  LocationsViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/22/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class DevicesViewController: BaseViewController, iCarouselDataSource, iCarouselDelegate {

    
    
    // VARIABLES
    @IBOutlet weak var homeBtn: UIBarButtonItem!
    @IBOutlet weak var menuBtn: UIBarButtonItem!
    @IBOutlet weak var carousel: iCarousel!
    @IBOutlet weak var newDeviceBtn: UIButton!
    @IBOutlet weak var buyDeviceBtn: UIButton!
    
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils = DBUtils()
    
    internal var allUserDevices   = [Int: Device?]()
    internal var devicesLocations = [String: Location]()
    internal var selectedDevice: Device = Device()
    
    var lastVisualized: Int = 0

    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // UI initialization
        self.customizeNavBar(self)
        self.customizeMenuBtn(self.menuBtn, btnIdentifier: self.feu.ID_MENU)
        self.customizeMenuBtn(self.homeBtn, btnIdentifier: self.feu.ID_HOME)
    }
    
    /*
        Load items into the carousel
    */
    override func awakeFromNib(){
        super.awakeFromNib()
        
        print("\nInitializing devices list ...")
        
        self.allUserDevices =  DBHelpers.userDevices
        
        print("user devices \(self.allUserDevices)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // binds the show menu toogle action implemented by SWRevealViewController to the menu button
        if self.revealViewController() != nil {
            self.menuBtn.target = self.revealViewController()
            self.menuBtn.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // initializes carousel
        self.carousel.dataSource = self
        self.carousel.delegate = self
        self.carousel.type = .Rotary
        self.carousel.decelerationRate = 0.6
        self.carousel.bounces = true
        self.carousel.userInteractionEnabled = true
        
        self.lastVisualized = 1
    }

    
    // UI
    // Carousel
    //---------
    /*
        Number of items in the carousel
    */
    func numberOfItemsInCarousel(carousel: iCarousel) -> Int{
        return self.allUserDevices.count
    }
    
    
    /*
        Load nib into carousel
    */
    func carousel(carousel: iCarousel, viewForItemAtIndex index: Int, reusingView view: UIView?) -> UIView{
        
        var itemView: DeviceCardView
        
        itemView = UIView.loadFromNibNamed("DeviceCard") as! DeviceCardView
        
        //create new view if no view is available for recycling
        if (view == nil){
            
            if let dev = self.allUserDevices[index]{
                if let device:Device =  dev{
                    
                    // insert device status
                    if(device.getStatus()){
                        itemView.deviceStatus.text = "Ativo"
                    }else{
                        itemView.deviceStatus.text = "Inativo"
                    }
                    
                    // insert payment status
                    if(device.getPaymentStatus()){
                        itemView.deviceStatus.text = "Em dia"
                    }else{
                        itemView.deviceStatus.text = "Em atraso"
                    }
                    
                    
                    
                    
                    //itemView.monitoredPlace.text = device.getLocation()
                }else{
                    print("problems to get user device out of list of devices")
                }
            }else{
                print("problem unwrapping device")
            }
        }
        
        return itemView
    }

    
    /*
        Controls the space between the views
    */
    func carousel(carousel: iCarousel, valueForOption option: iCarouselOption, withDefault value: CGFloat) -> CGFloat{
        
        if (option == .Spacing){
            return value * 3.5;
        }
        
        return value
    }

   
    /*
        Identify when the current view changes
    */
    func carouselCurrentItemIndexDidChange(carousel: iCarousel) {
        let currentItem = self.carousel.currentItemIndex + 1
        
        self.lastVisualized = currentItem
        
        // get selected device
        if let dev = self.allUserDevices[currentItem]{
            if let device:Device =  dev{
                self.selectedDevice = device
            }else{
                print("problems to get user device out of list of devices")
            }
        }else{
            print("problem unwrapping device")
        }
    }

    /*
        Selects an item from the carousel
    */
    func carousel(carousel: iCarousel, didSelectItemAtIndex index: Int) {
        print("selected location...")
        self.performSegueWithIdentifier(self.feu.SEGUE_UPSERT_DEVICE, sender: nil)
    }
    
    
    /*
        Display a message if the user has no device
    */
    internal func activateNoDeviceOutlets(){
        print("\nactivating no device UI mode ...")
    }
    
    
    /*
        Delete a device from de list of devices
    */
    internal func deleteDeviceFromList(deviceId:String){
        print("\ndeleting device from list of devices ...")
    }
    

    /*
        User wants to buy a device
    */
    @IBAction func buyDevice(sender: AnyObject) {
        print("\nstarting buy device process ...")
        self.infoWindow("Esta funcionalidade está sendo desenvolvida e estará disponível em breve (:", title: "Funcionalidade em desenvolvimento", vc: self)
    }
    
    
    
    
    
    // LOGIC
    /*
        Loads all the user's devices, including the ones he/she is attached only as a regular user

    internal func reloadUserDevices(){
        print("\ngetting all user's devices from backend ...")
        
        // clean list of available
        //self.allUserDevices.removeAll()
        
        let user:PFUser = PFUser.currentUser()!
        
        let query = Device.getAllUserDevices(user)
        query!.findObjectsInBackgroundWithBlock{
            (objects: [AnyObject]?, error: NSError?) -> Void in
            
            if(error == nil){
                if(objects.count > 0){
                    if let devObj:Array<PFObject> = objects{
                        
                        // iterate through each user_device relationship object
                        for i in 0...(devObj.count - 1){
                            if let obj = devObj[i] as? PFObject {
                                
                                // get the device id out of the user_device relationship
                                if let pointedDevice:PFObject = obj[self.dbu.DBH_REL_USER_ENVIR_DEVICE] as? PFObject{
                                    
                                    if(i == devObj.count){
                                        self.getDeviceWithId(pointedDevice, isLast:true)
                                    }else{
                                        self.getDeviceWithId(pointedDevice, isLast:false)
                                    }
                                }
                            }else{
                                print("error, there was a problem unwrapping device pointer from database")
                            }
                        }
                    }else{
                        print("problems to convert list from cloud into array of PFObjects")
                    }
                }else{
                    print("the user has no active device")
                    self.activateNoDeviceOutlets()
                }
            }else{
                print("error connecting to server \(error?.description)")
            }
        }
    }
     */

    
    /*
        Search for a Device by its id

    internal func getDeviceWithId(devicePointer:PFObject, isLast:Bool){
        print("\ngetting device object by its id ...")
        
        let query = Device.query()
        query!.getObjectInBackgroundWithId(devicePointer.objectId!){
            (fetDev, error) -> Void in
            
            if(error == nil){
                if let device:PFObject = fetDev{
                    let validDev:Device = Device(device:device)
                
                    self.allUserDevices[self.allUserDevices.count] = validDev
                }else{
                    print("error, there was a problem unwrapping device from database")
                }
                
                if(isLast){
                    print("this was the last device to load.")
                    self.carousel.reloadData()
                }
            }else{
                print("error connecting to server \(error?.description)")
                if(isLast){
                    print("this was the last device to load.")
                    self.carousel.reloadData()
                }
            }
        }
        
    }
    */
    
    
    /*
        Get location by id
    */
    internal func getLocationById(locId:String){
        
        // check if the user isn't already related to the location
        PFCloud.callFunctionInBackground("getLocationById", withParameters: [
            "locationId":locId
        ]) {
            (locObj, error) in
                
            if (error == nil){
                print("location \(locObj)")
                    
                if let loc:PFObject = locObj as? PFObject {
                    let location:Location = Location(location:loc)
                    
                    
                }else{
                    print("problems converting getting device location.")
                }
            }else{
                print("\nconnection error: \(error)")
            }
        }
    }
    
    
    
    
    
    // NAVIGATION
    /*
        Go home
    */
    @IBAction func goHome(){
        self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
    }
    
    
    /*
        Send the user to the new device screen
    */
    @IBAction func goToNewDeviceScreen(sender: AnyObject) {
        print("sending user to new device screen ...")
        self.performSegueWithIdentifier(self.feu.SEGUE_UPSERT_DEVICE, sender: nil)
    }
    
    
    /*
        Trheat the devices list with update data from the upsert operation
    */
    @IBAction func unwindAfterDeviceUpsert(segue:UIStoryboardSegue) {
        
        if let newDeviceVC:UpsertDeviceViewController = segue.sourceViewController as? UpsertDeviceViewController{
            if let upsertedDevice = newDeviceVC.upsertedDevice{
                print("call method with the created device \(upsertedDevice)")
            }else{
                print("No beacon was configured")
            }
        }
    }
    
    
    /*
        Get deleted device from the delete device operation
    */
    @IBAction func unwindAfterDeviceDeletion(segue:UIStoryboardSegue) {
        
        if let newDeviceVC:UpsertDeviceViewController = segue.sourceViewController as? UpsertDeviceViewController{
            if let upsertedDevice = newDeviceVC.upsertedDevice{
                print("call method with the created device \(upsertedDevice)")
                self.deleteDeviceFromList(upsertedDevice.getObId())
            }else{
                print("No beacon was configured")
            }
        }
    }
    
    
    
    
    /*
        Prepare data to next screen
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // update device
        if(segue.identifier == self.feu.SEGUE_UPSERT_DEVICE){
            let destineVC = (segue.destinationViewController as! UpsertDeviceViewController)
            destineVC.upsertedDevice = self.selectedDevice
            destineVC.pageMode = self.feu.PAGE_MODE_UPDATE
            
        // create device
        }else if(segue.identifier == self.feu.SEGUE_UPSERT_DEVICE){
            let destineVC = (segue.destinationViewController as! UpsertDeviceViewController)
            destineVC.pageMode = self.feu.PAGE_MODE_CREATE
        }
        
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}



extension UIView {
    
    class func loadFromNibNamed(nibNamed: String, bundle : NSBundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiateWithOwner(nil, options: nil)[0] as? UIView
    }
}
