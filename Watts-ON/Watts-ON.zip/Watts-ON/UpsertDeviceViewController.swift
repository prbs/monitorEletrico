//
//  NewDeviceViewController.swift
//  x
//
//  Created by Diego Silva on 11/15/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class UpsertDeviceViewController: BaseViewController {

    
    // VARIABLES
    // Containers
    @IBOutlet weak var scroller: UIScrollView!
    @IBOutlet weak var contentContainer: UIView!
    @IBOutlet weak var keyConfirmationContainer: UIView!
    
    // Page controller outlets
    @IBOutlet weak var confirmKeyBtn: UIButton!
    @IBOutlet weak var activationKey: UITextField!
    
    // Device info
    @IBOutlet weak var deviceInfo: UITextView!
    @IBOutlet weak var deviceWorkingStatus: UILabel!
    @IBOutlet weak var devicePaymentStatus: UILabel!
    
    // Hardware network settings
    @IBOutlet weak var netwokdId: UITextField!
    @IBOutlet weak var netPass: UITextField!
    @IBOutlet weak var networkStatus: UILabel!
    @IBOutlet weak var networkConfigProgress: UIProgressView!
    @IBOutlet weak var configHardBtn: UIButton!
    
    // Upsert methods
    @IBOutlet weak var upsertBtn: UIButton!
    @IBOutlet weak var deleteBtn: UIButton!
    
    // Controllers
    internal var upsertedDevice:Device?     = nil
    internal var isHardwareConfigured:Bool = false
    internal var pageMode:String           = "create"
    
    internal let dbu:DBUtils = DBUtils()
    
    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // UI
        self.setScroller()
        self.customizeNavBar(self)
        self.feu.applyPlainShadow(self.keyConfirmationContainer)
        self.feu.roundIt(self.confirmKeyBtn, color: self.feu.DARK_WHITE)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("\nUpsert device on \(self.pageMode) mode")
        if(self.pageMode == self.feu.PAGE_MODE_CREATE){
            self.switchToCreateMode()
        }else{
            self.switchToUpdateMode()
            print("device being updated \(self.upsertedDevice)")
        }
    }


    
    // UI
    /*
        Configure the dimensions of the scroller view
    */
    internal func setScroller(){
        self.scroller.userInteractionEnabled = true
        self.scroller.frame = self.view.bounds
        self.scroller.contentSize.height = self.contentContainer.frame.size.height
        self.scroller.contentSize.width = self.contentContainer.frame.size.width
    }
    
    
    /*
        Switch the page outlets to the create mode. I.E, block everything but the activation key container, that is going to be completely showing and activated
    */
    internal func switchToCreateMode(){
        self.confirmKeyBtn.enabled = true
        self.feu.fadeIn(self.confirmKeyBtn, speed:1.0)
        
        // block all other elements
        self.lockPage()
        self.deleteBtn.hidden = true
    }
    
    
    /*
        Switch the page outlets to the update mode. I.E, allow the access to all the fields, but hides the activate key btn
    */
    internal func switchToUpdateMode(){
        self.confirmKeyBtn.enabled = false
        self.feu.fadeOut(self.confirmKeyBtn, speed:1.0)
        
        // allow all other elements
        self.unlockPage()
        self.deleteBtn.hidden = false
    }
    
    
    /*
        Unlock fields that are needed to create a device
    */
    internal func unlockPage(){
        print("\nunlocking UI for creation ...")
        
        self.deviceInfo.editable = false
        self.deviceWorkingStatus.enabled = false
        self.devicePaymentStatus.enabled = false
        self.netwokdId.enabled = false
        self.netPass.enabled = false
        self.networkStatus.enabled = false
        self.configHardBtn.enabled = false
        self.upsertBtn.enabled = false
        self.deleteBtn.enabled = false
    }
    
    
    /*
        Lock fields that are needed to create a device
    */
    internal func lockPage(){
        print("\nlocking UI for creation ...")
        
        self.deviceInfo.editable = true
        self.deviceWorkingStatus.enabled = true
        self.devicePaymentStatus.enabled = true
        self.netwokdId.enabled = true
        self.netPass.enabled = true
        self.networkStatus.enabled = true
        self.configHardBtn.enabled = true
        self.upsertBtn.enabled = true
        self.deleteBtn.enabled = true
    }
    
    
    
    /*
        Start the activation key validation process
    */
    @IBAction func confirmActivationkey(sender: AnyObject) {
        
        if let key:String = self.activationKey.text{
            self.validadeKey(key)
        }else{
            print("problems getting device key as String")
            self.infoWindow("Insira uma chave válida", title: "Atenção", vc: self)
        }
    }
    
    
    
    
    /*
        Validate network information and try to connect to the device
    */
    @IBAction func configureNetwork(sender: AnyObject) {
        self.validateNetworkInfo()
    }
    
    
    /*
        Try to delete the device
    */
    @IBAction func deleteDevice(sender: AnyObject) {
        self.deleteDevice()
    }
    
    
    
    // LOGIC
    /*
        Validate a device activation key. if it is ok, unlock the page fields for creation
    */
    internal func validadeKey(key:String){
        print("\nvalidating activation key ...")
        
        // get id
        if let id:String = self.activationKey.text{
            
            // check device in the app backend
            PFCloud.callFunctionInBackground("isDevActivationKeyValid", withParameters: [
                "actKey":id
            ]) {
                (answer, error) in
                        
                if (error == nil){
                    if let result:Int = answer as? Int{
                        print("result \(result)")
                                
                        if(result == 0){
                            // allow user to create a new device
                            self.unlockPage()
                            
                        }else if(result == 1){
                            self.infoWindow("Chave de ativação inválida, verifique todos os caracteres da chave atentamente", title: "Chave inválida", vc: self)
                        }else{
                            self.infoWindow("Erro ao validar chave de ativação", title: "Erro operacional", vc: self)
                        }
                    }else{
                        print("unkown error: \(error)")
                        self.infoWindow("Erro ao validar chave de ativação", title: "Erro operacional", vc: self)
                    }
                }else{
                    print("\nerror: \(error)")
                    self.infoWindow("Erro ao validar chave de ativação", title: "Erro operacional", vc: self)
                }
            }
            
        }else{
            print("invalid key")
            self.infoWindow("Chave inválida", title: "Atenção", vc: self)
        }
    }
    
    
    
    /*
        Validate the information being insert to a Device object, if the data is valid call the
        upsert function with a valid Device Object, otherwise alert user that the inserted data
        is invalid
    */
    internal func validateInfoForDevice(){
        print("\nvalidating info for a Device object ...")
        
        let device:Device = Device()
        
        if(self.pageMode == self.feu.PAGE_MODE_CREATE){
            self.createDevice(device)
        }else{
            self.updateDevice(device)
        }
    }
    
    
    /*
        Clean data to the device configuration method
    */
    internal func validateNetworkInfo(){
        print("\nvalidating network data ...")
        
        if((self.netwokdId.text != "") && (self.netPass.text != "")){
            if let netId:String = self.netwokdId.text{
                if let netPass:String = self.netPass.text{
                    self.saveNetworkInfoOnDevice(netId, pass:netPass)
                }
            }else{
                print("problems to get network id")
            }
        }else{
            self.infoWindow("O identificador de uma rede acessível e senha devem ser informados", title: "Aviso", vc: self)
        }
    }
    
   
    /*
        Try to configure the device with the network credentials
    */
    internal func saveNetworkInfoOnDevice(netId:String, pass:String){
        print("\ntrying to configure device with the network credentials 'id'\(netId), 'pass'\(pass) ...")
    }
    
    
    /*
        Delete device
    */
    internal func deleteDevice(){
        print("\ntrying to delete the selected device ...")
        
        if let device:Device = self.upsertedDevice{
            
            // get the device id
            let id = device.getObId()
            
            // if the id is valid
            if(id != self.dbu.STD_UNDEF_STRING){
                
                PFCloud.callFunctionInBackground("deleteDeviceById", withParameters: [
                    "deviceId":id
                ]) {
                    (answer, error) in
                    
                    if (error == nil){
                        if let result:Int = answer as? Int{
                            print("result \(result)")
                            
                            if(result == 0){
                                self.infoWindow("Dispositivo deletado com sucesso", title: "Operação concluída", vc: self)
                                
                                // delete device trace from system
                                self.deleteDeviceDependencies()
                            }else if(result == 1){
                                self.infoWindow("Não foi possível deletar o dispositivo selecionado", title: "Falha ao deletar dispositivo", vc: self)
                            }else{
                                self.infoWindow("Erro desconhecido", title: "Falha ao deletar dispositivo", vc: self)
                            }
                        }else{
                            print("unkown error: \(error)")
                        }
                    }else{
                        print("\nerror: \(error)")
                        self.infoWindow("Não foi possível adicionar o usuário como visitante do local selecionado devido a uma falha do sistema", title: "Erro operacional", vc: self)
                    }
                }
            }else{
                print("device id is undefined ...")
                self.infoWindow("A operação não pode ser concluída, pois a id do dispositivo é inválida.", title: "Falha operacional", vc: self)
            }
        }else{
            print("weird, selected device seems to be invalid")
            self.infoWindow("A operação não pode ser concluída, pois o dispositivo é inválido.", title: "Falha operacional", vc: self)
        }
    }
    

    
    /*
        Create a device after its data is valid
    */
    internal func createDevice(device:Device){
        print("trying to create a device ...")
        
        // save device in the app backend
        device.saveInBackground()
        
        self.upsertedDevice = device
        self.performSegueWithIdentifier(self.feu.SEGUE_UNWIND_AFTER_DEV_UPS, sender: nil)
    }
    
    
    /*
        Update a device
    */
    internal func updateDevice(device:Device){
        print("trying to update a device ...")
        
        // get the device id
        let id:String = device.getObId()
        
        // if the id is valid
        if(id != self.dbu.STD_UNDEF_STRING){
            
            // get the device on the app backend
            let query:PFQuery = Device.query()!
            query.getObjectInBackgroundWithId(id){
                (deviceObj: PFObject?, error: NSError?) -> Void in
                
                if error != nil {
                    print(error)
                } else if let dev = deviceObj {
                    // pass dev PFObject as reference to the update device method, loading all information from the updated device into the dev PFObject
                    device.getUpdatedDeviceObject(dev)
                    
                    // save device in the app backend
                    dev.saveInBackground()
                    
                    self.performSegueWithIdentifier(self.feu.SEGUE_UNWIND_AFTER_DEV_UPS, sender: nil)
                }
            }
        }else{
            print("device id is undefined ...")
            self.infoWindow("A operação não pode ser concluída, pois a id do dispositivo é inválida.", title: "Falha operacional", vc: self)
        }
    }
    
    

    /*
        Delete the selected device and its dependencies from the system
    */
    internal func deleteDeviceDependencies(){
        print("\ndeleting device and dependencies trace from system ...")
        
        
    }
    
    
    
    
    // NAVIGATION
    
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
