//
//  TesteViewController.swift
//  Watts-ON
//
//  Created by Paulo Barbosa on 16/10/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class TesteViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
