//
//  PlaceDetailsViewController.swift
//  x
//
//  Created by Diego Silva on 11/13/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class PlaceDetailsViewController: BaseViewController {

    
    
    // VARIABLES
    // Containers
    @IBOutlet weak var locationTypeImgContainer: UIView!
    @IBOutlet weak var contentContainer: UIView!
    @IBOutlet weak var header: UIView!
    @IBOutlet weak var scroller: UIScrollView!
    @IBOutlet weak var adminImgContainer: UIImageView!
    
    // Regular outlets
    @IBOutlet weak var updateBtn: UIButton!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var visitorInfoBtn: UIButton!
    
    @IBOutlet weak var locationName: UILabel!
    @IBOutlet weak var adminName: UILabel!
    @IBOutlet weak var locationType: UILabel!
    @IBOutlet weak var locationAddress: UILabel!
    @IBOutlet weak var createdAt: UILabel!
    @IBOutlet weak var deviceInfo: UILabel!
    @IBOutlet weak var locTypeImg: UIImageView!
    @IBOutlet weak var sharedKey: UILabel!
    @IBOutlet weak var sharedKeyLabel: UIImageView!
    
    internal var deleteAsAdmin:Bool = false
    internal var location:Location  = Location()
    
    // CONSTANTS
    internal let dbu:DBUtils   = DBUtils()
    internal let dbh:DBHelpers = DBHelpers()
    internal let selector:Selector = Selector("goHome")



    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // UI
        self.setScroller()
        self.feu.roundIt(self.locationTypeImgContainer, color:self.feu.LIGHT_WHITE)
        self.feu.roundCorners(self.adminImgContainer, color: self.feu.SUPER_LIGHT_WHITE)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let location = DBHelpers.currentLocation{
            
            self.location = location
            
            // UI
            //assign button to navigationbar
            self.navigationItem.leftBarButtonItem = self.feu.getHomeNavbarBtn(self.selector, parentVC: self)
            self.setUI(self.location)
            self.feu.roundIt(self.visitorInfoBtn, color:self.feu.LIGHT_WHITE)
            
            // Data
            self.loadUIWithCurrentLocationData()
        }else{
            print("problem unwrapping current location")
        }
    }



    // UI
    /*
        Configure the dimensions of the scroller view
    */
    internal func setScroller(){
        self.scroller.userInteractionEnabled = true
        self.scroller.frame = self.view.bounds
        self.scroller.contentSize.height = self.contentContainer.frame.size.height
        self.scroller.contentSize.width = self.contentContainer.frame.size.width
    }
    
    
    /*
        Change the UI functionalities and appearence depending on the user location relationship
        if the user is de location admin, allow editing and deletion, otherwise doesn't
    */
    internal func setUI(location:Location){
        print("setting UI according to the user location relationship ...")
        
        if let locAdm:PFUser = location.getLocationAdmin(){
            if(locAdm.objectId == PFUser.currentUser()?.objectId){
                print("user is location admin, allowing operations ...")
                
                self.visitorInfoBtn.hidden  = true
                self.visitorInfoBtn.enabled = false
                
                self.deleteBtn.hidden = false
                self.deleteBtn.enabled = true
                
                self.updateBtn.hidden = false
                self.updateBtn.enabled = true
            }else{
                print("current user isn't location admin")
                
                self.visitorInfoBtn.hidden  = false
                self.visitorInfoBtn.enabled = true
                
                self.deleteBtn.hidden = false
                self.deleteBtn.enabled = true
                
                self.updateBtn.hidden = true
                self.updateBtn.enabled = false
            }
        }else{
            print("problem getting location admin")
        }
    }
    
    
    /*
        Load UI with data of the current location
    */
    internal func loadUIWithCurrentLocationData(){
        print("\nloading UI with current location data ...")
        
        // location name
        if let locName:String = self.location.getLocationName(){
            self.locationName.text = locName
        }else{
            self.locationName.text = "Nome do local"
        }
        
        // location type
        if let locType:String = self.location.getLocationType(){
            if(locType != self.dbu.STD_UNDEF_STRING){
                self.locationType.text = locType
                
                if(locType == self.feu.LOCATION_TYPES[0]){
                    self.locTypeImg.image = UIImage(named: self.feu.IMAGE_LOC_TYPE_RESIDENCIAL)
                    self.feu.fadeIn(self.locTypeImg, speed: 0.7)
                }else if(locType == self.feu.LOCATION_TYPES[1]){
                    self.locTypeImg.image = UIImage(named: self.feu.IMAGE_LOC_TYPE_BUSINESS)
                    self.feu.fadeIn(self.locTypeImg, speed: 0.7)
                }
            }else{
                self.locationType.text = "O tipo do local não foi selecionado"
            }
        }else{
            self.locationType.text = "Tipo do local"
        }
        
        // location adm
        print("location admin \(self.location.getLocationAdmin())")
        
        if let locAdm:User = self.location.getLocationAdmin() as? User{
                
            // get admin name
            if(locAdm.getUserName() != self.dbu.STD_UNDEF_STRING){
                self.adminName.text = locAdm.getUserName()
            }else{
                self.adminName.text = "Nome do administrador"
            }
                
            // get admin picture
            if let picture = locAdm.getUserPicUIImage(){
                self.adminImgContainer.image = picture
            }else{
                if let picFile = locAdm.getUserPicture(){
                    picFile.getDataInBackgroundWithBlock({
                        (imageData: NSData?, error: NSError?) -> Void in
                        
                        if (error == nil) {
                            let image = UIImage(data:imageData!)
                            self.adminImgContainer.image = image
                        }
                    })
                }else{
                    print("problem getting user picture file")
                    self.adminImgContainer.image = UIImage(named:self.feu.IMAGE_USER_PLACEHOLDER)
                }
            }
            self.feu.fadeIn(self.adminImgContainer, speed: 1.0)
            
            // show delete btn
            self.deleteBtn.enabled = true
            self.feu.fadeIn(self.deleteBtn, speed: 0.5)
            
            // if current user is the location admin
            if(DBHelpers.isUserLocationAdmin){
                self.sharedKey.text = self.location.getLocationSharedId()
                
                // show location shared key
                self.feu.fadeIn(self.sharedKeyLabel, speed:0.5)
                self.feu.fadeIn(self.sharedKey, speed: 1.0)
                
                // show update btn
                self.updateBtn.enabled = true
                self.feu.fadeIn(self.updateBtn, speed: 0.5)
                
                // hide visitor user's info btn
                self.visitorInfoBtn.enabled = false
                self.feu.fadeOut(self.visitorInfoBtn, speed: 0.5)
                
                self.deleteAsAdmin = true
            }else{
                // show visitor user's info btn
                self.visitorInfoBtn.enabled = true
                self.feu.fadeIn(self.visitorInfoBtn, speed: 0.5)
                
                self.deleteAsAdmin = false
            }
        }
        
        // location address
        if let locAddress:String = self.location.getLocationAddress(){
            if(locAddress != self.dbu.STD_UNDEF_STRING){
                self.locationAddress.text = locAddress
            }else{
                self.locationAddress.text = "Endereço não definido"
            }
        }else{
            self.locationAddress.text = "Endereço"
        }
        
        // location monitoring device
        if let locDev:Device = self.location.getLocationDevice(){
            if let devInfo:String = locDev.getDeviceInfo(){
                if(devInfo != self.dbu.STD_UNDEF_STRING){
                    self.deviceInfo.text = devInfo
                }else{
                    self.deviceInfo.text = "Dispositivo de monitoramento sem nome"
                }
            }else{
                self.deviceInfo.text = "Descrição do dispositivo"
            }
        }else{
            self.deviceInfo.text = "Este local não está usando um dipositivo"
        }
            
        // location creation date
        PFCloud.callFunctionInBackground("getLocationCreationDate", withParameters: [
            "locationId": location.getObId()
        ]) {
            (date, error) in
                    
            if (error == nil){
                if let date:NSDate = date as? NSDate{
                    let dateLabel:String = "Criado em " + date.formattedWith(self.feu.DATE_FORMAT)
                        
                    self.createdAt.text = dateLabel
                }else{
                    print("failed to get location creation date")
                }
            }
        }
    }
    
    
    
    /*
        Explain what the user can do on this page
    */
    @IBAction func showPageInfoForVisitor(sender: AnyObject) {
        self.infoWindow("Exemplo de ações que você, como visitante, pode realizar em um local: \n\nDeletá-lo de sua lista de locais\n\nRealizar leituras, caso ele não possua um dispositivo de monitoramento\n\nVisualizar sua lista de moradores e etc.", title: "Informações", vc: self)
    }
    
    
    
    
    /*
        Try to delete the current place
    */
    @IBAction func deletePlace(sender: AnyObject) {
        print("\ntrying to delete the selected place ...")
        
        self.deleteCurrentLocation()
    }
    
    
    
    // LOGIC
    /*
        Delete the current location from the app backend and from the global controller variables,
        after the operation is complete send the user back to the home screen
    */
    internal func deleteCurrentLocation(){
        print("\ndeleting current location trace locally and on the app backend ...")
        
        if let location = DBHelpers.currentLocation{
            
            // delete user location relationship
            if(self.deleteAsAdmin){
                // deletes Location trace on the app backend
                self.deleteLocationTrace()
            }else{
                // deletes only the User_Location relationship
                self.dbh.deleteUserLocationRels(location)
            }
            
            // delete location trace from global controller variables
            DBHelpers.userLocations.removeValueForKey(DBHelpers.userLocations.count - 1)
            
            if let dfManager = DBHelpers.locationDataObj[location.getObId()]{
                dfManager?.deleteDeviceHistoryFile()
            }else{
                print("problem getting location datafile manager")
            }
            DBHelpers.locationDataObj.removeValueForKey(location.getObId())
            
            DBHelpers.locationGoals.removeValueForKey(location.getObId())
            DBHelpers.alertMsgController.removeValueForKey(location.getObId())
            
            // if the user deleted his/her only location, kick the user out of the system
            if(DBHelpers.userLocations.count == 0){
                print("refreshing system to start point ...")
                
                DBHelpers.currentLocation = nil
                DBHelpers.isUserLocationAdmin = false
                DBHelpers.currentLocationData = nil
                DBHelpers.currentDevice = nil
                DBHelpers.currentGoal = nil
                DBHelpers.currentLocatinIdx = -1
                
                DBHelpers.lockedSystem = true
            }
                
            // select the previous location
            else{
                self.selectAnotherLocation()
            }
            
            // redirect user to home screen and reload it
            self.performSegueWithIdentifier(self.feu.SEGUE_UNWIND_AFTER_LOC_DEL, sender: nil)
        }else{
            print("problems getting location out of DBHelpers.currentLocation()")
        }
    }
    
    
    /*
        Delete location trace on the app backend
    */
    internal func deleteLocationTrace(){
        self.dbh.deleteUserLocationRels(location)
        self.dbh.deleteGoalLocationRel(location)
        self.dbh.deleteReportLocationRel(location)
        self.dbh.deleteDeviceLocationRel(location)
        self.dbh.deleteBeaconLocationRel(location)
        self.dbh.deleteUserLocation(location)
    }
    
    
    
    /*
        Select another available location from the user's location list, and load the global 
        controller variables and dependencies with its data
    */
    internal func selectAnotherLocation(){
        print("selecting another available location as current location ...")
    
        if let selLoc:Location = DBHelpers.userLocations[DBHelpers.currentLocatinIdx - 1]{
            DBHelpers.currentLocation     = selLoc
            DBHelpers.isUserLocationAdmin = true
    
            // get selected location datafile manager
            if let datafileManager:Readings = DBHelpers.locationDataObj[selLoc.getObId()]!{
                DBHelpers.currentLocationData = datafileManager
            }else{
                print("problem getting the datafileManger object of the selected location")
            }
    
            // get selected location device, if there is one
            if let device:Device = selLoc.getLocationDevice(){
                DBHelpers.currentDevice = device
            }else{
                print("the selected location has no device")
            }
    
            // get selected location goal, if there is one
            if let locationGoals = DBHelpers.locationGoals as? [String:Goal]{
                if let goal:Goal = locationGoals[selLoc.getObId()]{
                    DBHelpers.currentGoal = goal
                }else{
                    print("the selected location has no goal")
                }
            }else{
                print("list of goals is empty")
            }
    
            DBHelpers.currentLocatinIdx--
        }else{
            print("problems getting selected location")
        }
    }
    
    
    
    // NAVIGATION
    /*
        Send the user back to the home screen by dismissing the current page from the pages stack
    */
    internal func goHome(){
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    
    /*
        Redirect the user to the updatePlace screen
    */
    @IBAction func goToUpdatePlace(sender: AnyObject) {
        print("\ngoing to the new place screen on the update mode ...")
        self.performSegueWithIdentifier(self.feu.SEGUE_LOCATION_UPDATE, sender: nil)
    }
    
    
    /*
        Get updated information back from the update screen
    */
    @IBAction func unwindWithUpdatedLocation(segue:UIStoryboardSegue) {
        if let upsertLocationVC:UpsertPlaceViewController = segue.sourceViewController as? UpsertPlaceViewController{
            
            if let location:Location = upsertLocationVC.location{
                self.location = location
                self.loadUIWithCurrentLocationData()
            }else{
                print("problem getting updated location data from the UpserPlace page")
            }
        }
    }
    
    
    
    /*
        Prepare data to next screen
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == self.feu.SEGUE_LOCATION_UPDATE){
            let destineVC = (segue.destinationViewController as! UpsertPlaceViewController)
            destineVC.source   = "details"
            destineVC.location = DBHelpers.currentLocation
        }
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
