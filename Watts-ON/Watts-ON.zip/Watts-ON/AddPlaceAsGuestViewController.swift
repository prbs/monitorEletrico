//
//  CadUsuKeyViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/24/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class AddPlaceAsGuestViewController: BaseViewController {

    
    // VARIABLES
    @IBOutlet weak var sharedKey: UITextField!
    @IBOutlet weak var doubtBtn:UIButton!
    @IBOutlet weak var info: UILabel!
    
    internal let dbu:DBUtils = DBUtils()
    internal var tempUserConfirmed:Bool = false
    internal var loadedLocation:Location = Location()
    
    // Alerts
    internal var confirmLocationDialog : ConfirmPlaceViewController!
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()

        self.sharedKey.delegate = self
        self.feu.roundIt(self.doubtBtn, color:self.feu.LIGHT_GREY)
    }

    
    
    // UI
    @IBAction func confirmKey(sender: AnyObject) {
        print("\nconfirming shared key ...")
        self.validateSharedKey()
    }
    
    
    /*
        Show information outlet
    */
    @IBAction func showInfo(sender: AnyObject) {
        if(self.info.hidden){
            self.feu.fadeIn(self.info, speed: 0.6)
        }else{
            self.feu.fadeOut(self.info, speed: 1.0)
        }
    }
    
    
    
    // LOGIC
    internal func validateSharedKey(){
        
        if let key:String = self.sharedKey.text{
            print("\ntrying to validate the location key \(key) ...")
            
            PFCloud.callFunctionInBackground("isLocationKeyValid", withParameters: [
                "locationId":key
            ]) {
                (object, error) in
                    
                if (error == nil){
                    print("locs \(object)")
                    
                    if let loc:PFObject = object as? PFObject {
                        let location:Location = Location(location:loc)
                        
                        // get location admin pointer
                        if let locAdmPointer:PFUser = location.getLocationAdmin(){
                            self.getLocationAdmin(location, locObj:loc, admPointer:locAdmPointer)
                        }else{
                            print("problem getting out of the resultant array")
                        }
                    }else{
                        print("problems converting results into array of locations.")
                        self.infoWindow("Se certifique de que a chave está correta.", title: "Local não encontrado", vc: self)
                    }
                }else{
                    print("\nerror: \(error)")
                }
            }
            
        }else{
            print("failed to unwrap shared key")
        }
        
    }
    
    
    /*
        Get the location admin information using its id
    */
    internal func getLocationAdmin(location:Location, locObj:PFObject, admPointer:PFUser){
        print("\ntrying to get location admin \(admPointer)")
        
        if let id:String = admPointer.objectId{
            
            // get location admin
            let query:PFQuery = User.query()!
            query.getObjectInBackgroundWithId(id){
                (user: PFObject?, error: NSError?) -> Void in
                print("admin user found \(user)")
                
                if(error == nil){
                    if let admin:PFUser = user as? PFUser {
                        
                        // check if the current isn't already the location admin
                        if(PFUser.currentUser()?.objectId != admin.objectId){
                            let locAdmin:User = User(user:admin)
                            
                            print("checking if the user is alredy related to the location ...")
                            self.isUserRelatedToLocation(location, locObj:locObj, adm:locAdmin)
                        }else{
                            print("user is already the location admin")
                            self.infoWindow("Você já está cadastrado como o administrador deste local", title: "Operação não pode ser concluída", vc: self)
                        }
                    }else{
                        print("problems unwrapping admin user PFObject")
                        self.infoWindow("A operação não pode ser concluída devido a uma falha ocorrida tentando encontrar o administrador do local", title: "Erro operacional", vc: self)
                    }
                } else {
                    print("problems to get location admin \(error)")
                    self.infoWindow("A operação não pode ser concluída devido a uma falha ocorrida tentando encontrar o administrador do local", title: "Administrador não encontrado", vc: self)
                }
            }
        }else{
            print("problems getting admin id")
        }
    }
    
    
    /*
        Check if the user isn't already related to a location
    */
    internal func isUserRelatedToLocation(location:Location, locObj:PFObject, adm:User){
        
        // check if the user isn't already related to the location
        PFCloud.callFunctionInBackground("isUserRelatedToLocation", withParameters: [
            "locationId":locObj.objectId!,
            "userId"    :PFUser.currentUser()!.objectId!
        ]) {
            (result, error) in
            
            if (error == nil){
                print("location \(locObj)")
                        
                if let result:Int = result as? Int {
                    if(result == 0){
                        self.infoWindow("Você já está associado a este ambiente", title: "Operação inválida", vc: self)
                    }else if(result == 1){
                        print("user is not related to location, showing confirmation dialog ...")
                                
                        self.createConfirmationDialog(location, locObj:locObj, adm:adm)
                    }else{
                        self.infoWindow("Não foi possível te adicionar a este ambiente", title: "Erro operacional", vc: self)
                    }
                }else{
                    print("problems converting results into array of locations.")
                    self.infoWindow("Não foi possível te adicionar a este ambiente", title: "Erro operacional", vc: self)
                }
            }else{
                print("\nerror: \(error)")
                self.infoWindow("Não foi possível te adicionar a este ambiente", title: "Erro operacional", vc: self)
            }
        }
    }
    
    
    /*
        Create a confimation dialog ask the user if he/she really wants to be part of the selected
        location
    */
    internal func createConfirmationDialog(location:Location, locObj:PFObject, adm:User){
        
        // create a new reading dialog
        self.confirmLocationDialog = ConfirmPlaceViewController(
            nibName: "ConfirmLocation",
            bundle: nil
        )
        
        // initialize dialog with pointer to this page, in order to get the inserted value
        self.confirmLocationDialog.callerViewController = self
        self.confirmLocationDialog.title = "This is a popup view"
        self.confirmLocationDialog.showInView(
            self.view,
            animated  : true,
            location  : location,
            locObj    : locObj,
            admin     : adm
        )
    }
    
    
    
    
    // NAVIGATION
    internal func sendUserHomeAfterJoinOp(){
        print("join operation was successful, sending the user home ...")
        
        self.confirmLocationDialog.removeAnimate()
        
        // if this is the first location of the user, unlock the system
        if(DBHelpers.lockedSystem){
            DBHelpers.lockedSystem = false
        }
        
        self.performSegueWithIdentifier(self.feu.SEGUE_UNWIND_AFTER_NEW_LOC, sender: self)
    }
    

    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
