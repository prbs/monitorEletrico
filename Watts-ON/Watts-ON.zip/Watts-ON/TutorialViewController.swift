//
//  ViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class TutorialViewController: UIViewController, iCarouselDataSource, iCarouselDelegate {
    
    
    // VARIABLES
    @IBOutlet weak var carousel: iCarousel!
    
    @IBOutlet weak var progress1: UIImageView!
    @IBOutlet weak var progress2: UIImageView!
    @IBOutlet weak var progress3: UIImageView!
    @IBOutlet weak var progress4: UIImageView!
    @IBOutlet weak var progress5: UIImageView!
    @IBOutlet weak var progress6: UIImageView!
    
    internal let feu:FrontendUtilities = FrontendUtilities()
    internal var lastVisualized: Int = 0
    internal let FILLED_CIRCLE = "circle-filled.png"
    internal let EMPTY_CIRCLE  = "circle-empty.png"
    internal let tutoImages:Array<String> = [
        "tuto-img-1.png",
        "tuto-img-2.png",
        "tuto-img-3.png",
        "tuto-img-4.png",
        "tuto-img-5.png",
        "tuto-img-6.png"
    ]
    internal let tutoContent:Array<String> = [
        "Faça o cadastro como administrador ou usuário comum de um ambiente.",
        "Se você quer se tornar usuário comum, tenha a chave de compartilhamento do ambiente.",
        "Se você quer se tornar o dono de um novo ambiente, crie um novo ambiente.",
        "Possui um dispositivo? Adicione a chave de ativação do seu dispositivo",
        "Finalize o cadastro e após a ativação do ambiente, configure seu dispositivo.",
        "Pronto, comece a usar a tecnologia para economizar recursos e aprender com Bolt."
    ]
    
    
    // INITIALIZERS
    override func awakeFromNib(){
        super.awakeFromNib()
    }
    
    override func viewDidAppear(animated: Bool) {
        // testing area
    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        carousel.type = .Linear
        carousel.bounces = false
        
        self.progress1.image = UIImage(named:self.FILLED_CIRCLE)
        self.lastVisualized = 1
    }
    
    
    // UI
    func carousel(carousel: iCarousel, viewForItemAtIndex index: Int, reusingView view: UIView?) -> UIView{
        
        if(index != self.tutoImages.count - 1){
            var itemView: TutoPage
            
            //create new view if no view is available for recycling and fill its content
            itemView = UIView.loadFromNibNamed("TutoPage") as! TutoPage
            itemView.tutoView.image = UIImage(named: self.tutoImages[index])
            itemView.tutoInfo.text  = self.tutoContent[index]
            
            return itemView
        }else{
            var itemView: TutoLastPage
            
            //create new view if no view is available for recycling and fill its content
            itemView = UIView.loadFromNibNamed("TutoLastPage") as! TutoLastPage
            itemView.parentVC = self
            
            return itemView
        }
        
    }
    
    
    func carousel(carousel: iCarousel, valueForOption option: iCarouselOption, withDefault value: CGFloat) -> CGFloat{
        
        if (option == .Spacing){
            return value * 1.0
        }
        
        return value
    }

    
    /*
        Identify when the current view changes
    */
    func carouselCurrentItemIndexDidChange(carousel: iCarousel) {
        
        let currentItem = self.carousel.currentItemIndex
        self.setProgress(currentItem)
        self.lastVisualized = currentItem
    }
    
    
    /*
        Set the current selected page on the progress view images
    */
    internal func setProgress(currentPage:Int){
        
        self.resetProgressIndicators()
        
        if(currentPage < 6){
            switch (currentPage){
                case 0:
                    self.progress1.image = UIImage(named:self.FILLED_CIRCLE)
            
                case 1:
                    self.progress2.image = UIImage(named:self.FILLED_CIRCLE)
            
                case 2:
                    self.progress3.image = UIImage(named:self.FILLED_CIRCLE)
            
                case 3:
                    self.progress4.image = UIImage(named:self.FILLED_CIRCLE)
            
                case 4:
                    self.progress5.image = UIImage(named:self.FILLED_CIRCLE)
            
                case 5:
                    self.progress6.image = UIImage(named:self.FILLED_CIRCLE)
            
                default:
                    print("current page didn't match any available page of the tutorial")
            }
        }
    }
    
    /*
        Reset the progress indicators to default mode
    */
    internal func resetProgressIndicators(){
        self.progress1.image = UIImage(named:self.EMPTY_CIRCLE)
        self.progress2.image = UIImage(named:self.EMPTY_CIRCLE)
        self.progress3.image = UIImage(named:self.EMPTY_CIRCLE)
        self.progress4.image = UIImage(named:self.EMPTY_CIRCLE)
        self.progress5.image = UIImage(named:self.EMPTY_CIRCLE)
        self.progress6.image = UIImage(named:self.EMPTY_CIRCLE)
    }
    
    
    
    // LOGIC
    func numberOfItemsInCarousel(carousel: iCarousel) -> Int{
        return 6
    }

    
    
    // NAVIGATION
    @IBAction func goHome(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_HOME, sender: self)
    }


}
