//
//  TutoPage.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/24/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class TutoPage: UIView {

    // VARIABLES
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var tutoView: UIImageView!
    @IBOutlet weak var tutoInfo: UILabel!

}
