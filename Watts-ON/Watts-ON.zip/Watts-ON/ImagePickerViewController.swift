//
//  ImagePickerViewController.swift
//  x
//
//  Created by Diego Silva on 11/22/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class ImagePickerViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    
    // VARIABLES AND CONSTANTS
    internal var feu:FrontendUtilities = FrontendUtilities()
    
    internal var callerVC:UIViewController? = nil
    internal var imagePicker = UIImagePickerController()
    internal var pffileImg:PFFile? = nil
    internal var source:String = ""
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    
    // SETTERS
    internal func setCallerVC(viewController:UIViewController, source:String){
        self.source = source
        self.callerVC = viewController
    }
    
    
    /*
        Set the selected picture PFFile variable, the one that is going to be saved on the app 
        backend
    */
    internal func setSelectedImageFile(imgFile:PFFile){
        
        // decide who is the caller view controller and set its target image variable
        if(self.source == self.feu.ID_PROFILE){
            if let profileVC:PerfilViewController = self.callerVC as? PerfilViewController{
                
                // set caller view controller image attribute
                profileVC.setChosenImgFile(imgFile)
            }else{
                print("problem gettin callerVC as PerfilViewController")
            }
        }else{
            print("different VC")
        }
        
    }
    
    
    /*
        Set the actual image of the target element, let's say the picker picture button image.
    */
    internal func setTargetViewImage(img:UIImage){
        
        // decide who is the caller view controller and set its target image variable
        if(self.source == self.feu.ID_PROFILE){
            if let profileVC:PerfilViewController = self.callerVC as? PerfilViewController{
                
                // set caller view controller image attribute
                profileVC.setChosenImg(img)
            }else{
                print("problem gettin callerVC as PerfilViewController")
            }
        }else{
            print("different VC")
        }
    }
    
    
    
    
    
    // IMAGE PICKER METHODS
    /*
        Select a new picture for the reward from the user's camera roll
    */
    internal func selectPictureFromRoll(sender: AnyObject) {
        print("\nselect new reward picture from camera roll")
        
        if(self.source == self.feu.ID_PROFILE){
            if let profileVC:PerfilViewController = self.callerVC as? PerfilViewController{
                
                // image picker initialization
                profileVC.imagePicker.delegate = self
                profileVC.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
                profileVC.imagePicker.allowsEditing = false
                
                if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum){
                    print("selecting image from roll ...")
                    
                    profileVC.presentViewController(profileVC.imagePicker, animated: true, completion: nil)
                }
            }else{
                print("problem gettin callerVC as PerfilViewController")
            }
        }else{
            print("different VC")
        }
        
    }
    
    
    /*
        Open the camera roll
    */
    internal func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        if(self.source == self.feu.ID_PROFILE){
            if let profileVC:PerfilViewController = self.callerVC as? PerfilViewController{
                
                // dismiss view controller once the user finished picking image
                self.fetchProfileImg(info)
                profileVC.dismissViewControllerAnimated(true, completion: nil)
                
            }else{
                print("problem gettin callerVC as PerfilViewController")
            }
        }else{
            print("different VC")
        }
    }
    
    
    /*
        Fetch profile image
    */
    internal func fetchProfileImg(info: [String : AnyObject]){
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            let imageData = UIImagePNGRepresentation(image)
            print("\nimage file size: \(imageData?.length)")
            
            // if the image is valid, try to convert it
            if let imgSize:Int = imageData?.length{
                if(self.validImageSize(imgSize)){
                    if let imgFile:PFFile = self.convertImageToPFFile(image){
                        
                        // set the selected picture
                        self.setSelectedImageFile(imgFile)
                    }else{
                        print("problems getting image as a PFFile")
                    }
                }else{
                    print("\nwarning, image file size is to large")
                }
            }else{
                print("problems getting image size")
            }
        }
    }
    
    
    /*
        Convert image to PFFile
    */
    internal func convertImageToPFFile(image:UIImage?) -> PFFile?{
        if let img = image{
            
            // the caller target image outlet
            self.setTargetViewImage(img)
            
            let imgData:NSData = UIImagePNGRepresentation(img)!
            
            return PFFile(name: "picture", data: imgData)
        }else{
            return nil
        }
    }
    
    
    /*
        Actions taken if the user cancel the select picture operation
    */
    internal func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("\nuser canceled the operation")
        
        if(self.source == self.feu.ID_PROFILE){
            if let profileVC:PerfilViewController = self.callerVC as? PerfilViewController{
                profileVC.dismissViewControllerAnimated(true, completion: nil)
            }else{
                print("problem gettin callerVC as PerfilViewController")
            }
        }else{
            print("different VC")
        }
    }
    
    
    /*
        If the profile picture is too large, show a message and return false
    */
    internal func validImageSize(size:Int) -> Bool{
        if(size < self.feu.IMAGE_SIZE){
            return true
        }
        
        return false
    }
    


    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
