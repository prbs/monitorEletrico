//
//  RewardViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/13/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class RewardViewController: UIViewController {

    
    // VARIABLES
    @IBOutlet weak var rewardImage: UIImageView!
    @IBOutlet weak var rewardTitle: UILabel!
    @IBOutlet weak var rewardDescription: UITextView!
    
    internal var reward:Reward? = nil
    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // check if the reward object is initialized and load it
        if(self.reward != nil){
            print("selected reward on Reward/Details \(reward)")
            
            // load UI if values of loaded reward
            self.rewardTitle.text = self.reward?.getRewardTitle()
            self.rewardDescription.text = self.reward?.getRewardInfo()
            
            let pic = reward!.getRewardPicture()
            if(pic != nil){
                pic!.getDataInBackgroundWithBlock({
                    (imageData: NSData?, error: NSError?) -> Void in
                    
                    if (error == nil) {
                        let image = UIImage(data:imageData!)
                        self.rewardImage.image = image
                    }
                })
            }else{
                self.rewardImage.image = UIImage(named:"imgres.jpg")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
