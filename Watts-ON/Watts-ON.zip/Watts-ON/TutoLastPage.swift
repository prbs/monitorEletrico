//
//  TutoLastPage.swift
//  x
//
//  Created by Diego Silva on 11/20/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class TutoLastPage: UIView {

    
    
    // VARIABLES
    @IBOutlet weak var startBtn: UIButton!
    
    var parentVC:TutorialViewController = TutorialViewController()
    let feu:FrontendUtilities = FrontendUtilities()
    
    
    
    // INITIALIZERS
    override func drawRect(rect: CGRect) {
        self.feu.roundIt(self.startBtn, color:self.feu.NAVBAR_BACKGROUND_COLOR)
    }
    
    
    
    // NAVIGATION
    @IBAction func goHome(sender: AnyObject) {
        parentVC.goHome(sender)
    }

}
