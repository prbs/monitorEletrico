//
//  AlertViewController.swift
//  x
//
//  Created by Diego Silva on 11/3/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class AlertViewController: BaseViewController {
    
        
    // VARIABLES
    @IBOutlet weak var msg: UITextView!
    @IBOutlet weak var tipBtn: UIButton!
    
    
    internal let dbh:DBHelpers = DBHelpers()
    internal var callerViewController:HomeViewController = HomeViewController()
        
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
            
        let tapGesture = UITapGestureRecognizer(target: self, action: "dismissViewOnBackgroundTap")
        self.view.addGestureRecognizer(tapGesture)
        self.view.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.8)
    }
        
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
        
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
        
        
        
    // UI
    /*
        Pop up dialog
    */
    func showInView(aView: UIView!, animated: Bool){
            
        aView.addSubview(self.view)
        if animated{
            self.showAnimate()
        }
    }
        
    func showAnimate(){
        
        // customize view elements
        self.customizeAddBtn(self.tipBtn)
        
        
        
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        });
    }
        
        
    /*
        Close input dialog view
    */
    @IBAction func closePopupFromCloseBtn(sender: AnyObject) {
        self.removeAnimate()
    }
        
    func dismissViewOnBackgroundTap(){
        self.removeAnimate()
    }
        
    func removeAnimate(){
        UIView.animateWithDuration(0.5, animations: {
            
            // perform action on a separeted thread
            self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
            self.view.alpha = 0;
                
            self.view.frame = CGRectMake(
                self.view.frame.origin.x,
                self.view.frame.origin.y + 600,
                self.view.frame.size.width,
                self.view.frame.size.height
            )
        }, completion:{
            (finished : Bool)  in
                    
            // prevent the system of showing this alert again on this session
            DBHelpers.alertMsgController[(DBHelpers.currentLocation?.getObId())!] = true
            self.view.removeFromSuperview()
        });
            
    }
        
    
    
    /*
        Redirects the user to the tip's page
    */
    @IBAction func goTips(sender: AnyObject) {
        print("load a tip that matches the user needs.")
        
        self.callerViewController.openTipDialog(false)
        self.removeAnimate()
    }
    
    
    
    
    // LOGIC
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

