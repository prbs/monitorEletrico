//
//  TipCardView.swift
//  x
//
//  Created by Diego Silva on 11/15/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class TipCardView: UIView {

    
    @IBOutlet weak var cardOutterContainer: UIView!
    @IBOutlet weak var cardInnerContainer: UIView!
    @IBOutlet weak var tipView: UIImageView!
    @IBOutlet weak var tipTitle: UILabel!
    @IBOutlet weak var tipDescription: UITextView!
    @IBOutlet weak var shareBtn: UIButton!
    
    internal let feu:FrontendUtilities = FrontendUtilities()
    internal var parentVC:DicasViewController? = DicasViewController()
    internal var cardIdx:Int = -1
    
    
    
    // INITIALIZERS
    override func drawRect(rect: CGRect) {
        self.feu.roundIt(self.shareBtn, color:self.feu.LIGHT_WHITE)
        
        self.feu.roundCorners(self.cardOutterContainer, color: self.feu.LIGHT_WHITE)
        self.feu.roundCorners(self.cardInnerContainer, color: self.feu.SUPER_LIGHT_WHITE)
    }
    
    
    
    
    // LOGIC
    @IBAction func shareTip(sender: AnyObject) {
        
        // check if the parent view controller was set
        if let vc:DicasViewController = self.parentVC{
            vc.shareTip(cardIdx)
        }else{
            print("parent view controller was not set")
        }
        
    }
    
}
