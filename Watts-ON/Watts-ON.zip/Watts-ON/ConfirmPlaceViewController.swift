//
//  ConfirmPlaceViewController.swift
//  x
//
//  Created by Diego Silva on 11/20/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class ConfirmPlaceViewController: BaseViewController {

    
    // VARIABLES
    @IBOutlet weak var confInnerCont: UIView!
    @IBOutlet weak var confirmOutterCont: UIView!
    
    @IBOutlet weak var infoContainer: UIView!
    @IBOutlet weak var addedContainer: UIView!
    @IBOutlet weak var confirmRelationship: UIButton!
    
    
    @IBOutlet weak var adminImg: UIImageView!
    @IBOutlet weak var adminName: UILabel!
    @IBOutlet weak var placeName: UILabel!
    @IBOutlet weak var placeTypeImg: UIImageView!
    @IBOutlet weak var placeTypeImgContainer: UIView!
    
    
    internal var location:Location? = nil
    internal var locObj:PFObject? = nil
    internal var callerViewController:AddPlaceAsGuestViewController? = nil
    internal var confirmed:Bool = false
    
    internal let dbu:DBUtils = DBUtils()
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    
    
    // UI
    /*
        Pop up dialog
    */
    func showInView(aView: UIView!, animated: Bool, location:Location, locObj:PFObject, admin:User){
        aView.addSubview(self.view)
        
        if animated{
            
            // customize UI
            self.location = location
            self.locObj   = locObj
            self.customizeUI(admin)
            
            // show it
            self.showAnimate()
        }
    }
    
    func customizeUI(admin:User){
        
        // customize containers
        self.feu.roundCorners(self.confInnerCont, color: self.feu.LIGHT_WHITE)
        self.feu.roundCorners(self.confirmOutterCont, color: self.feu.DARK_WHITE)
        
        // admin name
        var admName = ""
        if(admin.getUserName() != self.dbu.STD_UNDEF_STRING){
            admName = admin.getUserName()!
        }else{
            print("problems getting admin name")
        }
        self.adminName.text = admName
        
        // location name
        self.placeName.text = self.location!.getLocationName()
        
        // insert the location type image (Business or Residencial)
        if let locType:String = self.location!.getLocationType(){
            if(locType == self.feu.LOCATION_TYPES[0]){
                self.placeTypeImg.image = UIImage(named:self.feu.IMAGE_LOC_TYPE_RESIDENCIAL)
                
            }else if(locType == self.feu.LOCATION_TYPES[1]){
                self.placeTypeImg.image = UIImage(named:self.feu.IMAGE_LOC_TYPE_BUSINESS)
            }
        }else{
            print("problems getting location type")
        }
        self.feu.roundIt(self.placeTypeImgContainer, color:self.feu.LIGHT_BLUE)
        
        // get the admin image
        if let picture:UIImage = admin.getUserPicUIImage(){
            self.adminImg.image = picture
        }else{
            self.adminImg.image = UIImage(named: "user.png")
        }
        self.feu.roundCorners(self.adminImg, color: self.feu.SUPER_LIGHT_WHITE)
        
        // initialize the fadeOut animation
        self.feu.fadeOut(self.infoContainer, speed: 0.1)
        self.feu.fadeOut(self.addedContainer, speed: 0.1)
    }
    
    func showAnimate(){
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        }, completion:{
            (value:Bool) in
            
            self.feu.fadeIn(self.infoContainer, speed: 0.8)
        });
    }
    
    
    func removeAnimate(){
        UIView.animateWithDuration(0.5, animations: {
            // perform action on a separeted thread
            self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
            self.view.alpha = 0;
            
            self.view.frame = CGRectMake(
                self.view.frame.origin.x,
                self.view.frame.origin.y + 600,
                self.view.frame.size.width,
                self.view.frame.size.height
            )
            }, completion:{
                (finished : Bool)  in
                
                // prevent the system of showing this alert again on this session
                self.view.removeFromSuperview()
        })
    }

    
    
    
    /*
        User cancelled the operation and closed the confirmation dialog
    */
    @IBAction func closeDialog(sender: AnyObject) {
        self.removeAnimate()
    }
    
    
    
    /*
        User has confirmed the location, starts backend operation
    */
    @IBAction func confirmLocation(sender: AnyObject) {
        print("user has confirmed location")
        
        if(!self.confirmed){
            self.addUserToLocationAsGuest()
        }else{
            print("reinitializing global variable and sending user back home ...")
            
            // unwind segue, and return user back to the home screen
            if let caller:AddPlaceAsGuestViewController = self.callerViewController{
                caller.sendUserHomeAfterJoinOp()
            }else{
                print("problems while getting caller object, cannot close dialog")
            }
        }
    }
    
    
    
    
    // LOGIC
    /*
        Add user to location as guest
    */
    internal func addUserToLocationAsGuest(){
        print("\ntrying to add user to location as guest")
        
        if let location:PFObject = self.locObj{
            
            PFCloud.callFunctionInBackground("createUserLocationRelationship", withParameters: [
                "locationId":location.objectId!,
                "userId"    :PFUser.currentUser()!.objectId!
            ]) {
                (result, error) in
                    
                if (error == nil){
                    print("location \(location)")
                    
                    if let result:Int = result as? Int {
                        print("user was added to the location)")
                        
                        if(result == 0){
                            // try to load added location goal
                            self.getLocationOpennedGoal(self.locObj!)
                        }else{
                            self.infoWindow("Não foi possível adicionar o usuário como visitante do local selecionado devido a uma falha do sistema", title: "Erro operacional", vc: self)
                        }
                    }else{
                        print("problems converting results into array of locations.")
                        self.finalizeLocationJoinProcess(false, locationId: "", goal: nil)
                    }
                }else{
                    print("\nerror: \(error)")
                }
            }
            
        }else{
            print("problem gettin user location out of selected location obj")
            self.infoWindow("Não foi possível adicionar o usuário como visitante do local selecionado devido a uma falha do sistema", title: "Erro operacional", vc: self)
        }
    }
    
    
    
    /*
        Get added location goal
    */
    internal func getLocationOpennedGoal(location:PFObject){
        print("\ntrying to get location openned goal ...")
        
        PFCloud.callFunctionInBackground("getLocationOpennedGoalById", withParameters: [
            "locationId":location.objectId!
        ]) {
            (goalId, error) in
                
            if (error == nil){
                print("goalId \(goalId)")
                
                if let locGoalId:String = goalId as? String {
                    self.getGoalById(locGoalId)
                }else{
                    print("the selected location has no openned goal.")
                    self.finalizeLocationJoinProcess(false, locationId:"", goal:nil)
                }
            }else{
                print("\nerror: \(error)")
                self.infoWindow("Não foi possível adicionar o usuário como visitante do local selecionado devido a uma falha do sistema", title: "Erro operacional", vc: self)
            }
        }
    }
    
    
    
    /*
        Get goal by its id
    */
    internal func getGoalById(id:String){
        
        PFCloud.callFunctionInBackground("getGoalById", withParameters: [
            "goalId":id
        ]) {
            (goal, error) in
                
            if (error == nil){
                print("found goal for added location \(goal), loading it ...")
                    
                if let locGoal:PFObject = goal as? PFObject {
                        
                    // unwrap PFObject into a model object
                    let locationGoal:Goal = Goal(goal:locGoal)
                        
                    // unwrap location values
                    if let loc:PFObject = self.location{
                        if let locId:String = loc.objectId{
                            
                            // insert the new location and its dependencies into the global variables
                            self.finalizeLocationJoinProcess(true, locationId:locId, goal:locationGoal)
                        }else{
                            print("problem getting location id as String")
                        }
                    }else{
                        print("problem converting location to PFObject")
                    }
                }else{
                    print("problems converting results into array of locations.")
                }
            }else{
                print("\nerror: \(error)")
                self.infoWindow("Não foi possível adicionar o usuário como visitante do local selecionado devido a uma falha do sistema", title: "Erro operacional", vc: self)
            }
        }
    }
    
    
    /*
        Finalize locatino join process
    */
    internal func finalizeLocationJoinProcess(withGoal:Bool, locationId:String, goal:Goal?){
        
        // update the status of the global controller variables
        DBHelpers.reinitializeGlobalVariables(self.locObj!)
        
        // insert the openned goal into the list of goals
        if(withGoal){
            if let locationGoal:Goal = goal{
                DBHelpers.locationGoals[locationId] = locationGoal
            }else{
                print("problems getting location goal")
            }
        }
        
        // change the view dialog
        self.feu.fadeOut(self.infoContainer, speed: 0.3)
        self.feu.fadeIn(self.addedContainer, speed: 0.7)
        self.confirmRelationship.setTitle("Ok, voltar para a Home", forState: .Normal)
        
        // allow the user to go to the home screen
        self.confirmed = true
    }
    
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
