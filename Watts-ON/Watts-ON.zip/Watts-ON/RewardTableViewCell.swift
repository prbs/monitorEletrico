//
//  RewardTableViewCell.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/15/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class RewardTableViewCell: PFTableViewCell {
    
    
    // VARIABLES
    @IBOutlet weak var rewardTitleContainer: UIView!
    @IBOutlet weak var cellFilter: UIView!
    @IBOutlet weak var actionsContainer: UIView!
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var editingBtn: UIButton!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var selectBtn: UIButton!
    
    @IBOutlet weak var rewardImage: UIImageView!
    @IBOutlet weak var rewardTitle: UILabel!
    @IBOutlet weak var rewardNumLikes: UILabel!
    @IBOutlet weak var hiddenNumLikes: UILabel!
    
    internal let feu:FrontendUtilities = FrontendUtilities()
    internal let dbu:DBUtils = DBUtils()
    internal var parentController:RewardsViewController = RewardsViewController()
    internal var cellReward:Reward? = nil
    internal var selectedIndexPath:NSIndexPath? = nil
    
    
    // INITIALIZERS
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // initialize buttons
        self.selectBtn.hidden = true
        self.selectBtn.enabled = false
        self.selectBtn.opaque = true
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // todo
    }
        
        
    // UI
    /*
        Upvote a reward
    */
    @IBAction func likeIt(sender: AnyObject) {
        print("like it")
        
        // check if the user already like the reward and disable button if it is the case
        if(!self.parentController.checkIfAlreadyLikeReward(self.cellReward!)){
            self.userLikeReward()
        }
    }
    
    
    /*
        Edit the reward of this cell
    */
    @IBAction func editReward(sender: AnyObject) {
        print("Go to reward editing screen")
        
        print("cell reward: \(self.cellReward)")
        parentController.performSegueWithIdentifier(self.feu.SEGUE_REWARD_UPDATE, sender: self.cellReward)
    }
    
    
    /*
        Deletes the reward currently set in this cell
    */
    @IBAction func deleteReward(sender: AnyObject) {
        print("deleting reward")
        
        parentController.infoWindowWithCancel("Uma recompensa deletada não poderá ser recuperada.", title: "Tem certeza?", objId: (self.cellReward?.getObId())!, selectedIndexPath: self.selectedIndexPath!)
    }
    
    
    /*
        Select cell
    */
    @IBAction func selectCell(sender: AnyObject) {
        
        print("return selected reward to new Goal")
        
        self.parentController.selectedReward = self.cellReward
        self.parentController.performSegueWithIdentifier("SelectReward", sender: self.cellReward)
    }
    
    
    /*
        Increment likes' counter
    */
    internal func incrementLikesCounter(){
        if var nl:Int = Int.init(self.rewardNumLikes.text!){
            nl++
            
            self.rewardNumLikes.text = String(nl)
            self.likeBtn.enabled = false
        }
    }
    
    

    // LOGIC
    /*
        Create a relationship of kind like between an User and a Reward
    */
    internal func userLikeReward(){
        
        // if cell reward is valid
        if(self.cellReward != nil){
            
            // create user like reward relationship
            let rewaRelObj = self.cellReward?.getUserLikeRewardsNewObj(PFUser.currentUser()!)
            rewaRelObj!.saveInBackgroundWithBlock {
                (success: Bool, error: NSError?) -> Void in
                    
                if (success) {
                    print("\ncreated relationship user like reward ...")
                    
                    // update UI
                    self.incrementLikesCounter()
                        
                    // update backend
                    self.updateRewardCounter()
                } else {
                    print("\nerror, there was a problem creating the user reward relatioship")
                }
            }
        }
    }
    
    
    /*
        Update likes counter on selected Reward object
    */
    internal func updateRewardCounter(){
        
        let query = PFQuery(className:self.dbu.DB_CLASS_REWARD)
        query.getObjectInBackgroundWithId((self.cellReward?.getObId())!) {
            (rew: PFObject?, error: NSError?) -> Void in
            
            if error != nil {
                print("Error changing num of likes on reward object \(error)")
            } else if let reward = rew {
                print("\nupdated reward object likes counter.")
                
                self.cellReward?.updateReward(reward)
                print("reward object after update \(reward)")
                
                reward.saveInBackground()
            }
        }
    }
    

}
