//
//  HomeViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {

    
    
    // VARIABLES
    /* Containers */
    @IBOutlet weak var scroller: UIScrollView!
    @IBOutlet weak var locationSelectorContainer: UIView!
    @IBOutlet weak var contentContainer: UIView!
    @IBOutlet weak var infoContainer    : UIView!
    @IBOutlet weak var boltAnimationContainer : UIView!
    
    @IBOutlet weak var screenLocker: UIView!
    
    /* Bolt animation */
    @IBOutlet weak var baBackgroundView: UIImageView!
    @IBOutlet weak var baProgressView: UIView!
    @IBOutlet weak var baForegroundView: UIImageView!
    @IBOutlet weak var baLeftEye: UIImageView!
    @IBOutlet weak var baRightEye: UIImageView!
    
    
    /* Money Spent progress animation */
    internal var ANIMATION_PROGRESS = ""
    @IBOutlet weak var moneySpent       : UILabel!
    @IBOutlet weak var desiredVal       : UILabel!
    @IBOutlet weak var thoughtContainer: UIView!
    
    
    /* Middle */
    @IBOutlet weak var chartsBtn: UIView!
    @IBOutlet weak var daysLeft      : UILabel!
    @IBOutlet weak var lineChartView : LineChartView!
    @IBOutlet weak var chartContainer: UIView!
    
    /* Action buttons */
    @IBOutlet weak var menuBtn     : UIBarButtonItem!
    @IBOutlet weak var newPlaceBtn : UIBarButtonItem!
    
    @IBOutlet weak var choosePlcLeftBtn  : UIButton!
    @IBOutlet weak var choosePlcRightBtn : UIButton!
    @IBOutlet weak var chosenPlace       : UIButton!
    
    @IBOutlet weak var newGoalBtn       : UIButton!
    @IBOutlet weak var usersBtn         : UIButton!
    @IBOutlet weak var newReadingBtn    : UIButton!
    @IBOutlet weak var allReadingsBtn   : UIButton!
    @IBOutlet weak var statsBtn: UIButton!
    
    /* Alerts */
    internal var welcomeMessageController : WelcomeMessageViewController!
    internal var popViewController        : UpdateReadingViewController!
    internal var alertViewController      : AlertViewController!
    internal var successViewController    : FinishedWithSucessViewController!
    internal var failureViewController    : FinishedWithFailureViewController!
    internal var amountPaidViewController : AmountPaidViewController!
    internal var tipCardViewController    : TipCardViewController!
    
    /* Helpers */
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils   = DBUtils()
    internal var callerViewController:BaseViewController = BaseViewController()
    
    /* Data containers */
    internal var locationNames:Array<String> = Array<String>()
    internal var selectedLocation:String = ""
    internal var areReadingOptShowing:Bool = false
    
    /* Constants */
    internal let BTN_MOV_DISTANCE:CGFloat = 70
    internal let BTN_ROT_SPEED:Double = 0.7
    internal let BTN_SHOW_HIDE_SPEED:Double = 1.3
    internal let OPNED_READING_OPT_BTN:String = "plus.png"
    internal let CLOSED_READING_OPT_BTN:String = "close.png"
    
    /* Controllers */
    internal var justDeletedLocation:Bool = false
    internal var isChartShowing:Bool = false
    
    /* Timers */
    internal var blinkTimer:NSTimer = NSTimer()
    
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(DBHelpers.lockedSystem){
            self.lockUI()
            
            // don't allow the user to access the menu
            self.view.removeGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }else{
            
            // unlock the system
            if(self.welcomeMessageController != nil){
                self.unlockUI()
            }
            
            // binds the show menu toogle action implemented by SWRevealViewController to the menu button
            if self.revealViewController() != nil {
                self.menuBtn.target = self.revealViewController()
                self.menuBtn.action = "revealToggle:"
                self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            }
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        
        // UI initialization
        self.customizeNavBar(self)
        self.customizeMenuBtn(self.menuBtn, btnIdentifier: self.feu.ID_MENU)
        self.feu.applyPlainShadow(self.locationSelectorContainer)
        
        self.customizeAddBtn(self.newGoalBtn)
        self.customizeAddBtn(self.usersBtn)
        self.customizeAddBtn(self.newReadingBtn)
        self.customizeAddBtn(self.allReadingsBtn)
        
        self.customizeChartsBtns()
        
        self.startBlinking()
        
        // set the scroll view
        self.setScroller()
        
        // lock system
        if(!DBHelpers.lockedSystem){
            
            // reset the animation controller variable after a successfull input
            FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_BOLT]     = false
            FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_PROGRESS] = false
        
            // Initialize data
            self.loadData()
        
            // analyze user data
            self.analyzeUserPerformance()
        }
    }

    
    
    // UI
    /*
        Block UI
    */
    internal func lockUI(){
        self.resetUI()
        self.choosePlcLeftBtn.hidden = true
        self.choosePlcRightBtn.hidden = true
        self.chosenPlace.hidden = true
        self.menuBtn.enabled = false
        
        // lock the screen with a specific message
        if(DBHelpers.firstTime){
            self.setInstructionsContainer(0)
        }else{
            self.setInstructionsContainer(1)
        }
    }
    
    /*
        Unlock UI
    */
    internal func unlockUI(){
        print("Unlocking UI ...")
        self.choosePlcLeftBtn.hidden = false
        self.choosePlcRightBtn.hidden = false
        self.chosenPlace.hidden = false
        self.menuBtn.enabled = true
        
        self.welcomeMessageController.removeAnimate()
        DBHelpers.lockedSystem = false
    }
    
    
    
    /*
        Change UI elemtents to the initial state
    */
    internal func resetUI(){
        print("\nreseting UI ...")
        
        // reset labels
        self.chosenPlace.setTitle("", forState: .Normal)
        self.desiredVal.text       = "R$00,00"
        self.moneySpent.text       = "R$00,00"
        self.daysLeft.text         = ""
        
        // reset animations
        self.feu.resetLineChart(self.lineChartView)
        
        FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_BOLT]     = false
        FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_PROGRESS] = false
    }
    
    
    /*
        Set the instruction's container with the correct view, in order to give the user instructions on how to use the system
    
        Input:
            instType - 0 = welcome message view
            instType - 1 = new location message view
    */
    internal func setInstructionsContainer(instType:Int){
    
        if(instType == 0){
            print("loading welcome message view ...")
            self.createWelcomeMessageDialog(
                "Bem vindo",
                msg:"Para que Bolt comece monitorar o seu consumo energético, clique no botão apontado pela seta e crie um local.",
                type:instType
            )
        }else{
            print("loading new location message view ...")
            self.createWelcomeMessageDialog(
                "Crie um novo local",
                msg:"Adicione um local para que o restante das funcionalidades do sistema sejam ativadas",
                type:instType
            )
        }
    }
    
    
    
    /*
        Set chart components
    */
    internal func customizeChartsBtns(){
        self.statsBtn.layer.borderColor = self.feu.LIGHT_WHITE.CGColor
        self.statsBtn.layer.borderWidth = 5.0
        self.statsBtn.layer.cornerRadius = self.statsBtn.frame.size.width / 20
        self.feu.applyCurvedShadow(self.statsBtn)
        
        self.feu.applyCurvedShadow(self.chartContainer)
    }
    
    
    
    /*
        Show charts on a toggle mode
    */
    @IBAction func showCharts(sender: AnyObject) {
        print("show charts area ...")
        
        if(self.isChartShowing){
            
            // hide the chart container
            UIView.animateWithDuration(0.8,
                animations: {
                    self.contentContainer.frame = CGRectMake(
                        self.contentContainer.frame.origin.x,
                        self.contentContainer.frame.origin.y,
                        self.contentContainer.frame.size.width,
                        self.contentContainer.frame.size.height
                    )

                    self.chartContainer.frame = CGRectMake(
                        self.chartContainer.frame.origin.x,
                        self.chartContainer.frame.origin.y,
                        self.chartContainer.frame.size.width,
                        self.chartContainer.frame.size.height
                    )
                    
                    self.feu.fadeOut(self.screenLocker, speed:0.4)
                    self.statsBtn.setTitle("Mais informações", forState: .Normal)
                }, completion:{
                    (val:Bool) in
                    
                    UIView.animateWithDuration(1.2,
                        animations: {
                            self.contentContainer.frame = CGRectMake(
                                self.contentContainer.frame.origin.x,
                                self.contentContainer.frame.origin.y + 100,
                                self.contentContainer.frame.size.width,
                                self.contentContainer.frame.size.height
                            )
                            
                            self.chartContainer.frame = CGRectMake(
                                self.chartContainer.frame.origin.x,
                                self.chartContainer.frame.origin.y + 300,
                                self.chartContainer.frame.size.width,
                                self.chartContainer.frame.size.height - 200
                            )
                            
                        }, completion:{
                            (val:Bool) in
                            
                            self.isChartShowing = false
                    })
                }
            )
        }else{
            
            // show the chart container
            UIView.animateWithDuration(0.8,
                animations: {
                    self.contentContainer.frame = CGRectMake(
                        self.contentContainer.frame.origin.x,
                        self.contentContainer.frame.origin.y,
                        self.contentContainer.frame.size.width,
                        self.contentContainer.frame.size.height
                    )
                    
                    self.chartContainer.frame = CGRectMake(
                        self.chartContainer.frame.origin.x,
                        self.chartContainer.frame.origin.y,
                        self.chartContainer.frame.size.width,
                        self.chartContainer.frame.size.height
                    )

                    self.feu.fadeIn(self.screenLocker, speed:0.4)
                    self.statsBtn.setTitle("Esconder informações", forState: .Normal)
                }, completion:{
                    (val:Bool) in
                    
                    UIView.animateWithDuration(1.2,
                        animations: {
                            self.contentContainer.frame = CGRectMake(
                                self.contentContainer.frame.origin.x,
                                self.contentContainer.frame.origin.y - 100,
                                self.contentContainer.frame.size.width,
                                self.contentContainer.frame.size.height
                            )
                            
                            self.chartContainer.frame = CGRectMake(
                                self.chartContainer.frame.origin.x,
                                self.chartContainer.frame.origin.y - 300,
                                self.chartContainer.frame.size.width,
                                self.chartContainer.frame.size.height + 200
                            )
                            
                        }, completion:{
                            (val:Bool) in
                            
                            self.isChartShowing = true
                    })
                }
            )
        }
    }
    
    
    
    
    /*
        Configure the dimensions of the scroller view
    */
    internal func setScroller(){
        self.scroller.userInteractionEnabled = true
        self.scroller.frame = self.view.bounds
        self.scroller.contentSize.height = self.contentContainer.frame.size.height
        self.scroller.contentSize.width = self.contentContainer.frame.size.width
    }
    
    
    /*
        Circular list methods
    */
    // select item on the left side
    @IBAction func selectPrevious(sender: AnyObject){
        var prevIdx = -1
        
        if(self.locationNames.count > 0){
            if((DBHelpers.currentLocatinIdx - 1) < 0){
                prevIdx = self.locationNames.count - 1
            }else{
                prevIdx = DBHelpers.currentLocatinIdx - 1
            }
        }else{
            print("user has no location")
        }
        
        DBHelpers.currentLocatinIdx = prevIdx
        
        self.chosenPlace.setTitle(self.locationNames[prevIdx], forState: .Normal)
        self.switchToLocation(prevIdx)
    }

    // select item on the right side
    @IBAction func selectNext(sender: AnyObject) {
        var nextIdx = -1
        
        if(self.locationNames.count > 0){
            if((DBHelpers.currentLocatinIdx + 1) > (self.locationNames.count - 1)){
                nextIdx = 0
            }else{
                nextIdx = DBHelpers.currentLocatinIdx + 1
            }
        }else{
            print("user has no location")
        }
      
        DBHelpers.currentLocatinIdx = nextIdx
        
        self.chosenPlace.setTitle(self.locationNames[nextIdx], forState: .Normal)
        self.switchToLocation(nextIdx)
    }
    
    // get the index of the selected item
    internal func getSelectedItemIndex(locationName:String) -> Int?{
        
        var i = 0
        for locName in self.locationNames{
            if(locName == locationName){
                return i
            }
            i++
        }
        
        return -1
    }
    
    
    
    
    // ANIMATIONS
    /*
        Present reading options buttons
    */
    internal func showFloatingMenu() {
        print("\nShowing floating menu")
        
        // show allReadingsBtn and newReadingsBtn, only if the user has a goal
        if(DBHelpers.currentGoal != nil){
                
            // show all readings if the user has a goal
            self.feu.fadeIn(self.allReadingsBtn, speed: self.BTN_SHOW_HIDE_SPEED)
                
            // show the newReadingsBtn only if current location has a device
            if(DBHelpers.currentDevice == nil){
                self.feu.fadeIn(self.newReadingBtn, speed: 0.3)
                
                let allReadBtnPos:CGFloat = self.allReadingsBtn.frame.origin.x
                    
                // avoid all readings btn dissapearing,
                if(!((allReadBtnPos - CGFloat(90.0)) < CGFloat(0.0))){
                        
                    // if the location has no device, show the new reading option and move all readings left
                        self.feu.moveLeft(self.allReadingsBtn, distance:90, speed: 0.8)
                }
            }else{
                self.feu.fadeOut(self.newReadingBtn, speed: 0.4)
                    
                // if the location has a device, hide the new reading option and move all readings right
                self.feu.moveRight(self.allReadingsBtn, distance:90, speed: 0.8)
            }
                
        }else{
            print("There isn't an active goal for this location")
            self.feu.fadeOut(self.allReadingsBtn, speed: 0.6)
            self.feu.fadeOut(self.newReadingBtn, speed: 0.6)
            
            // if the user has no goal call his/her attention to the need of a goal
            //self.feu.startPulsing(self.newGoalBtn, times:1)
        }
            
            
        // show the users btn only if the user has a location
        if(DBHelpers.currentLocation == nil){
            self.feu.fadeOut(self.usersBtn, speed: 0.6)
        }else{
            self.feu.fadeIn(self.usersBtn, speed: 0.6)
        }
        
    }
    
    
    /*
        Bolt percentage animation
    */
    internal func boltPercentageAnimation(usedPercentage:Double, status:Double){
        print("\ncreating bolt animation ...")
        
        if let hasAnimated = FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_BOLT]{
            
            if(!hasAnimated && (DBHelpers.currentGoal != nil)){
                
                if(usedPercentage <= 100){
                    // animate the KW meter on Bolt
                    self.feu.boltPercentageAnimation(
                        self.baBackgroundView,
                        boltProgressView:self.baProgressView,
                        usedPercentage:usedPercentage,
                        status:status
                    )
                    
                    UIView.animateWithDuration(0.5, animations: {
                        self.moneySpent.tintColor = self.feu.SAFE_COLOR
                    })
                }else{
                    print("create funny warning animation to let the user know that he/she exploded the value..")
                    
                    // animate the KW meter on Bolt
                    self.feu.boltPercentageAnimation(
                        self.baBackgroundView,
                        boltProgressView:self.baProgressView,
                        usedPercentage:100.0,
                        status:status
                    )
                }
                
                UIView.animateWithDuration(0.5, animations: {
                    self.moneySpent.tintColor = self.feu.DANGER_COLOR
                })
                
                // update the Bolt animation status
                FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_BOLT] = true
            }

        }else{
            print("problems getting the state of the Bolt animation")
        }
        
        print("animated Bolt")
    }
    
    
    /*
        Reset Bolt animation
    */
    internal func resetBoltAnimation(){
        // animate the KW meter on Bolt
        self.feu.boltPercentageAnimation(
            self.baBackgroundView,
            boltProgressView:self.baProgressView,
            usedPercentage:0.0,
            status:0
        )
    }
    
    
    
    /*
        Bolt blink animation, Create a blink effect on the selected view by increasing and reducing the size of the it
    */
    internal func startBlinking(){
        self.blinkTimer = NSTimer.scheduledTimerWithTimeInterval(
            10.0,
            target   : self,
            selector : Selector("blink:"),
            userInfo : nil,
            repeats  : true
        )
    }
    
    func blink(timer:NSTimer){
        
        UIView.animateWithDuration(0.3, animations:{
            self.baLeftEye.frame = CGRectMake(
                self.baLeftEye.frame.origin.x,
                self.baLeftEye.frame.origin.y,
                self.baLeftEye.frame.size.width,
                self.baLeftEye.frame.size.height
            )
                
            self.baRightEye.frame = CGRectMake(
                self.baRightEye.frame.origin.x,
                self.baRightEye.frame.origin.y,
                self.baRightEye.frame.size.width,
                self.baRightEye.frame.size.height
            )
            
        }, completion: {
            (value: Bool) in
                        
            UIView.animateWithDuration(0.3, animations:{
                self.baLeftEye.frame = CGRectMake(
                    self.baLeftEye.frame.origin.x,
                    self.baLeftEye.frame.origin.y + 12,
                    self.baLeftEye.frame.size.width,
                    self.baLeftEye.frame.size.height - 25
                )
                    
                self.baRightEye.frame = CGRectMake(
                    self.baRightEye.frame.origin.x,
                    self.baRightEye.frame.origin.y + 12,
                    self.baRightEye.frame.size.width,
                    self.baRightEye.frame.size.height - 25
                )
            }, completion:{
            (value:Bool) in
                                
                UIView.animateWithDuration(0.3, animations:{
                    self.baLeftEye.frame = CGRectMake(
                        self.baLeftEye.frame.origin.x,
                        self.baLeftEye.frame.origin.y - 12,
                        self.baLeftEye.frame.size.width,
                        self.baLeftEye.frame.size.height + 25
                    )
                        
                    self.baRightEye.frame = CGRectMake(
                        self.baRightEye.frame.origin.x,
                        self.baRightEye.frame.origin.y - 12,
                        self.baRightEye.frame.size.width,
                        self.baRightEye.frame.size.height + 25
                    )
                }, completion:{
                    (value:Bool) in
                            
                    // do something here
                })
            })
        })
    }
    
    internal func stopBlinking(){
        self.blinkTimer.invalidate()
    }

    
    
    
    
    
    // DIALOGS
    /*
        Welcome animation. This dialog explain what the user has to do to get the system working. 
        Basically create a new location
    
        Input:
            title:String - the title of the dialog
            msg:String   - the message of the dialog
            type: the sort of view:
                type 0 = welcome, 
                type 1 = new location
    */
    internal func createWelcomeMessageDialog(title:String, msg:String, type:Int){
        // create a new reading dialog
        self.welcomeMessageController = WelcomeMessageViewController(
            nibName: "WelcomeMessage",
            bundle: nil
        )
        
        // initialize dialog with pointer to this page, in order to get the inserted value
        self.welcomeMessageController.callerViewController = self
        self.welcomeMessageController.title = "This is a popup view"
        self.welcomeMessageController.showInView(
            self.view,
            animated: true,
            title: title,
            msg: msg,
            type: type
        )
    }
    
    
    
    
    /*
        Open the new reading dialog
    */
    @IBAction func newReading(sender: AnyObject) {
        
        // create a new reading dialog
        self.popViewController = UpdateReadingViewController(
            nibName: "UpdateReadingViewController",
            bundle: nil
        )
        
        // initialize dialog with pointer to this page, in order to get the inserted value
        self.popViewController.callerViewController = self
        self.popViewController.title = "This is a popup view"
        self.popViewController.showInView(
            self.view,
            withImage: UIImage(named: ""),
            withMessage: "",
            animated: true
        )
        
        self.popViewController.customizeView()
    }
    
    
    /*
        Show alert view
    */
    internal func newAlertView(msg:String){
        
        // create a new reading dialog
        self.alertViewController = AlertViewController(
            nibName: "AlertViewController",
            bundle: nil
        )
        
        self.alertViewController.showInView(
            self.view,
            animated: true
        )
        
        // initialize dialog with pointer to this page, in order to get the inserted value
        self.alertViewController.callerViewController = self
        self.alertViewController.title = "This is a popup view"
        self.alertViewController.msg.text = msg
    }
    
    
    /*
        Show the goal finished dialog, in case of success
    */
    internal func showEndOfGoalSuccess(){
        
        // create a new reading dialog
        self.successViewController = FinishedWithSucessViewController(
            nibName: "GoalDoneSuccess",
            bundle: nil
        )
        
        // start loading view attributes
        self.successViewController.callerViewController = self
        
        self.successViewController.showInView(
            self.view,
            animated: true
        )
        
        // get goal values
        self.successViewController.billEstimatedValue.text = self.dbh.getEstimatedAmountToPay().stringValue
        
        self.successViewController.desiredValue.text = DBHelpers.currentGoal!.getDesiredValue().stringValue
        
        // check if the current goal has a reward and insert its information
        var id = ""
        if let rewardId = DBHelpers.currentGoal?.getRewardId(){
            id = rewardId
        }else{
            print("current goal doensn't have a reward")
            self.successViewController.noRewardImage.hidden   = false
            
            self.successViewController.rewardImage.hidden     = true
            self.successViewController.rewardTitle.hidden     = true
            self.successViewController.labelYourReward.hidden = true
            self.successViewController.labelBesides.hidden    = true
        }
        
        // query reward on the backend
        let rewardQuery:PFQuery = Reward.query()!
        rewardQuery.getObjectInBackgroundWithId(id){
            (rewardObj: PFObject?, error: NSError?) -> Void in
            
            if(error == nil){
                if let reward = rewardObj{
                    
                    // start loading reward's attributes
                    if let rewTitle = reward[self.dbu.DBH_REWARD_TITLE] as? String{
                        self.successViewController.rewardTitle.text = rewTitle
                    }
                    
                    if let imageFile = reward[self.dbu.DBH_REWARD_PICTURE] as? PFFile{
                        imageFile.getDataInBackgroundWithBlock({
                            (imageData: NSData?, error: NSError?) -> Void in
                            
                            
                            // if there is a reward image load it
                            if (error == nil) {
                                
                                let image = UIImage(data:imageData!)
                                self.successViewController.rewardImage.image = image
                                self.successViewController.noRewardImage.hidden = true
                                self.successViewController.rewardImage.hidden = false
                            }
                        })
                    }else{
                        print("problem getting reward image PFFile")
                    }
                }else{
                    print("problem unwrapping reward info")
                }
            }else{
                print("problem getting the reward details")
            }
        }
        // end of query
    }
    
    
    /*
        Show the end of goal dialog for the case the user have failed achieving the goal
    */
    internal func showEndOfGoalFailure(){
        
        // create a new reading dialog
        self.failureViewController = FinishedWithFailureViewController(
            nibName: "GoalDoneFailure",
            bundle: nil
        )
        
        // initialize the failure view, this instruction must be used before any operation on the VC
        self.failureViewController.showInView(
            self.view,
            animated: true
        )
        
        // start loading view attributes
        self.failureViewController.callerViewController = self
        self.failureViewController.estimatedValue.text = "R$ " + self.dbh.getEstimatedAmountToPay().stringValue
        self.failureViewController.desiredValue.text = "R$ " + DBHelpers.currentGoal!.getDesiredValue().stringValue
        
        // animate progress bar
        self.failureViewController.animateProgressBar(
            self.failureViewController.progressBar,
            progressBarTrail:self.failureViewController.progressBarTrail,
            progressPointer :self.failureViewController.movingPointer,
            landmark        :self.failureViewController.landmark,
            finalLandmark   :self.failureViewController.finalLandmark,
            startValue      :0.0,
            landmarkValue   :DBHelpers.currentGoal!.getDesiredValue().floatValue,
            endValue        :self.dbh.getEstimatedAmountToPay().floatValue
        )
    }
    
    
    /*
        Explain that the user should insert the actual value paid for the eletric bill.
        Send the user home, call the process results method, and present the results. This method
        is called when the success or failure dialog is dismissed
    */
    internal func displayFinishedGoalMessage(){
        // create a new reading dialog
        self.amountPaidViewController = AmountPaidViewController(
            nibName: "AmountPaid",
            bundle: nil
        )
        
        // start loading view attributes
        self.amountPaidViewController.callerViewController = self
        
        // show the dialog
        self.amountPaidViewController.showInView(
            self.view,
            animated: true
        )
    }
    
    
    /*
        Show a tip to help the user on improving his current energy comsunption patterns
    */
    internal func openTipDialog(afterFailure:Bool){
        print("trying to open tip dialog")
        
        var image:UIImage = UIImage(named:"imgres.jpg")!
        
        // Get a tip from the backend and show it on the failure message
        let tipQuery:PFQuery = Tip.query()!
        tipQuery.findObjectsInBackgroundWithBlock{
            (objects: [AnyObject]?, error:NSError?) -> Void in
            
            if(error == nil){
                if(objects!.count > 0){
                    
                    // get a random number in the range from 0 to the tips count
                    let selected = Int(arc4random_uniform(UInt32(objects!.count)))
                    
                    if let tipObj = objects![selected] as? PFObject{
                        let tip:Tip = Tip(tip: tipObj)
                        
                        let picture = tip.getTipPicture()
                        if(picture != nil){
                            picture!.getDataInBackgroundWithBlock({
                                (imageData: NSData?, error: NSError?) -> Void in
                                
                                if (error == nil) {
                                    image = UIImage(data:imageData!)!
                                }
                                
                                self.showTip(tip, image:image, afterFailure: afterFailure)
                            })
                        }else{
                            self.showTip(tip, image:image, afterFailure: afterFailure)
                        }
                    }else{
                        print("problem converting AnyObject to PFObject")
                    }
                }else{
                    print("array of objects is empty")
                }
            }else{
                print("problem getting tip from backend")
            }
        }
    }
    
    
    /*
        Get a tip on the backend and load a new tip dialog
    */
    internal func showTip(tip:Tip, image:UIImage, afterFailure:Bool){
        
        // create a new reading dialog
        self.tipCardViewController = TipCardViewController(
            nibName: "TipDialog",
            bundle: nil
        )
        
        // start loading view attributes
        self.tipCardViewController.callerViewController = self
        
        // show the dialog
        self.tipCardViewController.showInView(
            self.view,
            animated: true
        )
        
        // load view data
        self.tipCardViewController.tipTitle.text    = tip.getTipTitle()
        self.tipCardViewController.observation.text = tip.getTipInfo()
        self.tipCardViewController.tipImage.image   = image
        self.tipCardViewController.afterFailure     = afterFailure
    }
    
   
    
    // LOGIC
    /*
        Gather all data associated with the current location and load it on the dashboard UI. 
        Important, this method doens't make modifications on the glocal variables.
    */
    internal func loadData(){
        print("\nloading data into home UI ...")
        
        // available locations
        print("user locations: ")
        
        self.locationNames = []
        for i in 0...DBHelpers.userLocations.count{
            if let loc = DBHelpers.userLocations[i]{
                print("\(loc.getLocationName())")
                
                self.locationNames.append(loc.getLocationName())
            }
        }
        
        // selected location
        if let name = DBHelpers.currentLocation?.getLocationName(){
            self.selectedLocation = name
            self.chosenPlace.setTitle(name, forState: .Normal)
            print("\nselected location: \(name)\n")
        }else{
            print("\nerror getting location name\n")
        }
        
        // admin status for selected location
        if(DBHelpers.isUserLocationAdmin){
            print("user is location admin\n")
        }else{
            print("user isn't location admin\n")
        }
        
        // if the location has a goal
        if(DBHelpers.currentGoal != nil){
            
            // set days left
            if let daysLeft = DBHelpers.currentGoal!.getDaysLeft(){
                self.daysLeft.text = String(daysLeft) + " dias restantes"
            }else{
                print("failed to get days left")
            }
            
            // wanted to pay
            self.desiredVal.text = "R$" + DBHelpers.currentGoal!.getDesiredValue().stringValue
            
            // probabily is going to pay
            self.moneySpent.text = "R$" + String(self.dbh.getEstimatedAmountToPay().doubleValue.format(".2"))

            // show thought btn
            self.feu.fadeIn(self.thoughtContainer, speed: 0.4)
            
        // if the location doesn't have a goal
        }else{
            print("there is no active goal for this location.")
            
            // if the user isn't coming back from a location deletion
            if(!self.justDeletedLocation){
                /*self.infoWindow("Clique no botão ao lado e defina uma meta de consumo para \(self.selectedLocation).", title: "Crie uma meta de consumo", vc: self)*/
            }
            
            // reset the Bolt animation to 0
            self.resetBoltAnimation()
            
            // hide thought btn
            self.feu.fadeOut(self.thoughtContainer, speed: 0.4)
        }
        
        // show the status of the current location variables
        DBHelpers.showCurrentLocationVariables()
        
        
        // present the floating menu
        self.showFloatingMenu()
    }
    
    
    /*
        Analise distance from goal and through message
    */
    internal func analyzeUserPerformance(){
        print("\nAnalysing user performance for the current goal ...")
        
        // check if the current goal has passed its due date
        if(self.dbh.isCurrentGoalFinished()){
            
            // check if the user has achieved his/her goal
            let desiredValue = DBHelpers.currentGoal!.getDesiredValue()
            let estimatedValue = self.dbh.getEstimatedAmountToPay()
            
            if(desiredValue.floatValue > estimatedValue.floatValue){
                print("user has achieved goal")
                self.showEndOfGoalSuccess()
            }else{
                print("user failed achieving goal displaying failure message")
                self.showEndOfGoalFailure()
            }
        }else{
            
            if let distanceFromGoal:Float = self.dbh.getDistanceOfGoal(){
                print("distance from goal \(distanceFromGoal)")

                // load chart
                self.feu.animateExpensesDay(self.lineChartView, status:Double(distanceFromGoal))
                
                let daysLeft = self.dbh.daysLeftEndOfGoal()
                if let percentageSpent:NSNumber = self.dbh.getGoalPercentageSpent(){
                    
                    // bolt animation
                    self.boltPercentageAnimation(
                        percentageSpent.doubleValue,
                        status:Double(distanceFromGoal)
                    )
                    
                    let percentage = percentageSpent.doubleValue.format(".1")
                    let overload = (percentageSpent.doubleValue - 100.0).format(".1")
                    
                    // executed if the alert hasn't been visualized yet
                    let hasVisualizedMsgForLocation:Bool = DBHelpers.alertMsgController[(DBHelpers.currentLocation?.getObId())!]!
                    
                    var msg = ""
                    if(percentageSpent.doubleValue > 100.0){
                        msg = "Você vai pagar mais do que gostaria por sua eletricidade. Ainda faltam \(daysLeft) dias para terminar o objetivo e o valor predefinido já foi ultrapassado em \(overload)%. Segure os gastos."
                        
                        if(!hasVisualizedMsgForLocation){
                            self.newAlertView(msg)
                        }else{
                            print("user already visualized alert for this location on this session")
                        }
                    }else if(distanceFromGoal > 1.0){
                        msg = "Você ultrapassou o consumo do seu planejamento, \(percentage)% do seu orçamento previsto já foi gasto e ainda temos \(daysLeft) dias até o fim do objetivo. Reduza os gastos e normalize a sua situação."
                        
                        if(!hasVisualizedMsgForLocation){
                            self.newAlertView(msg)
                        }else{
                            print("user already visualized alert for this location on this session")
                        }
                    }else if((distanceFromGoal < 1.0) && (distanceFromGoal > 0.8)){
                        msg = "Você está em uma situação delicada, \(percentage)% do seu orçamento previsto já foi gasto e ainda temos \(daysLeft) dias até o fim do objetivo."
                        
                        if(!hasVisualizedMsgForLocation){
                            self.newAlertView(msg)
                        }else{
                            print("user already visualized alert for this location on this session")
                        }
                    }else if((distanceFromGoal < 0.8) && (distanceFromGoal > 0.6)){
                        //self.chancesDescription.text = "Você está indo bem, mas não relaxe."
                    }else if((distanceFromGoal < 0.6) && (distanceFromGoal > 0.4)){
                        //self.chancesDescription.text = "Você tem tudo sob controle, parabéns."
                    }else if((distanceFromGoal < 0.4) && (distanceFromGoal > 0.0)){
                        //self.chancesDescription.text = "Você tem tudo sob controle, parabéns."
                    }else if(distanceFromGoal < 0.0){
                        if(DBHelpers.currentDevice != nil){
                            //self.chancesDescription.text = "O seu dispositivo de monitoramento está desligado ou desconfigurado, por que não estamos registrando nenhum gasto."
                        }else{
                            //self.chancesDescription.text = "Você ainda não fez nenhuma leitura para este objetivo."
                        }
                    }
                }else{
                    print("problems getting percentage spent")
                }
            }else{
                print("problems getting distance from goal")
            }
        }
    }
    
    
    
    /*
        Switch the current environment and reload UI data with values of global variables
    */
    internal func switchToLocation(locationIdx:Int){
        print("\nswitching data from previous location to selected location ...")
        
        if let location = DBHelpers.userLocations[locationIdx]{
            
            // clean up the user interface
            self.resetUI()
            
            // update the global location object currently being analysed by the system
            DBHelpers.currentLocation = location
            
            // set admin status for selected location
            print("\nsetting location admin status")
            DBHelpers.updateCurUserLocAdminStatus()
            
            // save current location datastructure to release it, in order to save memory
            print("\nsaving old location data")
            DBHelpers.currentLocationData?.save()
            DBHelpers.currentLocationData?.unloadDataStructure()
            
            // select location data from list of location data managers, every location MUST have a data manager object
            print("\ngetting new location datafile")
            if let locData = DBHelpers.locationDataObj[location.getObId()]{
                locData?.loadDataStructure()
                DBHelpers.currentLocationData = locData
            }else{
                print("problem loading selected location data manager")
            }
            
            // select goal for the selected location if there is one
            print("\nselecting goal of the selected location")
            if(DBHelpers.locationGoals[location.getObId()] != nil){
                DBHelpers.currentGoal = DBHelpers.locationGoals[location.getObId()]!!
                print("selected goal \(DBHelpers.currentGoal)")
            }else{
                print("location doesn't have goal")
                DBHelpers.currentGoal = nil
            }
            
            // select monitoring device if there
            print("\nselecting device of the new location if there is one")
            if let locDevice = location.getLocationDevice(){
                DBHelpers.currentDevice = locDevice
                print("selected location device \(DBHelpers.currentDevice)")
            }else{
                print("location doesn't have a device")
                DBHelpers.currentDevice = nil
            }
            
            // reload data for current screen
            self.loadData()
            
            // analyze user data
            self.analyzeUserPerformance()
        }else{
            print("problems getting the location indicated by the index \(locationIdx)")
        }
    }
    
    
    /*
        Change the status of the current goal to 'archived'
    */
    internal func archiveGoal(){
        print("archiving current goal ...")
        
        // delete the goal from the user-location-goal relation
        let archiveGoalQuery:PFQuery = DBHelpers.currentGoal!.openedGoalForLocation(
            PFUser.currentUser()!,
            location: DBHelpers.currentLocation!
        )
        
        archiveGoalQuery.findObjectsInBackgroundWithBlock({
            (goals:[AnyObject]?, error:NSError?) -> Void in
            
            if(error == nil){
                if let goalRelObj = goals?.first as? PFObject{
                    
                    goalRelObj[self.dbu.DBH_REL_USER_GOALS_STATUS] = self.dbu.DBH_REL_USER_GOALS_POS_STAT[1] // archived
                    
                    goalRelObj.saveInBackgroundWithBlock {
                        (success, error) -> Void in
                        
                        if(success){
                            print("display input to get the actual amount paid, in order to finish goal. Or show the archive it message")
                            
                            DBHelpers.eraseGoalTraceFromDatafile()
                            
                            // Reset current goal
                            DBHelpers.locationGoals[(DBHelpers.currentLocation?.getObId())!] = nil
                            DBHelpers.currentGoal = nil
                            self.loadData()
                            
                            self.infoWindow("O objetivo foi arquivado, você pode inserir o valor real cobrado pela companhia elétrica em \n\n'Objetivos/Objetivos Anteriores'.", title: "Objetivo arquivado", vc: self)
                        }else{
                            print("there was a problem archiving the current goal")
                            self.callerViewController.infoWindow("Houve um erro ao arquivar o objetivo atual", title:"Falha na operação", vc: self.callerViewController)
                        }
                    }
                }else{
                    print("problem getting user-location object")
                }
            }else{
                print("problem getting user-location object \(error!.description)")
            }
        })
    }
    
    
    /*
        Get all days within the period of the current goal
    */
    internal func getDaysOfCurrentGoal() -> Array<AnyObject>{
        
        // get the goal's start date
        if let startDate:NSDate = DBHelpers.currentGoal?.getStartingDate(){
            
            // get current date
            if let endDate:NSDate = NSDate(){
                let days:Array<AnyObject> = DBHelpers.currentLocationData!.getDaysWithReadingForGoal(
                    startDate, endDate:endDate
                )
                
                return days
            }else{
                print("error getting current date")
            }
        }else{
            print("error getting start date")
        }
        
        return []
    }
    
    
    override internal func setReadingValue(input:Double){
        // reset the animation controller variable after a successfull input
        FrontendUtilities.hasAnimated[self.feu.HOME_ANIMATION_BOLT] = false
        
        self.loadData()
        self.analyzeUserPerformance()
    }

    
    /*
        Get a Location by searching for its name
    */
    internal func getLocactionByName(locationName:String) -> Location?{
        
        // protect the for loop
        if(DBHelpers.userLocations.count > 0){
            
            // check on each location for the name
            for i in 0...(DBHelpers.userLocations.count - 1){
                
                // check if the names match
                if let locName = DBHelpers.userLocations[i]?.getLocationName(){
                    if(locationName == locName){
                        if let loc:Location = DBHelpers.userLocations[i]{
                            return loc
                        }else{
                            print("failed to get location id")
                        }
                    }
                }else{
                    print("failed to get location name")
                }
            }
        }
        
        return nil
    }

    
    
    // NAVIGATION
    /*
        Go to the new goal screen
    */
    @IBAction func goNewGoal(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_DEFINE_GOAL, sender: self)
    }

    
    /*
        Navigate to the readings log page
    */
    @IBAction func showAllReadings(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_DAILY_READINGS, sender: self)
    }
    
    
    /*
        Go to the new location decision screen
    */
    @IBAction func goNewLocation(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_CHOOSE_HOW_ADD_LOC, sender: self)
    }
    
    
    
    /*
        Redirect the user to the location details page sending the current location data
    */
    @IBAction func goLocationDetails(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_LOCATION_DETAILS, sender: NSObject())
    }
    
    
    /*
        Get response after location deletion on the location details screen
    */
    @IBAction func unwindAfterLocationDeletion(segue:UIStoryboardSegue) {
        if let _:PlaceDetailsViewController = segue.sourceViewController as? PlaceDetailsViewController{
            
            self.justDeletedLocation = true
            self.resetUI()
            self.viewDidLoad()
        }
    }
    
    
    /*
        Get response after location creation
    */
    @IBAction func unwindAfterNewLocation(segue:UIStoryboardSegue) {
        self.resetUI()
        self.viewDidLoad()
    }

    
    
    /*
        Prepare data to next screen
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // stop the blinking animation
        self.stopBlinking()
        self.feu.stopPulsing()
        
        if(segue.identifier == self.feu.SEGUE_DAILY_READINGS){
            let destineVC = (segue.destinationViewController as! DailyReadingsViewController)
            destineVC.days = self.getDaysOfCurrentGoal()
        }
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
}
