//
//  DicasViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class DicasViewController: BaseViewController, iCarouselDataSource, iCarouselDelegate  {

    
    // VARIABLES
    @IBOutlet weak var homeBtn: UIBarButtonItem!
    @IBOutlet weak var menuBtn: UIBarButtonItem!
    @IBOutlet weak var carousel: iCarousel!
    
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils = DBUtils()
    
    internal var tips = [Int: Tip]()
    internal var selectedTip:Tip = Tip()
    
    var items: [Int] = []
    var lastVisualized: Int = 0
    
    
    
    // INITIALIZERS
    override func awakeFromNib(){
        super.awakeFromNib()
    }
    
    override func viewDidAppear(animated: Bool) {
        // UI initialization
        self.customizeNavBar(self)
        self.customizeMenuBtn(self.menuBtn, btnIdentifier: self.feu.ID_MENU)
        self.customizeMenuBtn(self.homeBtn, btnIdentifier: self.feu.ID_HOME)
        
        // LOGIC
        self.loadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // binds the show menu toogle action implemented by SWRevealViewController to the menu button
        if self.revealViewController() != nil {
            self.menuBtn.target = self.revealViewController()
            self.menuBtn.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // initializes carousel
        self.carousel.dataSource = self
        self.carousel.delegate = self
        self.carousel.type = .Rotary
        self.carousel.decelerationRate = 0.5
        self.carousel.bounces = true
        self.carousel.userInteractionEnabled = true
        
        self.lastVisualized = 1
    }
    
    
    
    // UI
    // Carousel
    //---------
    /*
        Number of items in the carousel
    */
    func numberOfItemsInCarousel(carousel: iCarousel) -> Int{
        return self.tips.count
    }
    
    /*
        Load nib into carousel
    */
    func carousel(carousel: iCarousel, viewForItemAtIndex index: Int, reusingView view: UIView?) -> UIView{
        
        var itemView: TipCardView
        
        // get a tip out of the list of tips
        if let tip = self.tips[index]{
            
            //create new view if no view is available for recycling
            if (view == nil){
                itemView = UIView.loadFromNibNamed("TipCard") as! TipCardView
                
                itemView.parentVC = self
                itemView.cardIdx = index
                itemView.tipTitle.text = tip.getTipTitle()
                itemView.tipDescription.text = tip.getTipInfo()
                
                let pic = tip.getTipPicture()
                if(pic != nil){
                    pic!.getDataInBackgroundWithBlock({
                        (imageData: NSData?, error: NSError?) -> Void in
                        
                        if (error == nil) {
                            let image = UIImage(data:imageData!)
                            itemView.tipView.image = image
                        }
                    })
                }else{
                    itemView.tipView.image = UIImage(named:"imgres.jpg")
                }
                
                return itemView
            }else{
                print("returning reused view to save resources")
            }
        }else{
            print("problem getting tip out of array of tips")
        }
        
        itemView = view as! TipCardView
        
        return itemView
    }
    
    /*
        Controls the space between the views
    */
    func carousel(carousel: iCarousel, valueForOption option: iCarouselOption, withDefault value: CGFloat) -> CGFloat{
        
        if (option == .Spacing){
            return value * 0.8;
        }
        
        return value
    }
    
    /*
        Identify when the current view changes
    */
    func carouselCurrentItemIndexDidChange(carousel: iCarousel) {
        
        let currentItem = self.carousel.currentItemIndex + 1
        
        if(self.lastVisualized < currentItem){
            // to do
        }else{
            // to do
        }
        
        lastVisualized = currentItem
    }
    
    /*
        Selects an item from the carousel
    */
    func carousel(carousel: iCarousel, didSelectItemAtIndex index: Int) {
        print("selected location...")
    }
    
    
    
    // LOGIC
    /*
        Get list of tips from the app backend
    */
    internal func loadData(){
        print("loading tips ...")
        
        // request data from the app backend
        PFCloud.callFunctionInBackground("getAllTips", withParameters: nil) {
            (tipsObjects, error) in
            
            if (error == nil){
                if let tipsArray:Array<AnyObject> = tipsObjects as? Array<AnyObject> {
                    print("\navailable tips: \n\(tipsArray)")
                    
                    for i in 0...(tipsArray.count - 1){
                        if let tipObj = tipsArray[i] as? PFObject{
                            self.tips[i] = Tip(tip: tipObj)
                        }else{
                            print("problem unwraping tip object from array")
                        }
                    }
                    
                    self.carousel.reloadData()
                }else{
                    print("problems converting results into array of tips.")
                }
            }else{
                print("\nerror: \(error)")
            }
        }
    }

    
    
    /*
        Share a tip on Facebook
    */
    internal func shareTip(tipIdx:Int){
        print("\nsharing tip with index \(tipIdx) ...")
        
        // get tip data
        if let tip:Tip = self.tips[tipIdx]{
            print("sharing tip \(tip)")
        }else{
            print("problems to get tip at index \(tipIdx)")
        }
    }
    
    
    
    
    
    // NAVIGATION
    /*
        Go home
    */
    @IBAction func goHome(){
        self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
