//
//  LogoutTableViewCell.swift
//  x
//
//  Created by Diego Silva on 11/12/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class LogoutTableViewCell: UITableViewCell {


    // VARIABLES
    @IBOutlet weak var btnImage: UIImageView!
    @IBOutlet weak var btnLabel: UILabel!
    
    
    // INITIALIZERS
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
