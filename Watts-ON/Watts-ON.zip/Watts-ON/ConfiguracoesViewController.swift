//
//  ConfiguracoesViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class ConfiguracoesViewController: BaseViewController {
 

    // VARIABLES
    @IBOutlet weak var menuBtn: UIBarButtonItem!
    @IBOutlet weak var homeBtn: UIBarButtonItem!
    
    internal let dbh:DBHelpers = DBHelpers()
    
    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // UI initialization
        self.customizeNavBar(self)
        self.customizeMenuBtn(self.menuBtn, btnIdentifier: self.feu.ID_MENU)
        self.customizeMenuBtn(self.homeBtn, btnIdentifier: self.feu.ID_HOME)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // binds the show menu toogle action implemented by SWRevealViewController to the menu button
        if self.revealViewController() != nil {
            menuBtn.target = self.revealViewController()
            menuBtn.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }

    
    
    // UI
    /*
        Delete the current account and dissociate the user of all devices available on the database, event thought the user is registered wether as admin or a regular user.
    */
    @IBAction func deleteAccount(sender: AnyObject) {
        self.infoWindowWithCancel("Esta é uma operação definitiva, os dados deletados não poderão ser recuperados", title:"Atenção", vc:self)
    }
    
    
    //Information
    //-----------
    /*
        Overrides the info window method to perform a callback action depending on the user choice, delete or not their account
    */
    internal override func infoWindowWithCancel(txt:String, title:String, vc:UIViewController) -> Void{
        
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(
            UIAlertAction(title: "Ok", style: .Default, handler: {
                (action: UIAlertAction) in
            
                print("\nDeleting user account ...")
                self.dbh.deleteAccount(self)
            })
        )
        
        refreshAlert.addAction(
            UIAlertAction(title: "Cancel", style: .Default, handler: {
                (action: UIAlertAction!) in
                print("\nUser cancelled the delete account operation")
            })
        )
        
        vc.presentViewController(refreshAlert, animated: true, completion: nil)
    }

    
    @IBAction func showFAQ(sender: AnyObject) {
        print("show FAQ")
        self.infoWindow("Perguntas Frequentes: \nVocê está seguro utilizando o Watts-ON?\nSim, todos os seus dados são criptografados e bem protegidos. \n\nComo adicionar um novo dispositivo?\nTenha a chave do produto \"activation key\", que se encontrada na embalagem e siga para a tela de configurações -> locais -> 'adicionar novo local'", title: "Perguntas Frequentes", vc: self)
    }
    
    
    @IBAction func showTerms(sender: AnyObject) {
        print("show terms and conditions")
        self.infoWindow("Uma vez criada uma conta no Watts-ON, você concorda com estes termos e condições de uso.\n\nAs chaves de ativação e compartilhamento são únicas, elas são a única forma de associar novos usuários aos dispositivos (locais), a responsabilidade sobre quem está associado a cada local, e pode visualizar as informações daquele local, é somente do usuário administrador possuidor das chaves de compartilhamento e ativação.", title: "Perguntas Frequentes", vc: self)
    }
    
    
    @IBAction func showContactAdress(sender: AnyObject) {
        print("show contact info")
        self.infoWindow("Para mais informações sobre este software e outros fornecidos pela IoThinking, visite www.iothinking.com", title: "Contato", vc: self)
    }
    
    
    
    // NAVIGATION
    /*
        Go home
    */
    @IBAction func goHome(){
        self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
