//
//  CadastroDecisionViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/23/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class AddPlaceDecisionViewController: BaseViewController {

    
    // VARIABLES
    @IBOutlet weak var doubtBtn:UIButton!
    @IBOutlet weak var info: UILabel!
    
    // CONSTANTS
    internal let selector:Selector = Selector("goHome")
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()

        //assign button to navigationbar
        self.navigationItem.leftBarButtonItem = self.feu.getHomeNavbarBtn(self.selector, parentVC: self)
        self.feu.roundIt(self.doubtBtn, color:self.feu.LIGHT_GREY)
    }

    
    
    // UI
    /*
        Show information outlet
    */
    @IBAction func showInfo(sender: AnyObject) {
        if(self.info.hidden){
            self.feu.fadeIn(self.info, speed: 0.6)
        }else{
            self.feu.fadeOut(self.info, speed: 1.0)
        }
    }
    
    
    
    // NAVIGATION
    /*
        Send the user back to the home screen by dismissing the current page from the pages stack
    */
    internal func goHome(){
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    
    /*
        Get response from "user create location"
    */
    @IBAction func unwindAfterLocationCreation(segue:UIStoryboardSegue) {
        if let upsertVC:UpsertPlaceViewController = segue.sourceViewController as? UpsertPlaceViewController{
            print("came back from new location ...")
            
            self.performSegueWithIdentifier(self.feu.SEGUE_UNWIND_AFTER_NEW_LOC, sender: upsertVC)
        }
    }
    
    
    /*
        Get response from the "user joined location"
    */
    @IBAction func unwindAfterLocationJoinOperation(segue:UIStoryboardSegue) {
        if let joinPlaceVC:AddPlaceAsGuestViewController = segue.sourceViewController as? AddPlaceAsGuestViewController{
            print("came back from join location ...")
            
            self.performSegueWithIdentifier(self.feu.SEGUE_UNWIND_AFTER_NEW_LOC, sender: joinPlaceVC)
        }
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
