//
//  RewardsViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/14/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class RewardsViewController: PFQueryTableViewController {

    
    // VARIABLES
    @IBOutlet weak var homeBtn: UIBarButtonItem!
    @IBOutlet weak var menuBtn: UIBarButtonItem!
    @IBOutlet weak var rewardsType: UISegmentedControl!
    
    internal let feu:FrontendUtilities = FrontendUtilities()
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils = DBUtils()
    
    internal var rewards = [NSIndexPath: Reward]()
    internal var likedRewards = [Int: Reward]()
    internal var selectedReward:Reward? = nil
    internal var suggestedRewards = [NSIndexPath: NSIndexPath]()
    
    internal let CURRENT_REW_TYPE_ALL  = "all"
    internal let CURRENT_REW_TYPE_USER = "user"
    internal var currentRewardType     = "all"
    
    internal let DEFAULT_SOURCE_VAL = "inside"
    internal var navigationSource   = "inside"
    
    internal let CELL_FILTER_FOR_SELECTION = UIColor.blackColor().colorWithAlphaComponent(0.4)
    internal let CELL_FILTER_FOR_SELECTION_DARKER = UIColor.blackColor().colorWithAlphaComponent(0.001)
    
    
    // INITIALIZERS
    override func viewWillAppear(animated: Bool) {
        
        // UI initialization
        let bvc:BaseViewController = BaseViewController()
        bvc.customizeNavBar(self)
        bvc.customizeMenuBtn(self.menuBtn, btnIdentifier: self.feu.ID_MENU)
        bvc.customizeMenuBtn(self.homeBtn, btnIdentifier: self.feu.ID_HOME)
        
        // Data initialization
        //self.loadView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("navigation source: \(self.navigationSource)")
        self.getLikedRewards()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self

        // initilialize the elements of the view cell according to the source
        if(self.navigationSource == self.DEFAULT_SOURCE_VAL){
            
            // binds the show menu toogle action implemented by SWRevealViewController to the menu button
            if self.revealViewController() != nil {
                self.menuBtn.target = self.revealViewController()
                self.menuBtn.action = "revealToggle:"
                self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            }
        }else{
            self.menuBtn.enabled = false
            //self.addReward.enabled = false
        }
    }

    
    // UI
    /*
        Block the user of making anything until he/she creates a location
    */
    internal func lockUI(){
        
    }
    
    /*
        Unlock the UI
    */
    internal func unlockUI(){
        
    }
    
    
    /*
        Defines the sort of Reward was selected
    */
    @IBAction func selectRewardsType(sender: AnyObject) {
        
        switch self.rewardsType.selectedSegmentIndex{
        case 0:
            print("show all rewards")
            
            self.currentRewardType = self.CURRENT_REW_TYPE_ALL
            self.loadObjects()
            
        case 1:
            print("show only user's")
            
            self.currentRewardType = self.CURRENT_REW_TYPE_USER
            self.loadObjects()
            
        default:
            break;
        }
    }
    
    
    /*
        Fetch a cell of type RewardCell into the table with data from the backend
    */
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath, object: PFObject!) -> PFTableViewCell? {
    
        // creates a new regular cell
        let cell = tableView.dequeueReusableCellWithIdentifier("RewardCell", forIndexPath: indexPath) as! RewardTableViewCell
        
        // create a new tip object with values from server
        let reward:Reward = Reward(reward: object)
        
        // disable the like button if user already liked the reward
        if(self.checkIfAlreadyLikeReward(reward)){
            cell.likeBtn.enabled = false
        }
        
        // load values from object that came from server into the prototype cell Outlets
        cell.rewardTitle.text = reward.getRewardTitle()
        cell.rewardNumLikes.text = reward.getRewardLikes().stringValue
        cell.hiddenNumLikes.text = reward.getRewardLikes().stringValue
        
        let rew_pic = reward.getRewardPicture()
        if(rew_pic != nil){
            rew_pic!.getDataInBackgroundWithBlock({
                (imageData: NSData?, error: NSError?) -> Void in
                
                if (error == nil) {
                    let image = UIImage(data:imageData!)
                    cell.rewardImage.image = image
                    reward.setRewPictureImg(image)
                }
            })
        }else{
            cell.rewardImage.image = UIImage(named:"imgres.jpg")
        }
        
        // initilialize the elements of the view cell according to the source
        if(self.navigationSource == self.DEFAULT_SOURCE_VAL){
            self.initilizeCellDetailsForRewards(cell, reward:reward, indexPath:indexPath)
        }else{
            self.initilizeCellDetailsForNewGoal(cell, reward:reward, indexPath:indexPath)
        }
        
        cell.rewardNumLikes.text = String(reward.getRewardLikes())
        
        // push the selected tip into the list of tips
        self.rewards[indexPath] = reward
        
        // pass a reference to this view controller and insert the reward object inside of its cell in order to make the possible to use the method perfom segue with identifier within the table view cell
        cell.cellReward = reward
        cell.selectedIndexPath = indexPath
        cell.parentController = self
        
        return cell
    }
    

    /*
        Initialize cell for source being Rewards
    */
    internal func initilizeCellDetailsForRewards(cell:RewardTableViewCell, reward:Reward, indexPath:NSIndexPath){
        cell.hiddenNumLikes.hidden = true
        
        // check if the current user is the owner of the reward and enable/disabled the table item
        if(PFUser.currentUser()?.objectId == reward.getRewardOwner()?.objectId){
            cell.editingBtn.enabled = true
            cell.deleteBtn.enabled = true
            cell.editingBtn.hidden = false
            cell.deleteBtn.hidden = false
        }else{
            cell.editingBtn.enabled = false
            cell.deleteBtn.enabled = false
            cell.editingBtn.hidden = true
            cell.deleteBtn.hidden = true
            
            self.suggestedRewards[indexPath] = indexPath
        }
    }
    
    
    /*
        Initialize cell for the creation of a new goal
    */
    internal func initilizeCellDetailsForNewGoal(cell:RewardTableViewCell, reward:Reward, indexPath:NSIndexPath){
        
        /* show select button and enable action
        cell.selectBtn.hidden  = false
        cell.selectBtn.alpha   = 1.0
        */

        cell.selectBtn.enabled = true
        
        // change actions' container appearence
        cell.actionsContainer.backgroundColor = self.CELL_FILTER_FOR_SELECTION_DARKER
        
        // change filter
        cell.cellFilter.backgroundColor = self.CELL_FILTER_FOR_SELECTION
        
        // hide buttons
        cell.editingBtn.hidden     = true
        cell.deleteBtn.hidden      = true
        cell.editingBtn.hidden     = true
        cell.deleteBtn.hidden      = true
        cell.rewardNumLikes.hidden = true
        cell.hiddenNumLikes.hidden = false
        
        // disable actions
        cell.editingBtn.enabled     = false
        cell.deleteBtn.enabled      = false
        cell.editingBtn.enabled     = false
        cell.deleteBtn.enabled      = false
        cell.rewardNumLikes.enabled = true
        
        // check if the current user is the owner of the reward and enable/disabled the table item
        if(!(PFUser.currentUser()?.objectId == reward.getRewardOwner()?.objectId)){
            print("mark reward as a suggestion.")
            self.suggestedRewards[indexPath] = indexPath
        }
    }
    
    
    /*
        Overrides the table row height, it specifies the height of the profile table view cell
    */
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        
        // if it must show only user rewards loop through the suggested rewards list and hide the cell if match the current indexPath being threated
        if(self.currentRewardType != self.CURRENT_REW_TYPE_ALL){
            
            if(self.suggestedRewards[indexPath] != nil){
                print("found suggestion, hide cell")
                
                return 0.0
            }
        }
        
        return 167.0
    }

    
    /*
        Row selection event
    */
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        let indexPath = tableView.indexPathForSelectedRow
        
        self.selectedReward = self.rewards[indexPath!]
        
        if(self.navigationSource == self.DEFAULT_SOURCE_VAL){
            self.performSegueWithIdentifier(self.feu.SEGUE_REWARD_SHOW, sender: self)
        }else{
            self.performSegueWithIdentifier("SelectReward", sender: self.selectedReward)
        }
    }
    
    
    // INFORMATION
    /*
        Show an information window allowing the user to cancel his/her choice
    */
    internal func infoWindowWithCancel(txt:String, title:String, objId:String, selectedIndexPath:NSIndexPath) -> Void{
        
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction) in
            let query = Reward.query()
            query!.getObjectInBackgroundWithId(objId){
                (rewardObj, error) -> Void in
                
                print("reward \(rewardObj)")
                
                if(error == nil){
                    
                    print("found the reward object")
                    rewardObj?.deleteInBackgroundWithBlock{
                        (success, error) -> Void in
                        
                        if(error == nil){
                            print("deleted successfully")
                            self.infoWindow("Recompensa deletada com sucesso", title: "Operação concluída")
                            
                            print("selected index path \(selectedIndexPath)")
                            
                            self.loadObjects()
                        }else{
                            print("failed to create new Reward")
                            self.infoWindow("Falha ao deletar recompensa", title: "Falha na operação")
                        }
                    }
                }else{
                    print("error, no reward found for the id \(objId)")
                    self.infoWindow("Erro de conexão com o servidor", title: "Erro de conexão")
                }
            }
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: { (action: UIAlertAction!) in
            
            print("\nuser canceled operation")
        }))
        
        self.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    /*
        Show inforamtion window to send a simple message
    */
    internal func infoWindow(txt:String, title:String) -> Void{
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction) in
            
            print("\nuser clicked ok ...")
        }))
        
        self.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    // LOGIC
    /*
        Parse does the querying logic based on the model class which extends from PFObject and on the view settings
    */
    override func queryForTable() -> PFQuery {
        let query = Reward.query()
        return query!
    }
    
    
    /* 
        Get list of rewards liked by current user
    */
    internal func getLikedRewards(){
        
        let rewardAux:Reward = Reward()
        
        let query:PFQuery = rewardAux.getRewardsLikedByUser(PFUser.currentUser()!)
        query.findObjectsInBackgroundWithBlock{
            (let objects, error) -> Void in
            
            if(error == nil){
                
                var count = 0
                for obj in objects!{
                    if let o:PFObject = obj as? PFObject{
                        
                        let likedReward:Reward = Reward(reward: o.objectForKey(self.dbu.DBH_REL_USER_REWARD_REWARD) as! PFObject)
                        
                        print("liked Reward id: \(likedReward.getObId())")
                        self.likedRewards[count] = likedReward
                        
                        count++
                    }else{
                        print("error, the reward pointer is null")
                    }
                }
                
                self.loadObjects()
            }else{
                print("error, no user like reward relationship object found")
                
                self.loadObjects()
            }
        }
    }
    
    
    /*
        Check if user already liked a selected reward
    */
    internal func  checkIfAlreadyLikeReward(selectedReward:Reward) -> Bool{
        
        for i in 0...self.likedRewards.count{
            if(self.likedRewards[i]?.getObId() == selectedReward.getObId()){
                return true
            }
        }
        
        return false
    }
    
    
    // NAVIGATION
    /*
        Go to new reward screen
    */
    @IBAction func goNewReward(sender: AnyObject) {
        self.performSegueWithIdentifier(self.feu.SEGUE_REWARD_ADD, sender: nil)
    }
    
    
    
    /*
        Go home
    */
    @IBAction func goHome(){
        self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
    }
    
    
    /*
        Prepare data to next screen
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if(segue.identifier == self.feu.SEGUE_REWARD_SHOW){
            let destineVC = (segue.destinationViewController as! RewardViewController)
            destineVC.reward = self.selectedReward
            
        }else if ((segue.identifier == self.feu.SEGUE_REWARD_UPDATE)||(segue.identifier == self.feu.SEGUE_REWARD_ADD)){
            
            let destineVC = (segue.destinationViewController as! NewRewardViewController)
            destineVC.reward = sender as? Reward
            
            if(segue.identifier == self.feu.SEGUE_REWARD_UPDATE){
                print("\ntrying to update selected reward object: \(sender)")
                destineVC.task = "update"
            }else{
                print("\ntrying to create a reward")
                destineVC.task = "create"
            }
        }else if (segue.identifier == "SelectReward"){
            print("\nunwind segue to Goal screen with selected Reward ...")
        }
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
