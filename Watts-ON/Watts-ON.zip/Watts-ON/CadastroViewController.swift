//
//  CadastroViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/20/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit
import Parse
import Bolts

class CadastroViewController: BaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    // VARIABLES
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var surname: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var passConfirmation: UITextField!
    @IBOutlet weak var imageSizeWarning: UILabel!
    @IBOutlet weak var pictureBtn: UIButton!
    
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils = DBUtils()

    internal var permissions = [""]
    internal var imagePicker = UIImagePickerController()
    internal var profilePicture: PFFile? = nil
    
    internal let imgTooLargeMsg = "A imagem selecionada é muito grande, por favor selecione outra."
    
   
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()

        // initialize GUI components
        self.permissions = self.feu.FACEBOOK_PERMISSIONS
        
        // setup the input elements that are going to respond to keyboard events
        self.name.delegate = self
        self.surname.delegate = self
        self.email.delegate = self
        self.pass.delegate = self
        self.passConfirmation.delegate = self
        
        // setup the distance that the keyboard is going to move
        self.kbHeight = 70
        
        self.setScroller()
        self.resetUI()
    }

    
    
    // UI
    /*
        Reset UI elements
    */
    internal func resetUI(){
        self.name.text = ""
        self.surname.text = ""
        self.email.text = ""
        self.pass.text = ""
        self.passConfirmation.text = ""
        
        self.name.enabled = true
        self.surname.enabled = true
        self.email.enabled = true
        self.pass.enabled = true
        self.passConfirmation.enabled = true
        
        self.customizePicButton()
    }
    
    
    /*
        Customize the user picture btn
    */
    internal func customizePicButton(){
        self.feu.roundIt(self.pictureBtn, color:self.feu.LIGHT_BLUE)
    }
    
    
    /*
        Configure the dimensions of the scroller view
    */
    internal func setScroller(){
        self.scrollView.userInteractionEnabled = true
        self.scrollView.frame = self.view.bounds
        self.scrollView.contentSize.height = self.contentView.frame.size.height
        self.scrollView.contentSize.width = self.contentView.frame.size.width
    }
    
    
    /*
        Select a new picture for the reward from the user's camera roll
    */
    @IBAction func selectPictureFromRoll(sender: AnyObject) {
        print("\nselect new reward picture from camera roll")
        
        // reset warning
        self.imageSizeWarning.hidden = true
        
        // image picker initialization
        self.imagePicker.delegate = self
        self.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
        self.imagePicker.allowsEditing = false
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum){
            print("selecting image from roll ...")
            
            self.presentViewController(self.imagePicker, animated: true, completion: nil)
        }
    }
    
    
    // MARK: - Image picker
    //---------------------
    /*
        Open the camera roll
    */
    internal func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        self.fetchProfileImg(info)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    /*
        Fetch profile image
    */
    internal func fetchProfileImg(info: [String : AnyObject]){
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            let imageData = UIImagePNGRepresentation(image)
            print("\nimage file size: \(imageData?.length)")
            
            if(self.validImageSize((imageData?.length)!)){
                self.profilePicture = self.convertImageToPFFile(image)!
            }else{
                print("\nwarning, image file size is to large")
            }
        }
    }
    
    /*
        Convert image to PFFile
    */
    internal func convertImageToPFFile(image:UIImage?) -> PFFile?{
        if let img = image{
            self.pictureBtn.setImage(img, forState: .Normal)
            let imgData:NSData = UIImagePNGRepresentation(img)!
            
            return PFFile(name: "profile picture", data: imgData)
        }else{
            return nil
        }
    }
    
    /*
        Actions taken if the user cancel the select picture operation
    */
    internal func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("\nuser canceled the operation")
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    /*
        If the profile picture is too large, show a message and return false
    */
    internal func validImageSize(size:Int) -> Bool{
        if(size < self.feu.IMAGE_SIZE){
            return true
        }
        
        self.imageSizeWarning.text   = self.imgTooLargeMsg
        self.imageSizeWarning.hidden = false
        
        return false
    }
    
    
    /*
        User registration
    */
    @IBAction func save(sender: AnyObject) {
        print("Registration process")
        
        self.validateUserData()
    }

    
    
    // LOGIC
    /* 
        Get Facebook information to sign up the user
    */
    @IBAction func facebookSignup(sender: AnyObject) {
        
        let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
        fbLoginManager .logInWithReadPermissions(self.permissions, handler: {
            (result, error) -> Void in
            
            if (error == nil){
                if let fbloginresult : FBSDKLoginManagerLoginResult = result{
                    if(fbloginresult.grantedPermissions.contains("email")){
                        print("facebook data has been confirmed \n")
                        
                        // Create request for Facebook user's data
                        let request = FBSDKGraphRequest(graphPath:"me", parameters: ["fields":"name, email"])
                        
                        // Send request to Facebook
                        request.startWithCompletionHandler {
                            (connection, result, error) in
                            
                            if error != nil {
                                print("error getting user info from facebook \n")
                            }
                            else if let userData = result as? [String:AnyObject] {
                                // fill in and disable fields
                                self.pass.text = (userData["id"] as? String)!
                                self.passConfirmation.text = (userData["id"] as? String)!
                                self.email.text = (userData["email"] as? String)!
                                
                                //let fullName = (userData["name"] as? String)!
                                let fullNameArr = (userData["name"] as? String)!.characters.split{$0 == " "}.map(String.init)
                                
                                if(!(fullNameArr[0] == "")){
                                    self.name.text = fullNameArr[0]
                                }
                                
                                if(!(fullNameArr[1] == "")){
                                    self.surname.text = fullNameArr[1]
                                }
                                
                                self.email.enabled = false
                                self.pass.enabled = false
                                self.passConfirmation.enabled = false
                                
                                // also sign user on Parse after it gets the user's profile picture
                                self.requestProfilePicture(self.pass.text!, facebookLoginManager:fbLoginManager)
                            }
                        }
                    }else{
                        self.infoWindow("Operação cancelada.", title: "Aviso", vc: self)
                    }
                }
            }else{
                print("Facebook intial data requesition error: \(error.localizedDescription) \n")
                self.infoWindow("Falha ao confirmar dados com Facebook", title: "Aviso", vc: self)
            }
        })
    }
    
    
    /*
        Make an asynchrounous call to the to get the facebook user's profile picture and place it into
        the local image variable.
    */
    func requestProfilePicture(facebookID:String, facebookLoginManager:FBSDKLoginManager) {
        let pictureURL = "https://graph.facebook.com/\(facebookID)/picture?type=large&return_ssl_resources=1"
        
        let URLRequest = NSURL(string: pictureURL)
        let URLRequestNeeded = NSURLRequest(URL: URLRequest!)
        
        NSURLConnection.sendAsynchronousRequest(URLRequestNeeded, queue: NSOperationQueue.mainQueue(),completionHandler: {
            (response: NSURLResponse?, data: NSData?, error: NSError?) -> Void in
            
            if error == nil {
                if let img = UIImage(data: data!){
                    self.pictureBtn.setImage(img, forState: .Normal)
                    
                    let imgData:NSData = UIImagePNGRepresentation(img)!
                    self.profilePicture = PFFile(name: "profile picture", data: imgData)
                    
                    facebookLoginManager.logOut()
                }
            }
            else {
                print("Facebook picture request error: \(error?.localizedDescription) \n")
                self.infoWindow("Erro ao pegar foto de perfil do facebook.", title:"Aviso", vc:self)
            }
        })
    }
    
    
    /*
        Validate user data
    */
    internal func validateUserData(){
        
        // validate data
        if(self.feu.isValidEmail(self.email.text!) == true){
            
            PFCloud.callFunctionInBackground("isEmailTaken", withParameters: [
                "email": self.email.text!
            ]) {
                (answer, error) in
                    
                if (error == nil){
                    if let result:Int = answer as? Int{
                        if(result == 1){
                            
                            print("valid email, no one is using it")
                            if(self.pass.text == self.passConfirmation.text){
                                self.registerUser()
                            }else{
                                self.infoWindow("Senha e confirmação da senha devem ser iquais.", title:"Aviso", vc:self)
                            }
                            
                        }else if(result == 0){
                            print("email already registered")
                            self.infoWindow("Este email já está cadastrado, se cadastre com um novo email.", title:"Aviso", vc:self)
                        }else{
                            print("unknown error")
                            self.infoWindow("Problemas ao verificar email", title:"Falha operacional", vc:self)
                        }
                    }else{
                        print("unknown error")
                        self.infoWindow("Problemas ao verificar email", title:"Falha operacional", vc:self)
                    }
                }
            }
        }else{
            self.infoWindow("Por favor insira um endereço de email válido.", title:"Aviso", vc:self)
        }
    }
    
    
    /*
        Register a new user and connect it to a location
    */
    internal func registerUser(){
        print("\ntrying to create free account ...")
        
        DBHelpers.freeAccountRegistration(
            self.email.text!,
            name: self.name.text!,
            password: self.pass.text!,
            profilePicture: self.profilePicture,
            sender:self
        )
    }    
    
    
    
    // MANDATORY
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
