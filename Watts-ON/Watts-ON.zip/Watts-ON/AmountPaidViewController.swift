//
//  AmountPaidViewController.swift
//  x
//
//  Created by Diego Silva on 11/4/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class AmountPaidViewController: UIViewController {

    
    
    // VARIABLES
    @IBOutlet weak var amountPaid: UITextField!
    @IBOutlet weak var saveBtn: UIButton!
    
    internal let bvc:BaseViewController = BaseViewController()
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils = DBUtils()
    internal var callerViewController: HomeViewController = HomeViewController()
    internal var closedGoal:Bool = false
        
        
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.amountPaid.keyboardType = .NumberPad
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "dismissViewOnBackgroundTap")
        self.view.addGestureRecognizer(tapGesture)
        self.view.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.8)
    }
        
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
        
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
        
        
        
    // UI
    /*
        Pop up dialog
    */
    func showInView(aView: UIView!, animated: Bool){
            
        aView.addSubview(self.view)
        if animated{
            self.showAnimate()
        }
    }
        
    func showAnimate(){
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        });
    }
        
        
    /*
        Close input dialog view
    */
    @IBAction func closePopup(sender: AnyObject) {
        self.removeAnimate()
    }
        
        
    /*
        Close input dialog view
    */
    func dismissViewOnBackgroundTap(){
        self.removeAnimate()
    }
        
    func removeAnimate(){
        UIView.animateWithDuration(0.5, animations: {
            // perform action on a separeted thread
            self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
            self.view.alpha = 0;
                
            self.view.frame = CGRectMake(
                self.view.frame.origin.x,
                self.view.frame.origin.y + 600,
                self.view.frame.size.width,
                self.view.frame.size.height
            )
        }, completion:{
            (finished : Bool)  in
            
            if(!self.closedGoal){
                self.callerViewController.archiveGoal()
            }
            
            self.view.removeFromSuperview()
        });
    }
        
        
    /*
        Confirm that the event is going to happen
    */
    @IBAction func save(sender: AnyObject) {
        self.closeGoal()
    }
        
        
        
    // LOGIC
    /*
        Change the status of the current goal to archived on the backend.
    
        Inform the user that the archived goal is available on the table of archived goals, so
        he/she can inser the actual amount paid.
    */
    internal func closeGoal(){
        print("closing current goal ...")
        
        // delete the goal from the user-location-goal relation
        let archiveGoalQuery:PFQuery = DBHelpers.currentGoal!.openedGoalForLocation(
            PFUser.currentUser()!,
            location: DBHelpers.currentLocation!
        )
        
        archiveGoalQuery.findObjectsInBackgroundWithBlock({
            (goals:[AnyObject]?, error:NSError?) -> Void in
            
            if(error == nil){
                if let goalRelObj = goals?.first as? PFObject{
                    
                    goalRelObj[self.dbu.DBH_REL_USER_GOALS_STATUS] = self.dbu.DBH_REL_USER_GOALS_POS_STAT[2] // closed
                    
                    goalRelObj.saveInBackgroundWithBlock {
                        (success, error) -> Void in
                        
                        if(success){
                            print("display input to get the actual amount paid, in order to finish goal. Or show the archive it message")
                            self.callerViewController.infoWindow("O valor informado foi salvo com sucesso", title:"Muito obrigado pelo feedback (:", vc: self.callerViewController)
                            
                            self.closedGoal = true
                            
                            // create a new report object for archived goal
                            self.createReportOutOfOldGoal()
                        }else{
                            print("there was a problem archiving the current goal")
                            self.callerViewController.infoWindow("Houve um erro ao arquivar o objetivo atual", title:"Falha na operação", vc: self.callerViewController)
                        }
                    }
                }else{
                    print("problem getting user-location object")
                }
            }else{
                print("problem getting user-location object \(error!.description)")
            }
        })
    }
    

    
    /*
        Create a new report object with the closed goal data
    */
    internal func createReportOutOfOldGoal(){
        
        print("\ntrying to create a new report about the closed goal ...")
        
        // get current month and year to set new report
        let date = NSDate()
        let calendar = NSCalendar.currentCalendar()
        let components = calendar.components([.Year, .Month], fromDate: date)
        let year =  components.year
        let month = components.month
        
        let report = Report()
        report.setReportLocation(DBHelpers.currentLocation)
        report.setReportMonth(month)
        report.setReportYear(year)
        report.setDistanceFromGoal(self.dbh.getDistanceOfGoal())
        report.setPredWatts(DBHelpers.currentGoal?.getDesiredWatts())
        report.setRealWatts(self.dbh.getWattsSpentForCurrentGoal())
        report.setPredBill(DBHelpers.currentGoal?.getDesiredValue())
        
        if(Float(self.amountPaid.text!) != nil){
            report.setRealBill(
                NSNumber(float: Float(self.amountPaid.text!)!)
            )
        }
        
        let newReport = report.getNewReport()
        print("new report \(newReport)")
        
        newReport.saveInBackgroundWithBlock({
            (success, error:NSError?) -> Void in
            
            if(success){
                print("success saving new report.")
                
                // Reset current goal
                DBHelpers.locationGoals[(DBHelpers.currentLocation?.getObId())!] = nil
                DBHelpers.currentGoal = nil
                
                // reset the home page
                self.removeAnimate()
                self.callerViewController.loadData()
            }else{
                print("problem saving new report")
            }
        })
    }
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

