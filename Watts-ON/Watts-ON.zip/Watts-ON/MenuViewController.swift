//
//  MenuViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class MenuViewController: UITableViewController {

    
    // VARIABLES
    let feu:FrontendUtilities = FrontendUtilities()
    let dbh:DBHelpers         = DBHelpers()
    let dbu:DBUtils           = DBUtils()
    
    internal var destination = ""
    internal var menuItems:NSArray = NSArray()
    internal var userPicture:UIImage = UIImage()
    internal var colorForCellUnselected:CGColor? = nil
    internal let CELL_PRESENTATION_SPEED = 0.4
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.menuItems = self.feu.MAIN_MENU_ITEMS
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    
    // UI
    /* 
        Table view method, returns the number of sections
    */
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    
    /*
        Table view method, returns the number of rows in the current section
    */
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.menuItems.count
    }
    
    
    /* 
        Customize the menu, defining different prototype cells according to the menu opton
    */
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
        let cellIdentifier:String = self.menuItems.objectAtIndex(indexPath.row) as! String
        
        // this is where you set your color view
        let customColorView:UIView = UIView()
        customColorView.layer.backgroundColor = UIColor(red: 58.0, green: 85.0, blue: 113.0, alpha: 1.0).CGColor
        
        // loads the user profile cell
        if(cellIdentifier == self.feu.MAIN_MENU_ITEMS[0]){
            // profile cell
            let cell = tableView.dequeueReusableCellWithIdentifier(self.feu.MAIN_MENU_ITEMS[0], forIndexPath: indexPath) as! ProfileTableViewCell
            
            // username
            if let name = PFUser.currentUser()?.objectForKey("name") as? String{
                cell.username.text = name
            }else{
                cell.username.text = PFUser.currentUser()?.username
            }
            
            // picture
            let user = PFUser.currentUser()
            let picture = user?.objectForKey("picture")
            if(picture != nil){
                picture!.getDataInBackgroundWithBlock({
                    (imageData: NSData?, error: NSError?) -> Void in
                    
                    if (error == nil) {
                        let image = UIImage(data:imageData!)
                        cell.profilePic.image = image
                        self.feu.roundIt(cell.profilePic, color:self.feu.NAVBAR_BACKGROUND_COLOR)
                    }
                })
            }else{
                cell.profilePic.image = UIImage(named: "user.png")
                self.feu.roundIt(cell.profilePic, color:self.feu.NAVBAR_BACKGROUND_COLOR)
            }
            
            return cell
        }else if(cellIdentifier == self.feu.MAIN_MENU_ITEMS[self.feu.MAIN_MENU_ITEMS.count - 1]){
            
            var cell:LogoutTableViewCell = LogoutTableViewCell()
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! LogoutTableViewCell
            
            // centralize tableViewCell items
            self.feu.verticallyCentralizeElement(
                cell.btnLabel,
                parentView: cell.contentView,
                speed:self.CELL_PRESENTATION_SPEED
            )
            self.feu.verticallyCentralizeElement(
                cell.btnImage,
                parentView: cell.contentView,
                speed:self.CELL_PRESENTATION_SPEED
            )
            
            return cell
        }else{
            var cell:RegularTableViewCell = RegularTableViewCell()
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! RegularTableViewCell
            
            // centralize tableViewCell items
            self.feu.verticallyCentralizeElement(
                cell.btnLabel,
                parentView: cell.contentView,
                speed:self.CELL_PRESENTATION_SPEED
            )
            self.feu.verticallyCentralizeElement(
                cell.btnImage,
                parentView: cell.contentView,
                speed:self.CELL_PRESENTATION_SPEED
            )
            
            return cell
        }
    }


    /*
        Overrides the table row height, it specifies the height of the profile table view cell
    */
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        let cellIdentifier:String = self.menuItems.objectAtIndex(indexPath.row) as! String
        if(cellIdentifier == "perfil"){
            return 180.0
        }else{
            // get phone height
            let screenSize: CGRect = UIScreen.mainScreen().bounds
            let screenHeight = screenSize.height
            
            return (screenHeight - 180.0)/CGFloat(self.menuItems.count - 1)
        }
    }
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        // if the user selected the logout cell
        if(indexPath.row == 6){
            self.dbh.logout()
        }else{
            let selectedCell:UITableViewCell = tableView.cellForRowAtIndexPath(indexPath)!
            selectedCell.contentView.layer.backgroundColor = self.feu.NAVBAR_BACKGROUND_COLOR.CGColor
        }
    }
    
    override func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        let cellToDeSelect:UITableViewCell = tableView.cellForRowAtIndexPath(indexPath)!
        cellToDeSelect.contentView.layer.backgroundColor = self.colorForCellUnselected
    }
    
    
    
    
    // NAVIGATION
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

    }
    
}
