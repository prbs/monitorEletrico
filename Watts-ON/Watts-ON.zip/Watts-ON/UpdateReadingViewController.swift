//
//  UpdateReadingViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/22/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class UpdateReadingViewController: UIViewController {

    
    // VARIABLES
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var reading: UITextField!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var lastReading: UILabel!
    
    internal let feu:FrontendUtilities = FrontendUtilities()
    internal let dbh:DBHelpers = DBHelpers()
    internal var callerViewController: BaseViewController = BaseViewController()
    internal var savedValue:Bool     = false
    internal var value:Double        = 0.0
    internal var isFirstReading:Bool = false
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()

        let tapGesture = UITapGestureRecognizer(target: self, action: "dismissViewOnBackgroundTap")
        
        self.view.addGestureRecognizer(tapGesture)
        self.view.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.6)
        self.popUpView.layer.cornerRadius = 5
        self.popUpView.layer.shadowOpacity = 0.8
        self.popUpView.layer.shadowOffset = CGSizeMake(0.0, 0.0)

        // Do any additional setup after loading the view.
        self.reading.keyboardType = .NumberPad
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    
    
    // UI
    /*
        Customize view
    */
    internal func customizeView(){
        self.feu.roundCorners(self.container, color:self.feu.LIGHT_BLUE)
    }
    
    
    /*
        Pop up dialog
    */
    func showInView(aView: UIView!, withImage image : UIImage!, withMessage message: String!, animated: Bool){
        
        aView.addSubview(self.view)
        if animated{
            self.showAnimate()
        }
    }
    
    func showAnimate(){
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        });
        
        print(" \(DBHelpers.currentLocationData?.getLastSumReadingVal())")
        self.lastReading.text = String(DBHelpers.currentLocationData!.getLastSumReadingVal().format(".0"))
    }
    
    
    /*
        Close input dialog view
    */
    @IBAction func save(sender: AnyObject) {
        if let val:Double = Double(self.reading.text!){
            self.saveReading(val)
        }else{
            print("only numeric values are accepted")
        }
    }

    @IBAction func closePopupFromCloseBtn(sender: AnyObject) {
        self.removeAnimate(-1)
    }
    
    func dismissViewOnBackgroundTap(){
        self.removeAnimate(-1)
    }
    
    func removeAnimate(value:Double){
        UIView.animateWithDuration(0.5, animations: {
            
            // perform action on a separeted thread
            self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
            self.view.alpha = 0;
            
            self.view.frame = CGRectMake(
                self.view.frame.origin.x,
                self.view.frame.origin.y + 600,
                self.view.frame.size.width,
                self.view.frame.size.height
            )
            
        }, completion:{
            (finished : Bool)  in
            
            // update the caller view controller with the inserted value
            self.callerViewController.setReadingValue(self.value)
            
            self.view.removeFromSuperview()
        });
        
    }

    
    
    // LOGIC
    /*
        Try to add a new reading in the local history file, and upload the updated file to 
        the app backend
    */
    internal func saveReading(newReading:Double){
        
        // if it is the first reading of a goal and the user is inserting the readings without a 'Bolt' monitoring device
        if(self.isFirstReading){
            print("this is a reading made for a new goal, reseting sumLastReadingsVal ...")
            
            self.value = newReading
            
            self.removeAnimate(newReading)
        }else{
            
            print("regular manual reading, getting lastSumReadingVal to operate ...")
            let lastReadingVal = DBHelpers.currentLocationData?.getLastSumReadingVal()
            
            // check if the last reading value is valid 'for manual reading'
            if(lastReadingVal >= 0){
                
                // insert a new value into the location datafile, considering whether the user is using a 'Bolt' monitoring device or not.
                if(DBHelpers.currentDevice == nil){
                    
                    // check if the value being inserted is bigger than the last one
                    if(newReading > lastReadingVal){
                        
                        DBHelpers.currentLocationData!.addReading(newReading)
                        
                        self.dbh.executeInput()
                        
                        self.savedValue = true
                        
                        self.removeAnimate(newReading)
                    }else{
                        print("input is smaller than last reading value")
                        self.showInvalidDialog()
                    }
                }else{
                    print("user has a device attached to this location and is trying to make a manual reading")
                }
            }else{
                print("negative input")
                self.showInvalidDialog()
            }
        }
    }
    
    

    
    internal func showInvalidDialog(){
        self.view.removeFromSuperview()
        
        let title = "O valor inserido não é válido"
        let msg = "O valor informado é menor do que o último valor de leitura do seu relógio."
        
        let refreshAlert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Tentar novamente", style: .Default, handler: { (action: UIAlertAction) in
            
            print("showing input dialog again")
            self.showInView(
                self.callerViewController.view,
                withImage: UIImage(named: ""),
                withMessage: "",
                animated: true
            )
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancelar", style: .Default, handler: { (action: UIAlertAction) in
            
            print("user canceled the operation.")
        }))
        
        self.callerViewController.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
