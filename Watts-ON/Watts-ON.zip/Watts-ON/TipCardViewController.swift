//
//  TipCardViewController.swift
//  x
//
//  Created by Diego Silva on 11/5/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class TipCardViewController: UIViewController {

    
    // VARIABLES
    @IBOutlet weak var tipImage: UIImageView!
    @IBOutlet weak var tipTitle: UILabel!
    @IBOutlet weak var observation: UITextView!
    
    internal let bvc:BaseViewController = BaseViewController()
    internal let dbh:DBHelpers = DBHelpers()
    internal var callerViewController: HomeViewController = HomeViewController()
    internal var afterFailure:Bool = false
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "dismissViewOnBackgroundTap")
        self.view.addGestureRecognizer(tapGesture)
        self.view.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.8)
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    
    
    // UI
    /*
        Pop up dialog
    */
    func showInView(aView: UIView!, animated: Bool){
        
        aView.addSubview(self.view)
        if animated{
            self.showAnimate()
        }
    }
    
    func showAnimate(){
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        });
    }
    
    
    /*
        Close input dialog view
    */
    @IBAction func closePopup(sender: AnyObject) {
        self.removeAnimate()
    }
    
    
    /*
        Close input dialog view
    */
    func dismissViewOnBackgroundTap(){
        self.removeAnimate()
    }
    
    func removeAnimate(){
        UIView.animateWithDuration(0.5, animations: {
            // perform action on a separeted thread
            self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
            self.view.alpha = 0;
            
            self.view.frame = CGRectMake(
                self.view.frame.origin.x,
                self.view.frame.origin.y + 600,
                self.view.frame.size.width,
                self.view.frame.size.height
            )
            }, completion:{
                (finished : Bool)  in
                
                // inform the caller view controller that the operation went wrong
                if(self.afterFailure){
                    self.callerViewController.displayFinishedGoalMessage()
                }
                
                self.view.removeFromSuperview()
        });
        
    }
    
    
    
    
    // LOGIC
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}