//
//  LoadInfoViewController.swift
//  x
//
//  Created by Diego Silva on 11/22/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class LoadInfoViewController: BaseViewController {

    
    
    // VARIABLES AND CONSTANTS
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var loadingPercentage: UILabel!
    @IBOutlet weak var spinner: UIImageView!
    
    internal var loadingTimer:NSTimer = NSTimer()
    internal var SPINNER_SPEED:Double = 0.6
    
    
    
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()

        print("current user \(PFUser.currentUser())")
        
        // checks if the user has a saved session
        if let _ = PFUser.currentUser(){
            print("getting user from last session ...")
            
            let initializer:SystemInitializer = SystemInitializer()
            initializer.lui = self
            initializer.initSystem()
        }else{
            print("user doesn't have old session, send him/her login ...")
            self.feu.goToSegueX(self.feu.ID_LOGIN, obj: self)
        }
    }

    
    
    // UI
    internal func startLoadingAnimation(){
        print("\nstarting loading animation")
        
        // show elements
        //self.feu.fadeIn(loadingPercentage, speed: 0.4)
        self.feu.fadeIn(spinner, speed: self.SPINNER_SPEED)
        
        self.rotateSpinner()
        
        // start counting the loading time
        self.loadingTimer = NSTimer.scheduledTimerWithTimeInterval(
            self.SPINNER_SPEED,
            target   : self,
            selector : Selector("rotateSpinner"),
            userInfo : nil,
            repeats  : true
        )
    }
    
    
    /*
        Rotate the spinner until it the page is fully loaded
    */
    internal func rotateSpinner(){
        UIView.animateWithDuration(
            self.SPINNER_SPEED,
            delay: 0,
            options: .CurveLinear, animations: {
                () -> Void in
                
                self.spinner.transform = CGAffineTransformRotate(
                    self.spinner.transform,
                    CGFloat(M_PI_2)
                )
            }
        ){
            (finished) -> Void in
        }
    }
    
    
    /*
        Stop spinner rotation
    */
    internal func stopSpinner(){
        self.loadingTimer.invalidate()
    }
    
    
    internal func setLoadingPercentage(percentage:String, isLast:Bool){
        self.loadingPercentage.text = percentage
        
        if(isLast){
            self.feu.fadeOut(self.spinner, speed:3.2)
            self.feu.fadeOut(self.loadingPercentage, speed:3.2)
            self.feu.fadeIn(self.welcomeLabel, speed: 0.8)
        }
    }
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
