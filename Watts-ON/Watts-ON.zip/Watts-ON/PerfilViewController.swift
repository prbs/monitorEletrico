//
//  PerfilViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 9/19/15.
//  Copyright (c) 2015 SudoCRUD. All rights reserved.
//

import UIKit

class PerfilViewController: BaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource {

    
    // VARIABLES
    // Containers
    @IBOutlet weak var updateContainer: UIView!
    @IBOutlet weak var banner: UIView!
    @IBOutlet weak var menuBtn: UIBarButtonItem!
    @IBOutlet weak var homeBtn: UIBarButtonItem!
    @IBOutlet weak var pictureBtn: UIButton!
    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userEmail: UILabel!
    @IBOutlet weak var registerDate: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var tableView: UITableView!
    
    internal let dbh:DBHelpers = DBHelpers()
    internal let dbu:DBUtils   = DBUtils()
    
    internal var imagePicker = UIImagePickerController()
    internal var selectedPicture:PFFile? = nil
    internal let imgPicController:ImagePickerViewController = ImagePickerViewController()
    internal var availableLocations:Array<Location> = []
    
    
    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        
        // UI initialization
        self.customizeNavBar(self)
        self.customizeMenuBtn(self.menuBtn, btnIdentifier: self.feu.ID_MENU)
        self.customizeMenuBtn(self.homeBtn, btnIdentifier: self.feu.ID_HOME)
        self.feu.roundIt(self.pictureBtn, color:self.feu.SUPER_LIGHT_WHITE)
        
        // apply shadow
        self.feu.applyPlainShadow(self.updateContainer)
        self.feu.applyHoverShadow(self.pictureBtn)
        self.feu.applyCurvedShadow(self.saveBtn)
        
        // Banner labels
        self.feu.fadeIn(self.userNameLabel, speed: 1.0)
        self.feu.fadeIn(self.registerDate, speed: 2.0)
        self.feu.fadeIn(self.userEmail, speed: 3.0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // binds the show menu toogle action implemented by SWRevealViewController to the menu button
        if self.revealViewController() != nil {
            menuBtn.target = self.revealViewController()
            menuBtn.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        self.kbHeight = 10
        
        // regiester text fields
        self.userName.delegate = self
        
        // tableView initialization
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        // load current user information
        self.loadData()
    }
    
    
    // UI
    /*
        Table methods
    */
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.availableLocations.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // create a new cell
        let cell = tableView.dequeueReusableCellWithIdentifier("SharedPlaceTableViewCell") as! SharedPlaceTableViewCell
        
        // load the new cell with data
        cell.parentController     = self
        cell.index                = indexPath
        
        // get the location out of the locations array to load the cell variables
        let location = self.availableLocations[indexPath.row]
        cell.location = location
        cell.placeName.text = location.getLocationName()
        
        // get location admin admin's name
        if let admPointer = location.getLocationAdmin(){
            let query:PFQuery = User.query()!
            query.getObjectInBackgroundWithId(admPointer.objectId!){
                (user, error) -> Void in
                
                if((user != nil) && (error == nil)){
                    if let u = user as? PFUser{
                        cell.adminName.text = u.username
                    }else{
                        print("problems converting user from app backend into PFObject")
                        cell.opaque = true
                    }
                }
            }
        }else{
            print("problems getting location admin")
        }
        
        // get number of users of the selected location
        PFCloud.callFunctionInBackground("getNumberOfUsersLocation", withParameters: ["locationId": location.getObId()]) {
            (nUsers, error) in
            
            if (error == nil){
                if let numberOfUsers = nUsers as? Int {
                    cell.nUsers.text = String(numberOfUsers)
                }else{
                    print("problems getting the number of users connected to this location")
                    cell.nUsersLabel.text = "usuário"
                }
            }else{
                print("\nerror: \(error)")
                print("problems getting the number of users connected to this location")
                cell.nUsersLabel.text = "usuário"
            }
        }
        
        // get the location profile
        cell.placeTypeLabel.text  = location.getLocationType()
        if(location.getLocationType() == "Residencial"){
            cell.placeTypeImage.image = UIImage(named:"home.png")
        }else{
            cell.placeTypeImage.image = UIImage(named:"factory.png")
        }
        
        return cell
    }

    
    
    // IMAGE SELECTOR METHODS
    /*
        Initializer the image picker controller, to obey to the PerfilViewController class
    */
    @IBAction func selecteProfilePicture(sender: AnyObject) {
        print("\nselecting new profile picture ...")
        
        self.imgPicController.setCallerVC(self, source: self.feu.ID_PROFILE)
        self.imgPicController.selectPictureFromRoll(sender)
    }
    
    /*
        Set the picture selector btn with the chosen image
    */
    internal func setChosenImg(img:UIImage){
        print("\nsetting chosen image \(img)")
        self.pictureBtn.setImage(img, forState: .Normal)
    }
    
    /*
        Set the selected picture file target with the selected file
    */
    internal func setChosenImgFile(file:PFFile){
        self.selectedPicture = file
    }
    
    
    /*
        Save user info
    */
    @IBAction func saveInfo(sender: AnyObject) {
        print("\nstarting saving user info process ...")
        
        self.validateInputs()
    }
    
    
    
    // LOGIC
    /*
        Validate the information that was inserted
    */
    internal func validateInputs(){
        print("\nvalidating inputs ...")
        if let name = self.userName.text{
            
            print("problems getting user profile picture")
            self.save(name, picture: self.selectedPicture)
        }else{
            print("problem getting user name")
        }
    }
    
    
    /*
        Save validated user information
    */
    internal func save(name:String, picture:PFFile?){
        print("\nsaving user information ...")
        
        // save info locally
        PFUser.currentUser()![self.dbu.DBH_USER_NAME] = name
        
        if let pic = picture{
            PFUser.currentUser()![self.dbu.DBH_USER_PICTURE] = pic
        }
        
        // save in the app backend
        PFUser.currentUser()?.saveInBackground()
        
        self.infoWindow("", title: "Dados atualizados com sucesso", vc: self)
        self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
    }
    
    
    /*
        Load current user information
    */
    internal func loadData(){
        print("\nloading current user information ...")
        
        if let u:PFUser = PFUser.currentUser(){
            let user:User = User(user:u)
            
            // load user information
            if let regDate:NSDate = u.createdAt{
                self.loadUserInformation(user, createdAt: regDate)
            }
            
            // load table view data
            self.getAllUserLocations(user)
        }else{
            print("problems to get current user as User object")
        }
    }
    
    
    /*
        Load user information
    */
    internal func loadUserInformation(user:User, createdAt:NSDate){
        
        // set user profile picture
        if let pic:UIImage = user.getUserPicUIImage(){
            self.setChosenImg(pic)
        }else{
            print("problems to get profile picture, leave the select picture button as it is")
                
            // load the user picture for this object
            if let picFile:PFFile =  user.getUserPicture(){
                    
                // if the image wasn't download in time make the request to get the file
                picFile.getDataInBackgroundWithBlock({
                    (imageData: NSData?, error: NSError?) -> Void in
                        
                    if (error == nil) {
                        let image = UIImage(data:imageData!)
                        self.setChosenImg(image!)
                    }
                })
            }else{
                    
                // if getting image from backend failed, let the picture selector button as it is
                if let stdImg = self.feu.getDefaultProfileImg(){
                    self.setChosenImg(stdImg)
                }
            }
        }
            
        // set username
        if(user.getUserName() == self.dbu.STD_UNDEF_STRING){
            self.userName.text = "Qual é o seu nome?"
        }else{
            self.userName.text = user.getUserName()
            self.userNameLabel.text = user.getUserName()
        }
            
        // set other attributes
        self.userEmail.text = user.getUserEmail()
            
        // set register date
        self.registerDate.text = "Usuário desde " + createdAt.formattedWith(self.feu.DATE_FORMAT)
    }
    
    
    
    /*
        Get a list of all user locations
    */
    internal func getAllUserLocations(user:User){
        
        // Get all available locations
        PFCloud.callFunctionInBackground("getAllUserLocations", withParameters: [
            "userId": user.getObId()!
        ]) {
            (objects, error) in
            
            if (error == nil){
                if let locIds:Array<AnyObject> = objects as? Array<AnyObject> {
                    print("\nuser location ids: \n\(locIds)")
                    
                    // make sure the loop won't break if the array is empty
                    if(locIds.count > 0){
                        for i in 0...(locIds.count - 1){
                            if let id:String = locIds[i] as? String{
                                
                                // get the actual location PFObject
                                if(i == (locIds.count - 1)){
                                    self.getLocationById(id, isLast: true)
                                }else{
                                    self.getLocationById(id, isLast: false)
                                }
                            }else{
                                print("problem converting location id into string")
                            }
                        }
                    }
                }else{
                    print("problems converting results into array of locations.")
                }
            }else{
                print("\nerror: \(error)")
            }
        }
    }
    
    
    
    /*
        Get location PFObject by id
    */
    internal func getLocationById(locId:String, isLast:Bool){
        print("\ngetting location by id ...")
        
        // Get all available locations
        PFCloud.callFunctionInBackground("getLocationById", withParameters: [
            "locationId": locId
        ]) {
            (locObj, error) in
                
            if (error == nil){
                if let location:PFObject = locObj as? PFObject {
                    print("\nlocation: \(location)")
                    self.availableLocations.append(Location(location:location))
                }else{
                    print("problems converting results into array of locations.")
                }
                
                self.isDoneLoading(isLast)
            }else{
                print("\nerror: \(error)")
                self.isDoneLoading(isLast)
            }
        }
    }
    
    
    internal func isDoneLoading(isLast:Bool){
        
        // if this is the last iteration, update the tableview datasource
        if(isLast){
            print("this was the last iteration.")
            self.tableView.reloadData()
        }else{
            print("still have to load more locations")
        }
    }
    
    
    
    
    // NAVIGATION
    /*
        Go home
    */
    @IBAction func goHome(sender: AnyObject) {
        self.feu.goToSegueX(self.feu.ID_HOME, obj: self)
    }
    

    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
