//
//  DeviceCardView.swift
//  x
//
//  Created by Diego Silva on 11/15/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class DeviceCardView: UIView {

    
    // VARIABLES
    @IBOutlet weak var outterContainer: UIView!
    @IBOutlet weak var innerContainer: UIView!
    @IBOutlet weak var banner: UIView!
    @IBOutlet weak var infoContainer: UIView!
    @IBOutlet weak var monitoredPlaceTypeContainer: UIView!
    
    @IBOutlet weak var monitoredPlaceImgType: UIImageView!
    @IBOutlet weak var monitoredPlace: UILabel!
    @IBOutlet weak var deviceStatus: UILabel!
    @IBOutlet weak var paymentStatus: UILabel!
    
    internal let feu:FrontendUtilities = FrontendUtilities()
    
    
    // INITIALIZERS
    override func drawRect(rect: CGRect) {
        self.feu.roundCorners(self.outterContainer, color: self.feu.SUPER_LIGHT_WHITE)
        self.feu.roundCorners(self.innerContainer, color: self.feu.SUPER_LIGHT_WHITE)
        
        self.feu.roundIt(self.monitoredPlaceTypeContainer, color: self.feu.DARK_WHITE)
        self.feu.applyHoverShadow(self.monitoredPlaceTypeContainer)
    }
    
}
