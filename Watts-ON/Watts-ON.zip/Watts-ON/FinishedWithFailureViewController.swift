//
//  FinishedWithFailureViewController.swift
//  x
//
//  Created by Diego Silva on 11/4/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class FinishedWithFailureViewController: UIViewController {

    
    // VARIABLES
    // custom progress bar
    @IBOutlet weak var landmark: UIView!
    @IBOutlet weak var finalLandmark: UIView!
    @IBOutlet weak var movingPointer: UIView!
    @IBOutlet weak var desiredValue: UILabel!
    @IBOutlet weak var progressBar: UIView!
    @IBOutlet weak var progressBarTrail: UIView!
    @IBOutlet weak var estimatedValue: UILabel!

    // bar chart "KW x Day"
    @IBOutlet weak var barChartView: BarChartView!
    internal let BARCHART_ARRAY_COLORS = [
        UIColor(red: 230/255, green: 126/255, blue: 34/255, alpha: 1)
    ]
    
    internal let bvc:BaseViewController = BaseViewController()
    internal let dbh:DBHelpers = DBHelpers()
    internal var callerViewController:HomeViewController = HomeViewController()
        
        
        
    // INITIALIZERS
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "dismissViewOnBackgroundTap")
        self.view.addGestureRecognizer(tapGesture)
        self.view.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.8)
    }
        
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
        
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
        
    
    
    // UI
    /*
        Pop up dialog
    */
    func showInView(aView: UIView!, animated: Bool){
            
        aView.addSubview(self.view)
        if animated{
            self.showAnimate()
        }
    }
        
    func showAnimate(){
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        });
    }
        
        
    /*
        Close input dialog view
    */
    @IBAction func closePopupFromCloseBtn(sender: AnyObject) {
        self.removeAnimate()
    }
        
    func dismissViewOnBackgroundTap(){
        self.removeAnimate()
    }
        
    func removeAnimate(){
        UIView.animateWithDuration(0.5, animations: {
            
            self.view.transform = CGAffineTransformMakeScale(0.2, 0.2)
            self.view.alpha = 0;
                
            self.view.frame = CGRectMake(
                self.view.frame.origin.x,
                self.view.frame.origin.y + 600,
                self.view.frame.size.width,
                self.view.frame.size.height
            )
            }, completion:{
                (finished : Bool)  in
                    
                self.callerViewController.openTipDialog(true)
        });
            
    }

    
    /*
        Creates the progress bar animation with an intermediate landmark
    */
    func animateProgressBar(progressBar:UIView, progressBarTrail:UIView, progressPointer:UIView, landmark:UIView, finalLandmark:UIView, startValue:Float, landmarkValue:Float, endValue:Float){
        
        let LANDMARK_FADE_IN_SPEED       = 1.1
        let MOVING_POINTER_GROWING_RATIO = CGFloat(4)
        let FINAL_LANDMARK_FADE_IN_SPEED = 0.7
        let INITIAL_PROGRESS_COLOR       = UIColor.blueColor()
        let INTERMEDIATE_PROGRESS_COLOR  = UIColor.orangeColor()
        let FINAL_PROGRESS_COLOR         = UIColor.redColor()
        
        let pBarWidth     = progressBarTrail.frame.width
        let progressRatio = pBarWidth * 0.01
        let valuePoints   = CGFloat(endValue - startValue)
        let landmarkLeftMov = CGFloat(CGFloat(landmarkValue * 100)/valuePoints) * progressRatio
        let landmarkPos = progressBar.frame.origin.x + landmarkLeftMov
        let finalLandmarkPos = progressBar.frame.origin.x + pBarWidth
        
        print("\n\nPROGRESS BAR ANIMATION")
        print("startValue: \(startValue)")
        print("landmarkValue: \(landmarkValue)")
        print("endValue: \(endValue)")
        
        print("\npBarWidth: \(pBarWidth)")
        print("progressRatio: \(progressRatio)")
        print("landmarkPos: \(landmarkPos)")
        print("finalLandmarkPos: \(finalLandmarkPos)")
        
        // Progress bar pointer animation
        UIView.animateWithDuration(0.01, animations:{
            
            // set the initial value of the progress pointer
            progressPointer.frame = CGRectMake(
                progressPointer.frame.origin.x - landmarkLeftMov,
                progressPointer.frame.origin.y,
                progressPointer.frame.size.width - MOVING_POINTER_GROWING_RATIO,
                progressPointer.frame.size.height - MOVING_POINTER_GROWING_RATIO
            )
            
            // set the initial value of the landmark view
            landmark.frame = CGRectMake(
                landmark.frame.origin.x - landmarkLeftMov,
                landmark.frame.origin.y,
                landmark.frame.size.width - MOVING_POINTER_GROWING_RATIO,
                landmark.frame.size.height - MOVING_POINTER_GROWING_RATIO
            )
            }, completion: {
                (value: Bool) in
                
                // animate pointer to the intermediary position
                UIView.animateWithDuration(LANDMARK_FADE_IN_SPEED, animations:{
                    progressPointer.frame = CGRectMake(
                        progressPointer.frame.origin.x + landmarkLeftMov,
                        progressPointer.frame.origin.y + (MOVING_POINTER_GROWING_RATIO/2),
                        progressPointer.frame.size.width + MOVING_POINTER_GROWING_RATIO,
                        progressPointer.frame.size.height + MOVING_POINTER_GROWING_RATIO
                    )
                    
                    // set the final position of the landmark view
                    landmark.frame = CGRectMake(
                        landmark.frame.origin.x + landmarkLeftMov,
                        landmark.frame.origin.y,
                        landmark.frame.size.width - MOVING_POINTER_GROWING_RATIO,
                        landmark.frame.size.height - MOVING_POINTER_GROWING_RATIO
                    )
                    landmark.alpha = 0.0
                    
                    }, completion: {
                        (value: Bool) in
                        
                        // fade in the intermediate landmark
                        UIView.animateWithDuration(LANDMARK_FADE_IN_SPEED, animations:{
                            landmark.hidden = false
                            landmark.alpha = 1.0
                            }, completion: {
                                (value: Bool) in
                                
                                print("start second part of the animation")
                                
                                // animate progress bar to the final position
                                UIView.animateWithDuration(LANDMARK_FADE_IN_SPEED, animations:{
                                    progressBar.frame = CGRectMake(
                                        progressBar.frame.origin.x,
                                        progressBar.frame.origin.y,
                                        pBarWidth,
                                        progressBar.frame.size.height
                                    )
                                    
                                    progressBar.backgroundColor = FINAL_PROGRESS_COLOR
                                })
                                
                                // animate pointer to the final position
                                UIView.animateWithDuration(LANDMARK_FADE_IN_SPEED, animations:{
                                    progressPointer.frame = CGRectMake(
                                        finalLandmarkPos,
                                        progressPointer.frame.origin.y,
                                        progressPointer.frame.size.width,
                                        progressPointer.frame.size.height
                                    )
                                    
                                    finalLandmark.hidden = true
                                    finalLandmark.alpha = 0.0
                                    
                                    }, completion:{
                                        (value: Bool) in
                                        
                                        // fade in the intermediate landmark
                                        UIView.animateWithDuration(FINAL_LANDMARK_FADE_IN_SPEED, animations:{
                                            finalLandmark.hidden = false
                                            finalLandmark.alpha = 1.0
                                            }, completion:{
                                                (value: Bool) in
                                                
                                                self.animateExpensesDay()
                                            })
                                })
                        })
                })
        })

        
        // Progress bar animation
        UIView.animateWithDuration(0.01, animations:{
            
            // set the initial value of the progress pointer
            progressBar.frame = CGRectMake(
                progressBar.frame.origin.x,
                progressBar.frame.origin.y,
                progressBar.frame.size.width - landmarkLeftMov,
                progressBar.frame.size.height
            )
            
            progressBar.backgroundColor = INITIAL_PROGRESS_COLOR
            }, completion: {
                (value: Bool) in
                
                // animate pointer to the intermediary position
                UIView.animateWithDuration(LANDMARK_FADE_IN_SPEED, animations:{
                    progressBar.frame = CGRectMake(
                        progressBar.frame.origin.x,
                        progressBar.frame.origin.y,
                        progressBar.frame.size.width + landmarkLeftMov,
                        progressBar.frame.size.height
                    )
                    
                    progressBar.backgroundColor = INTERMEDIATE_PROGRESS_COLOR
                })
        })
        
    }
    
    
    
    /*
        Animate Expenses x Day
    */
    internal func animateExpensesDay(){
        
        // if there is a current goal and there is data to build the chart
        if(DBHelpers.currentGoal != nil && (DBHelpers.currentLocationData!.getDays().count > 0)){
            
            // get the start date of a goal
            if let startDate:NSDate = (DBHelpers.currentGoal?.getStartingDate()){
                
                // get the end date of a goal
                if let endDate:NSDate = (DBHelpers.currentGoal?.getStartingDate())!{
                    
                    // animate expenses per day
                    if let days:Array<String> = DBHelpers.currentLocationData!.getDaysWithReadingForGoal(
                            startDate,
                            endDate: endDate
                        ) as? Array<String>{
                            
                            if let kwh = (DBHelpers.currentGoal?.getKWH()){
                                
                                // get list of kwhs by day
                                let kwhs = DBHelpers.currentLocationData!.getListSpentValuesByDay(
                                    days,
                                    kwh:kwh
                                )
                                
                                self.setChart(days, values: kwhs)
                            }else{
                                print("problem to get kwh from current goal")
                            }
                    }else{
                        print("problem getting list of days within goal period")
                    }
                }else{
                    print("problem getting end date")
                }
            }else{
                print("problem getting start date")
            }
        }else{
            print("selected location doesn't have a goal")
        }
        
    }
    
    
    
    /*
        Set the barchart used to show how much money the user spent on each day in the period defined by the goal
    */
    func setChart(dataPoints: [String], values: [Double]) {
        
        var dataEntries: [BarChartDataEntry] = []
        for i in 0..<dataPoints.count {
            
            let dataEntry = BarChartDataEntry(value: values[i], xIndex: i)
            dataEntries.append(dataEntry)
        }
        
        let barChartDataSet = BarChartDataSet(yVals: dataEntries, label: "KW/Dia")
        barChartDataSet.colors = self.BARCHART_ARRAY_COLORS
        
        let barChartData = BarChartData(xVals: dataPoints, dataSet: barChartDataSet)
        self.barChartView.data = barChartData
        
        // customize chart
        self.barChartView.noDataText = "Nenhum dado de leitura encontrado"
        self.barChartView.leftAxis.enabled = false
        self.barChartView.xAxis.labelPosition = .Bottom
        self.barChartView.descriptionText = ""
        self.barChartView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}


