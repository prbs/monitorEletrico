//
//  NewRewardViewController.swift
//  Watts-ON
//
//  Created by Diego Silva on 10/13/15.
//  Copyright © 2015 SudoCRUD. All rights reserved.
//

import UIKit

class NewRewardViewController: BaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate {

    
    // VARIABLES
    internal let dbu:DBUtils = DBUtils()
    
    internal var reward:Reward? = nil
    internal var task:String? = "create"
    internal var imagePicker = UIImagePickerController()
    internal let IMAGE_SIZE = 900000
    internal let ACTION_NAV_BACK = "back"
    internal let ACTION_NAV_STAY = "stay"
    
    @IBOutlet weak var scroller: UIScrollView!
    @IBOutlet weak var contentContainer: UIView!
    @IBOutlet weak var toolbar: UIView!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var imageSizeWarning: UILabel!
    @IBOutlet weak var selectPicture: UIButton!
    @IBOutlet weak var rewardTitle: UITextField!
    @IBOutlet weak var rewardPicture: UIImageView!
    @IBOutlet weak var rewardDescription: UITextView!
    
    
    // INITIALIZERS
    override func viewDidAppear(animated: Bool) {
        // UI
        self.setScroller()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("reward on Reward Upsert: \(self.reward) selected task: \(self.task)")
        
        // keyboard animation
        self.kbHeight = 60
        self.rewardTitle.delegate = self
        self.rewardDescription.delegate = self
        
        // load reward information
        if(self.reward != nil){
            self.rewardTitle.text = self.reward?.getRewardTitle()
            
            print("Reward img: \(self.reward?.getRewardPictureImg())")
            self.rewardPicture.image = self.reward?.getRewardPictureImg()
            
            self.rewardDescription.text = self.reward?.getRewardInfo()
        }
        
        // set image size warning label
        self.imageSizeWarning.hidden = true
    }

    
    // UI
    /*
        Configure the dimensions of the scroller view
    */
    internal func setScroller(){
        self.scroller.userInteractionEnabled = true
        self.scroller.frame = self.view.bounds
        self.scroller.contentSize.height = self.contentContainer.frame.size.height
        self.scroller.contentSize.width = self.contentContainer.frame.size.width
    }
    
    
    /*
        Delete the current reward picture
    */
    @IBAction func deleteRewardPicture(sender: AnyObject) {
        print("Delete reward picture")
        
        // update view
        self.rewardPicture.image = UIImage(named:"imgres.jpg")
        
        // update object
        self.reward?.setRewPictureImg(UIImage(named:"imgres.jpg"))
        self.reward?.setRewPicture(nil)
    }
    
    
    /*
        Select a new picture for the reward from the user's camera roll
    */
    @IBAction func selectPictureFromRoll(sender: AnyObject) {
        print("\nSelect new reward picture from camera roll")
        
        // image picker initialization
        self.imagePicker.delegate = self
        self.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
        self.imagePicker.allowsEditing = false
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum){
            print("selecting image from roll ...")
            
            self.presentViewController(self.imagePicker, animated: true, completion: nil)
        }
    }
    
    
    /*
        Save updaated reward information
    */
    @IBAction func updateRewardInfo(sender: AnyObject) {
        print("\nUpsert reward info")
        
        self.upsertRewardInfoOnBackend(sender)
    }
    
    
    // UITextView
    //-----------
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        // set the drag distance of the keyboard animation
        self.kbHeight = 120
        
        return true
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            self.rewardDescription.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        // reset the drag distance of the keyboard animation
        self.kbHeight = 60
    }
    
    
    // MARK: - Image picker
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        self.imageSizeWarning.hidden = true
        
        // fetch the selected image
        if self.imagePicker.allowsEditing {
            self.rewardPicture.image = info[UIImagePickerControllerEditedImage] as? UIImage
        } else {
            print("\nimage picked \(info[UIImagePickerControllerOriginalImage] as? UIImage)")
            
            if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
                
                // get image file size to prevent that huge images get uploaded
                let imageData = UIImagePNGRepresentation(image)
                print("\nimage file size: \(imageData?.length)")
                
                if(validadeImageSize((imageData?.length)!)){
                    self.rewardPicture.image = image
                }else{
                    print("\nwarning, image file size is to large")
                }
            }
        }
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        print("user canceled the operation")
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    internal func validadeImageSize(size:Int) -> Bool{
        
        if(size < self.IMAGE_SIZE){
            return true
        }
        
        self.imageSizeWarning.hidden = false
        
        return false
    }
    
    
    // Information
    //------------
    internal func infoWindow(txt:String, title:String, vc:UIViewController, navAction:String) -> Void{
        
        let refreshAlert = UIAlertController(title: title, message: txt, preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction) in
            
            print("\naction \(navAction)")
            print("\naction \(self.ACTION_NAV_STAY)")
            if(navAction == self.ACTION_NAV_BACK){
                self.navigationController?.popToRootViewControllerAnimated(true)
            }
        }))
        
        vc.presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    
    
    // LOGIC
    /*
        Update reward info
    */
    internal func upsertRewardInfoOnBackend(sender:AnyObject){
        
        if(self.task == "update"){
            
            // Start of update Reward process
            // load data
            self.reward?.setRewPicture(self.feu.imageToFile(self.rewardPicture.image!))
            self.reward?.setRewInfo(self.rewardDescription.text)
            self.reward?.setRewTitle(self.rewardTitle.text)
            
            // validate new reward title
            if(self.reward?.getRewardTitle() == ""){
                self.infoWindow("Por favor insira um título para sua recompensa", title: "Título é obrigatório", vc: self, navAction: self.ACTION_NAV_STAY)
            }else{
                if(self.reward?.getRewardInfo() == ""){
                    self.infoWindow("Por favor insira uma descrição para sua recompensa", title: "Descrição é obrigatória", vc: self, navAction: self.ACTION_NAV_STAY)
                }else{
                    print("updated reward info: \(self.reward)")
            
                    let query = Reward.query()
                    query!.getObjectInBackgroundWithId((self.reward?.getObId())!){
                        (rewardObj, error) -> Void in
                        //print("reward \(rewardObj)")
                
                        if(error == nil){
                            print("updating reward info ...")
                    
                            self.reward?.updateReward(rewardObj!)
                    
                            rewardObj?.saveInBackgroundWithBlock{
                                (success, error) -> Void in
                        
                                if(error == nil){
                                    print("updated successfully")
                                    self.infoWindow("Sua recompensa foi atualizada com sucesso", title: "Operação concluída", vc: self, navAction:self.ACTION_NAV_BACK)
                                }else{
                                    print("failed to update Reward")
                                    self.infoWindow("Falha ao criar nova recompensa", title: "Falha na operação", vc: self, navAction:self.ACTION_NAV_STAY)
                                }
                            }
                        }else{
                            print("error, no reward found for the id \(self.reward?.getObId())")
                            self.infoWindow("Erro de conexão com o servidor", title: "Erro de conexão", vc:self, navAction:self.ACTION_NAV_STAY)
                        }
                    }
                }
            }
            // end of update reward process
            
        }else{
            
            // Start of new reward process
            // load data
            self.reward = Reward()
            self.reward?.setRewOwner(PFUser.currentUser())
            self.reward?.setRewPicture(self.feu.imageToFile(self.rewardPicture.image!))
            self.reward?.setRewInfo(self.rewardDescription.text)
            self.reward?.setRewTitle(self.rewardTitle.text)
            
            // validate new reward title
            if(self.reward?.getRewardTitle() == ""){
                self.infoWindow("Por favor insira um título para sua recompensa", title: "Título é obrigatório", vc: self, navAction: self.ACTION_NAV_STAY)
            }else{
                if(self.reward?.getRewardInfo() == ""){
                    self.infoWindow("Por favor insira uma descrição para sua recompensa", title: "Descrição é obrigatória", vc: self, navAction: self.ACTION_NAV_STAY)
                }else{
                    
                    let checkRewardExist:PFQuery = (self.reward?.checkIfRewardExistQuery())!
                    checkRewardExist.findObjectsInBackgroundWithBlock{
                        (objectFound, error) -> Void in
                        
                        // if there is already a Reward with the same name and description, interrupts the operation
                        if(error == nil){
                            print("\(objectFound)")
                            
                            if(objectFound?.count == 0){
                                print("\ntrying to create new reward: \(self.reward) ...")
                                self.createNewReward(self.reward!)
                            }else{
                                print("\nthere is already a reward with the same title and description, cancelling operation ...")
                                
                                self.infoWindow("Já existe uma recompensa com o mesmo título e descrição, por favor escolha mude alguma destas informações", title: "Recompensa já existe", vc: self, navAction:self.ACTION_NAV_STAY)
                            }
                        }else{
                            self.infoWindow("Houve uma falha de comunicação com o servidor", title: "Falha na operação", vc: self, navAction:self.ACTION_NAV_STAY)
                        }
                    }
                }
            }
            // End of new reward process
            
        }
        
    }
    
    
    /*
        Get a loaded and valid Reward object and save it.
    */
    internal func createNewReward(reward:Reward){
        
        let reward = self.reward?.getNewRewardPFobj()
        reward!.saveInBackgroundWithBlock{
            (success, error) -> Void in
            
            if(error == nil){
                print("created successfully")
                self.infoWindow("Nova recompensa criada com sucesso", title: "Operação concluída", vc: self, navAction:self.ACTION_NAV_BACK)
            }else{
                print("failed to create new Reward")
            }
        }
        
    }
    
    
    
    // NAVIGATION
    @IBAction func unwindWithSelectedGame(segue:UIStoryboardSegue) {
        if let rewardsViewController = segue.sourceViewController as? RewardsViewController{
            rewardsViewController.loadView()
        }
    }
    
    
    
    // MANDATORY METHODS
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
